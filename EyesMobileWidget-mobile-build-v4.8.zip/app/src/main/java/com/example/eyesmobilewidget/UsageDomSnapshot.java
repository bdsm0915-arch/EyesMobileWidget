package com.example.eyesmobilewidget;

import android.webkit.WebView;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/** Builds a small, usage-focused DOM snapshot instead of parsing the whole MyPage text. */
public final class UsageDomSnapshot {
    private UsageDomSnapshot() {}

    public interface Callback {
        void onSnapshot(String snapshot);
    }

    public static void capture(WebView webView, Callback callback) {
        if (webView == null) {
            if (callback != null) callback.onSnapshot("");
            return;
        }
        try {
            webView.evaluateJavascript(JS, value -> {
                String decoded = decodeJsString(value);
                if (callback != null) callback.onSnapshot(decoded == null ? "" : decoded);
            });
        } catch (Throwable t) {
            if (callback != null) callback.onSnapshot("");
        }
    }

    public static String freshMyPageUrl() {
        return EyesMobileFetcher.MY_PAGE_URL;
    }

    public static void loadFresh(WebView webView) {
        if (webView == null) return;
        // v4.3: do not manufacture a unique URL and force a full HTML/cache miss on every tap.
        // The MyPage shell may be reused by WebView while EyesMobile's own usage request remains
        // responsible for retrieving the live counters.
        webView.loadUrl(EyesMobileFetcher.MY_PAGE_URL);
    }

    private static final String JS =
            "(function(){try{" +
            "function clean(s){return (s||'').replace(/\\u00a0/g,' ').replace(/[\\t\\r]+/g,' ').replace(/ *\\n */g,'\\n').replace(/\\n{3,}/g,'\\n\\n').trim();}" +
            "function visible(e){try{var st=getComputedStyle(e);if(st.display==='none'||st.visibility==='hidden'||st.opacity==='0')return false;return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length);}catch(x){return true;}}" +
            "function has(re,t){return re.test(t);}" +
            "function score(t){" +
            "if(!t||t.length<12||t.length>2200)return -9999;" +
            "var d=has(/데이터|\\bdata\\b/i,t),v=has(/음성|통화|\\bvoice\\b|\\bcall\\b/i,t),s=has(/문자|\\bsms\\b/i,t);" +
            "var cats=(d?1:0)+(v?1:0)+(s?1:0);if(cats===0)return -9999;" +
            "var vals=(t.match(/\\d[\\d,.]*\\s*(?:TB|GB|MB|KB|G|M|분|초|건|회|개|%)/gi)||[]).length;" +
            "var strong=has(/사용량|잔여|남은|잔량|제공량|소진|이용량/i,t);var basic=has(/기본제공|무제한/i,t);" +
            "var bad=(t.match(/요금제추천|가입신청|추천상품|특별할인|월\\s*[\\d,]+\\s*원|통신상품|요금제.*월/gi)||[]).length;" +
            "var z=cats*16+Math.min(vals,12)*3+(strong?52:0)+(basic?6:0)+(cats===3?24:0);" +
            "if(has(/사용량조회|사용량 조회/i,t))z+=18;if(has(/데이터\\s*사용량|통화\\s*사용량|음성\\s*사용량|문자\\s*사용량/i,t))z+=22;" +
            "z-=bad*60;z-=Math.floor(t.length/500);return z;}" +
            "var all=document.querySelectorAll('main,section,article,div,li,ul,ol,table,tbody');var c=[];" +
            "for(var i=0;i<all.length;i++){var e=all[i];if(!visible(e))continue;var t=clean(e.innerText);var sc=score(t);if(sc>15)c.push({s:sc,t:t,l:t.length});}" +
            "c.sort(function(a,b){if(b.s!==a.s)return b.s-a.s;return a.l-b.l;});" +
            "var out=[];var seen={};for(var j=0;j<c.length&&out.length<10;j++){var t=c[j].t;var key=t.slice(0,180);if(seen[key])continue;seen[key]=1;out.push('[[EYES_USAGE_BLOCK_'+out.length+']]\\n'+t);}" +
            "var body=clean(document.body?document.body.innerText:'');" +
            "return '[[EYES_URL]]\\n'+location.href+'\\n[[EYES_TITLE]]\\n'+document.title+'\\n'+out.join('\\n')+'\\n[[EYES_BODY]]\\n'+body.slice(0,16000);" +
            "}catch(e){return '[[EYES_ERROR]]\\n'+String(e);}})()";

    private static String decodeJsString(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            if (value.startsWith("\"") && value.endsWith("\"")) {
                value = value.substring(1, value.length() - 1);
            }
            return value.replace("\\n", "\n")
                    .replace("\\r", "\r")
                    .replace("\\t", "\t")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\u003C", "<")
                    .replace("\\u003E", ">");
        } catch (Throwable e) {
            return value;
        }
    }
}

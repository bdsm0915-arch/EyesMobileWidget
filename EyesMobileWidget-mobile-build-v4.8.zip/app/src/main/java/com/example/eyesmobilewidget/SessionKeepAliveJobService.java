package com.example.eyesmobilewidget;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;

/**
 * v4.5 best-effort session keep-alive. Android may defer periodic jobs in Doze, so this cannot
 * defeat a server-enforced absolute expiry, but it greatly reduces idle-session expiry when the
 * device is active and the network is available. No auto-login is attempted in background.
 */
public class SessionKeepAliveJobService extends JobService {
    private static final int JOB_ID = 29072;
    private static final long PERIOD_MS = 15L * 60L * 1000L;

    public static void ensureScheduled(Context context) {
        try {
            Context app = context.getApplicationContext();
            if (UsageEndpointStore.getConfirmed(app) == null) return;
            JobScheduler scheduler = (JobScheduler) app.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (scheduler == null) return;
            if (android.os.Build.VERSION.SDK_INT >= 24 && scheduler.getPendingJob(JOB_ID) != null) return;

            JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(app, SessionKeepAliveJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true)
                    .setPeriodic(PERIOD_MS)
                    .build();
            scheduler.schedule(job);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        Context app = getApplicationContext();
        if (HiddenWebViewRefresher.isRunning() || FastUsageRefresher.isRunning() || FastAutoLogin.isRunning()
                || !FastUsageRefresher.shouldTry(app)) {
            jobFinished(params, false);
            return false;
        }
        FastUsageRefresher.keepAliveAsync(app, (success, detail) -> jobFinished(params, false));
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Learns the real same-origin GET request that carries live usage data.
 *
 * v3.5 tried /mypage/main directly, but EyesMobile fills usage after page load through a
 * separate async request. v3.6 observes those requests without intercepting/changing them,
 * verifies candidates only after a successful WebView refresh, and stores only an endpoint URL
 * that itself can be parsed as usage. No cookie/token values are logged.
 */
public final class UsageEndpointStore {
    private static final String PREF = "eyes_usage_endpoint_v36";
    private static final String KEY_URL = "url";
    private static final String KEY_AT = "verified_at";
    private static final String KEY_FAILS = "fails";
    private static final String KEY_X_REQUESTED_WITH = "x_requested_with";
    private static final String KEY_ACCEPT = "accept";
    private static final String KEY_REFERER = "referer";
    // v4.4: keep a previously verified usage endpoint long enough for direct auto-login after
    // long idle periods. Invalid endpoints are still discarded after repeated non-session failures.
    private static final long MAX_AGE_MS = 30L * 24L * 60L * 60L * 1000L;
    private static final int MAX_OBSERVED = 28;
    private static final int MAX_VERIFY = 10;
    private static final Object LOCK = new Object();
    private static final Map<String, Candidate> OBSERVED = new LinkedHashMap<>();
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final AtomicBoolean VERIFYING = new AtomicBoolean(false);

    private UsageEndpointStore() {}

    public static void beginObservation() {
        synchronized (LOCK) {
            OBSERVED.clear();
        }
    }

    public static void observe(String method, String rawUrl) {
        observe(method, rawUrl, null);
    }

    public static void observe(String method, String rawUrl, Map<String, String> requestHeaders) {
        if (method == null || !"GET".equalsIgnoreCase(method) || rawUrl == null) return;
        try {
            Uri u = Uri.parse(rawUrl);
            String scheme = u.getScheme();
            String host = u.getHost();
            String path = u.getPath();
            if (!"https".equalsIgnoreCase(scheme) || host == null || path == null) return;
            String h = host.toLowerCase(Locale.ROOT);
            if (!(h.equals("eyes.co.kr") || h.endsWith(".eyes.co.kr"))) return;

            String lowerPath = path.toLowerCase(Locale.ROOT);
            if (lowerPath.equals("/mypage/main") || lowerPath.equals("/mypage/main/")) return;
            if (lowerPath.contains("/login") || lowerPath.contains("/logout")) return;
            if (isStatic(lowerPath)) return;

            String full = rawUrl;
            Candidate candidate = new Candidate(full, score(full), safeHeader(requestHeaders, "X-Requested-With"),
                    safeHeader(requestHeaders, "Accept"), safeHeader(requestHeaders, "Referer"));
            synchronized (LOCK) {
                if (OBSERVED.size() >= MAX_OBSERVED && !OBSERVED.containsKey(full)) return;
                Candidate old = OBSERVED.get(full);
                if (old == null || candidate.score >= old.score) OBSERVED.put(full, candidate);
            }
        } catch (Throwable ignored) {
        }
    }

    public static String getConfirmed(Context context) {
        SharedPreferences p = prefs(context);
        long at = p.getLong(KEY_AT, 0L);
        String url = p.getString(KEY_URL, null);
        if (url == null || url.trim().isEmpty()) return null;
        if (at <= 0L || System.currentTimeMillis() - at > MAX_AGE_MS) {
            p.edit().clear().apply();
            return null;
        }
        return url;
    }

    public static boolean hasConfirmed(Context context) {
        return getConfirmed(context) != null;
    }

    public static void noteFastSuccess(Context context, String url) {
        noteFastSuccess(context, url, null, null, null);
    }

    public static void noteFastSuccess(Context context, String url, String xRequestedWith,
                                       String accept, String referer) {
        if (url == null || url.trim().isEmpty()) return;
        SharedPreferences.Editor e = prefs(context).edit()
                .putString(KEY_URL, url)
                .putLong(KEY_AT, System.currentTimeMillis())
                .putInt(KEY_FAILS, 0);
        putOrRemove(e, KEY_X_REQUESTED_WITH, xRequestedWith);
        putOrRemove(e, KEY_ACCEPT, accept);
        putOrRemove(e, KEY_REFERER, referer);
        e.apply();
    }

    public static Map<String, String> getConfirmedHeaders(Context context) {
        Map<String, String> out = new LinkedHashMap<>();
        SharedPreferences p = prefs(context);
        copyIfPresent(out, "X-Requested-With", p.getString(KEY_X_REQUESTED_WITH, null));
        copyIfPresent(out, "Accept", p.getString(KEY_ACCEPT, null));
        copyIfPresent(out, "Referer", p.getString(KEY_REFERER, null));
        return out;
    }

    public static void noteFastFailure(Context context, String detail) {
        if (detail == null) return;
        // Session/login/network failures do not mean the learned endpoint is wrong.
        if (detail.contains("LOGIN") || detail.contains("LOGGED_OUT")
                || detail.contains("TIMEOUT") || detail.contains("NETWORK")) return;
        SharedPreferences p = prefs(context);
        int fails = p.getInt(KEY_FAILS, 0) + 1;
        SharedPreferences.Editor e = p.edit().putInt(KEY_FAILS, fails);
        if (fails >= 3) e.clear();
        e.apply();
    }

    /** Verify observed requests in the background after WebView has already delivered usage. */
    public static void verifyObservedAsync(Context context) {
        final Context app = context.getApplicationContext();
        if (hasConfirmed(app)) return;
        if (!VERIFYING.compareAndSet(false, true)) return;

        final List<Candidate> candidates = snapshotCandidates();
        if (candidates.isEmpty()) {
            VERIFYING.set(false);
            return;
        }
        final String cookies = SessionCookieStore.currentCookieHeader(app, EyesMobileFetcher.MY_PAGE_URL);
        final String ua = SessionCookieStore.getUserAgent(app);
        if (cookies == null || cookies.trim().isEmpty()) {
            VERIFYING.set(false);
            return;
        }

        EXEC.execute(() -> {
            Candidate winner = null;
            int checked = 0;
            for (Candidate c : candidates) {
                if (checked++ >= MAX_VERIFY) break;
                String candidateCookies = SessionCookieStore.currentCookieHeader(app, c.url);
                if (candidateCookies == null || candidateCookies.trim().isEmpty()) candidateCookies = cookies;
                if (fetchUsage(c, candidateCookies, ua) != null) {
                    winner = c;
                    break;
                }
            }
            final Candidate confirmed = winner;
            MAIN.post(() -> {
                if (confirmed != null) noteFastSuccess(app, confirmed.url, confirmed.xRequestedWith,
                        confirmed.accept, confirmed.referer);
                VERIFYING.set(false);
            });
        });
    }

    /** Shared parser/request helper used only for endpoint verification. */
    static UsageData fetchUsage(String endpoint, String cookies, String userAgent) {
        return fetchUsage(new Candidate(endpoint, 0, null, null, null), cookies, userAgent);
    }

    private static UsageData fetchUsage(Candidate candidate, String cookies, String userAgent) {
        String endpoint = candidate == null ? null : candidate.url;
        HttpURLConnection conn = null;
        try {
            URL url = new URL(endpoint);
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(900);
            conn.setReadTimeout(1500);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Cookie", cookies);
            if (userAgent != null && !userAgent.trim().isEmpty()) conn.setRequestProperty("User-Agent", userAgent);
            conn.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en;q=0.7");
            conn.setRequestProperty("Accept", notEmpty(candidate.accept) ? candidate.accept : "application/json,text/plain,text/html,*/*");
            if (notEmpty(candidate.xRequestedWith)) conn.setRequestProperty("X-Requested-With", candidate.xRequestedWith);
            conn.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
            conn.setRequestProperty("Pragma", "no-cache");
            conn.setRequestProperty("Referer", notEmpty(candidate.referer) ? candidate.referer : EyesMobileFetcher.MY_PAGE_URL);
            int code = conn.getResponseCode();
            if (code < 200 || code >= 400) return null;
            String body = readLimited(conn.getInputStream(), 700_000);
            return parseAny(body);
        } catch (Throwable t) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    static UsageData parseAny(String body) {
        if (body == null || body.trim().isEmpty()) return null;
        UsageData data = UsageParser.parse(body);
        if (data != null) return data;

        try {
            String jsonish = body
                    .replaceAll("[{}\\[\\]\"':,]", " ")
                    .replace("\\u00a0", " ")
                    .replaceAll("\\s+", " ")
                    .trim();
            data = UsageParser.parse(jsonish);
            if (data != null) return data;
        } catch (Throwable ignored) {
        }

        try {
            String text;
            if (android.os.Build.VERSION.SDK_INT >= 24) {
                text = Html.fromHtml(body, Html.FROM_HTML_MODE_LEGACY).toString();
            } else {
                text = Html.fromHtml(body).toString();
            }
            return UsageParser.parse(text);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static List<Candidate> snapshotCandidates() {
        List<Candidate> out = new ArrayList<>();
        synchronized (LOCK) {
            out.addAll(OBSERVED.values());
        }
        Collections.sort(out, Comparator.comparingInt((Candidate c) -> c.score).reversed());
        return out;
    }

    private static int score(String url) {
        String s = url.toLowerCase(Locale.ROOT);
        int score = 0;
        if (containsAny(s, "usage", "used", "remain", "quota", "traffic", "balance", "allowance")) score += 50;
        if (containsAny(s, "data", "voice", "call", "sms", "message")) score += 28;
        if (containsAny(s, "/api/", "ajax", "json", "mypage")) score += 18;
        if (s.contains("/member/") || s.contains("auth")) score -= 20;
        return score;
    }

    private static boolean isStatic(String path) {
        return path.matches(".*\\.(?:js|css|png|jpg|jpeg|gif|webp|svg|ico|woff|woff2|ttf|map|mp4|webm)(?:$|\\?.*)")
                || path.contains("/static/") || path.contains("/assets/")
                || path.contains("/images/") || path.contains("/image/")
                || path.contains("/fonts/");
    }

    private static boolean containsAny(String s, String... terms) {
        for (String term : terms) if (s.contains(term)) return true;
        return false;
    }

    private static String readLimited(InputStream in, int maxChars) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[8192];
            int n;
            while ((n = br.read(buf)) >= 0) {
                int remaining = maxChars - sb.length();
                if (remaining <= 0) break;
                sb.append(buf, 0, Math.min(n, remaining));
                if (sb.length() >= maxChars) break;
            }
        }
        return sb.toString();
    }

    private static String safeHeader(Map<String, String> headers, String name) {
        if (headers == null || name == null) return null;
        for (Map.Entry<String, String> e : headers.entrySet()) {
            if (e.getKey() != null && name.equalsIgnoreCase(e.getKey())) {
                String v = e.getValue();
                if (v == null) return null;
                v = v.trim();
                return v.length() > 500 ? v.substring(0, 500) : v;
            }
        }
        return null;
    }

    private static void putOrRemove(SharedPreferences.Editor e, String key, String value) {
        if (notEmpty(value)) e.putString(key, value); else e.remove(key);
    }

    private static void copyIfPresent(Map<String, String> out, String key, String value) {
        if (notEmpty(value)) out.put(key, value);
    }

    private static boolean notEmpty(String value) {
        return value != null && !value.trim().isEmpty();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    private static final class Candidate {
        final String url;
        final int score;
        final String xRequestedWith;
        final String accept;
        final String referer;

        Candidate(String url, int score, String xRequestedWith, String accept, String referer) {
            this.url = url;
            this.score = score;
            this.xRequestedWith = xRequestedWith;
            this.accept = accept;
            this.referer = referer;
        }
    }
}

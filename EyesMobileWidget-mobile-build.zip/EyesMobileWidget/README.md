# EyesMobileWidget

아이즈모바일(`https://www.eyes.co.kr/mypage/main`) 로그인 세션을 이용해 홈 화면에서 데이터/음성/문자 사용량을 보여 주는 4×2 다크 위젯입니다.

## 기능
- 검정색 4×2 홈 화면 위젯
- 데이터 / 음성 / 문자 사용량 표시
- 위젯 새로고침 버튼
- Android AppWidget 30분 주기 갱신 요청
- 앱 내 WebView에서 아이즈모바일 로그인
- 비밀번호를 별도 SharedPreferences에 저장하지 않음
- 로그인 웹 세션 쿠키로 마이페이지 자동 조회 시도
- 웹페이지 구조가 달라 자동 파싱이 실패해도, 앱에서 실제 사용량조회 페이지를 연 뒤 `위젯 갱신` 버튼을 누르면 화면 텍스트를 파싱해 반영

## 빌드
Android Studio에서 이 폴더를 열고 **Build > Build APK(s)** 를 실행합니다.

명령줄에서는 JDK 17 + Android SDK 34가 준비된 상태에서:

```bash
./gradlew assembleDebug
```

APK 위치:
`app/build/outputs/apk/debug/app-debug.apk`

## 첫 사용
1. 앱 실행
2. 아이즈모바일 로그인
3. 마이페이지의 `사용량조회` 화면 열기
4. 상단 `위젯 갱신` 누르기
5. 홈 화면 길게 누르기 > 위젯 > 아이즈모바일 추가

## 참고
아이즈모바일의 로그인 후 HTML/API 구조는 공개 문서가 아니므로 사이트 구조가 변경되면 `UsageParser.java`의 패턴을 조정해야 할 수 있습니다.

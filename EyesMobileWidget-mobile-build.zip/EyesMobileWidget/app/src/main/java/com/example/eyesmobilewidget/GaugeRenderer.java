package com.example.eyesmobilewidget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class GaugeRenderer {
    private static final int PINK = Color.rgb(245,0,115);

    private GaugeRenderer() {}

    public static Bitmap renderGauge(Context context, int usedPercent, String remainingText,
                                     int labelColor, int trackColor) {
        int w = 240;
        int h = 130;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(14f);

        float pad = 28f;
        RectF oval = new RectF(pad, 16f, w - pad, h + 82f);
        p.setColor(trackColor);
        c.drawArc(oval, 180f, 180f, false, p);

        int remaining = Math.max(0, Math.min(100, 100 - usedPercent));
        p.setColor(PINK);
        c.drawArc(oval, 180f, 180f * remaining / 100f, false, p);

        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setColor(labelColor);
        p.setTextSize(22f);
        c.drawText("잔여", w / 2f, 70f, p);

        p.setColor(PINK);
        p.setTextSize(28f);
        String value = (remainingText == null || remainingText.trim().isEmpty()) ? "--" : remainingText;
        c.drawText(value, w / 2f, 104f, p);
        return bmp;
    }

    public static Bitmap renderBodyBackground(Context context, int color) {
        // Use a large source bitmap so RemoteViews fitXY scaling does not blow up
        // the antialiased corner pixels into a white/blurred halo on Samsung launchers.
        int w = 1024;
        int h = 512;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        float r = 22f;
        // Push the top corners above the bitmap so only the bottom corners are rounded.
        c.drawRoundRect(new RectF(0f, -r, w, h), r, r, p);
        return bmp;
    }

    public static String remaining(String used, String total, boolean data) {
        if (total != null && containsAny(total, "기본제공", "무제한", "unlimited")) {
            return total.contains("무제한") ? "무제한" : "기본제공";
        }
        double u = numericToBase(used, data);
        double t = numericToBase(total, data);
        if (u < 0 || t < 0 || t < u) return "--";
        double rem = t - u;
        if (data) return formatData(rem);
        if (containsAny(total, "분", "min", "minute")) return trim(rem) + "분";
        if (containsAny(total, "건", "회", "개")) return trim(rem) + "건";
        return trim(rem);
    }

    public static String caption(String label, String total) {
        if (total == null || total.equals("--")) return label + " --";
        return label + " " + total;
    }

    private static String formatData(double mb) {
        if (mb >= 1024d) {
            double gb = mb / 1024d;
            if (Math.abs(gb - Math.rint(gb)) < 0.005) return String.format(Locale.KOREA, "%.0fGB", gb);
            return String.format(Locale.KOREA, "%.2fGB", gb).replaceAll("0+$", "").replaceAll("\\.$", "");
        }
        return trim(mb) + "MB";
    }

    private static String trim(double n) {
        if (Math.abs(n - Math.rint(n)) < 0.005) return String.format(Locale.KOREA, "%.0f", n);
        return String.format(Locale.KOREA, "%.1f", n).replaceAll("\\.0$", "");
    }

    private static double numericToBase(String value, boolean data) {
        if (value == null) return -1;
        String v = value.replace(",", "").replace(" ", "").toUpperCase(Locale.ROOT);
        Matcher m = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)(GB|MB|KB|G|M|분|초|MINUTE|MIN|건|회|개)?").matcher(v);
        if (!m.find()) return -1;
        double n;
        try { n = Double.parseDouble(m.group(1)); } catch (Exception e) { return -1; }
        String unit = m.group(2) == null ? "" : m.group(2);
        if (data) {
            if (unit.equals("GB") || unit.equals("G")) n *= 1024d;
            else if (unit.equals("KB")) n /= 1024d;
        }
        return n;
    }

    private static boolean containsAny(String text, String... values) {
        if (text == null) return false;
        String lower = text.toLowerCase(Locale.ROOT);
        for (String v : values) if (lower.contains(v.toLowerCase(Locale.ROOT))) return true;
        return false;
    }
}

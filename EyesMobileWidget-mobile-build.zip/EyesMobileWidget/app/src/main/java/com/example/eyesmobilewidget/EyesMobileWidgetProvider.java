package com.example.eyesmobilewidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EyesMobileWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.example.eyesmobilewidget.ACTION_REFRESH";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int id : appWidgetIds) updateWidget(context, appWidgetManager, id);
        refreshAsync(context, goAsync());
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            WidgetStorage.setStatus(context, "새로고침 중…");
            updateAll(context);
            refreshAsync(context, goAsync());
        }
    }

    private static void refreshAsync(Context context, PendingResult pendingResult) {
        Context app = context.getApplicationContext();
        final PendingResult result = pendingResult;
        new Thread(() -> {
            try {
                EyesMobileFetcher.refresh(app);
                updateAll(app);
            } finally {
                if (result != null) result.finish();
            }
        }, "EyesMobileRefresh").start();
    }

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, EyesMobileWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        UsageData d = WidgetStorage.load(context);
        RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.eyes_mobile_widget);

        rv.setTextViewText(R.id.data_value, d.dataUsed + " / " + d.dataTotal);
        rv.setTextViewText(R.id.voice_value, d.voiceUsed + " / " + d.voiceTotal);
        rv.setTextViewText(R.id.sms_value, d.smsUsed + " / " + d.smsTotal);

        rv.setProgressBar(R.id.data_progress, 100, d.dataPercent, false);
        rv.setProgressBar(R.id.voice_progress, 100, d.voicePercent, false);
        rv.setProgressBar(R.id.sms_progress, 100, d.smsPercent, false);

        rv.setTextViewText(R.id.data_percent, d.dataPercent > 0 ? d.dataPercent + "% 사용" : "--");
        rv.setTextViewText(R.id.voice_percent, d.voicePercent > 0 ? d.voicePercent + "% 사용" : "--");
        rv.setTextViewText(R.id.sms_percent, d.smsPercent > 0 ? d.smsPercent + "% 사용" : "--");

        if (d.updatedAt > 0) {
            String time = new SimpleDateFormat("M월 d일 HH:mm", Locale.KOREA).format(new Date(d.updatedAt));
            rv.setTextViewText(R.id.last_updated, time + " 기준");
        } else {
            rv.setTextViewText(R.id.last_updated, "로그인 필요");
        }
        rv.setTextViewText(R.id.status_text, WidgetStorage.getStatus(context));

        Intent refresh = new Intent(context, EyesMobileWidgetProvider.class)
                .setAction(ACTION_REFRESH)
                .setPackage(context.getPackageName());
        PendingIntent refreshPi = PendingIntent.getBroadcast(
                context, 1001, refresh, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.refresh_button, refreshPi);

        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(
                context, 1002, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.widget_root, openPi);

        manager.updateAppWidget(id, rv);
    }
}

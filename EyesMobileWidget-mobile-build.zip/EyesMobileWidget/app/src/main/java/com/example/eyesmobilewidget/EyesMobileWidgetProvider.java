package com.example.eyesmobilewidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EyesMobileWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.example.eyesmobilewidget.ACTION_REFRESH";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int id : appWidgetIds) updateWidget(context, appWidgetManager, id);
        refreshAsync(context, goAsync());
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            WidgetStorage.setStatus(context, "새로고침 중…");
            updateAll(context);
            refreshAsync(context, goAsync());
        }
    }

    private static void refreshAsync(Context context, PendingResult pendingResult) {
        Context app = context.getApplicationContext();
        final PendingResult result = pendingResult;
        new Thread(() -> {
            try {
                EyesMobileFetcher.refresh(app);
                updateAll(app);
            } finally {
                if (result != null) result.finish();
            }
        }, "EyesMobileRefresh").start();
    }

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, EyesMobileWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        UsageData d = WidgetStorage.load(context);
        RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.eyes_mobile_widget);

        int textColor = WidgetAppearance.getTextColor(context);
        int trackColor = WidgetAppearance.getTrackColor(context);
        int bodyColor = WidgetAppearance.getBodyColor(context);
        int statusColor = withAlpha(textColor, 165);

        String dataRemaining = GaugeRenderer.remaining(d.dataUsed, d.dataTotal, true);
        String voiceRemaining = GaugeRenderer.remaining(d.voiceUsed, d.voiceTotal, false);
        String smsRemaining = GaugeRenderer.remaining(d.smsUsed, d.smsTotal, false);

        Bitmap dataGauge = GaugeRenderer.renderGauge(context, d.dataPercent, dataRemaining, textColor, trackColor);
        Bitmap voiceGauge = GaugeRenderer.renderGauge(context, d.voicePercent, voiceRemaining, textColor, trackColor);
        Bitmap smsGauge = GaugeRenderer.renderGauge(context, d.smsPercent, smsRemaining, textColor, trackColor);
        Bitmap body = GaugeRenderer.renderBodyBackground(context, bodyColor);

        rv.setImageViewBitmap(R.id.data_gauge, dataGauge);
        rv.setImageViewBitmap(R.id.voice_gauge, voiceGauge);
        rv.setImageViewBitmap(R.id.sms_gauge, smsGauge);
        rv.setImageViewBitmap(R.id.body_background, body);

        rv.setTextViewText(R.id.data_caption, GaugeRenderer.caption("데이터", d.dataTotal));
        rv.setTextViewText(R.id.voice_caption, GaugeRenderer.caption("음성", d.voiceTotal));
        rv.setTextViewText(R.id.sms_caption, GaugeRenderer.caption("문자", d.smsTotal));
        rv.setTextColor(R.id.data_caption, textColor);
        rv.setTextColor(R.id.voice_caption, textColor);
        rv.setTextColor(R.id.sms_caption, textColor);
        rv.setTextColor(R.id.status_text, statusColor);

        if (d.updatedAt > 0) {
            String time = new SimpleDateFormat("M/d HH:mm", Locale.KOREA).format(new Date(d.updatedAt));
            rv.setTextViewText(R.id.last_updated, time);
        } else {
            rv.setTextViewText(R.id.last_updated, "로그인 필요");
        }
        String status = WidgetStorage.getStatus(context);
        // The update time is already shown in the pink header. Hide the redundant
        // "최신 사용량" footer and only surface actionable states/errors.
        rv.setTextViewText(R.id.status_text, "최신 사용량".equals(status) ? "" : status);

        Intent refresh = new Intent(context, EyesMobileWidgetProvider.class)
                .setAction(ACTION_REFRESH)
                .setPackage(context.getPackageName());
        PendingIntent refreshPi = PendingIntent.getBroadcast(
                context, 1001, refresh, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.refresh_button, refreshPi);

        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(
                context, 1002, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.widget_root, openPi);
        rv.setOnClickPendingIntent(R.id.settings_button, openPi);

        manager.updateAppWidget(id, rv);
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }
}

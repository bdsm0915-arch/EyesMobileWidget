package com.example.eyesmobilewidget;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), dp(8), dp(8), dp(8));
        top.setBackgroundColor(Color.rgb(16,16,16));

        TextView title = new TextView(this);
        title.setText("아이즈모바일 사용량 위젯");
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));

        Button refresh = new Button(this);
        refresh.setText("위젯 갱신");
        refresh.setAllCaps(false);
        refresh.setOnClickListener(v -> capturePageAndRefresh());
        top.addView(refresh, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
        root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setText("아이즈모바일에 로그인한 뒤 사용량조회 화면을 열어 주세요. 로그인 정보는 앱이 따로 저장하지 않습니다.");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(12);
        status.setPadding(dp(14), dp(9), dp(14), dp(9));
        root.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setUserAgentString(settings.getUserAgentString() + " EyesMobileWidget/1.0");

        android.webkit.CookieManager.getInstance().setAcceptCookie(true);
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new PageBridge(), "EyesWidgetBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                status.setText("페이지 로드 완료 · 로그인 후 '사용량조회' 화면에서 위젯 갱신을 누르세요.");
                handler.postDelayed(MainActivity.this::capturePageText, 1200);
            }
        });

        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);
        webView.loadUrl(EyesMobileFetcher.MY_PAGE_URL);
    }

    private void capturePageAndRefresh() {
        status.setText("현재 페이지에서 사용량을 읽는 중…");
        capturePageText();
        new Thread(() -> {
            boolean ok = EyesMobileFetcher.refresh(getApplicationContext());
            EyesMobileWidgetProvider.updateAll(getApplicationContext());
            runOnUiThread(() -> {
                if (ok) status.setText("위젯을 최신 사용량으로 갱신했습니다.");
                else status.setText("웹 세션 자동 조회가 안 되면, 사용량조회 화면을 띄운 상태에서 다시 '위젯 갱신'을 눌러 주세요.");
            });
        }, "ManualRefresh").start();
    }

    private void capturePageText() {
        if (webView == null) return;
        webView.evaluateJavascript(
                "(function(){try{return document.body ? document.body.innerText : '';}catch(e){return '';}})()",
                value -> {
                    String text = decodeJsString(value);
                    if (text != null && !text.isEmpty()) handlePageText(text);
                });
    }

    private void handlePageText(String text) {
        UsageData data = UsageParser.parse(text);
        if (data != null) {
            WidgetStorage.save(getApplicationContext(), data);
            EyesMobileWidgetProvider.updateAll(getApplicationContext());
            status.setText("사용량을 읽어 위젯에 반영했습니다.");
        }
    }

    private String decodeJsString(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            if (value.startsWith("\"") && value.endsWith("\"")) value = value.substring(1, value.length() - 1);
            return value.replace("\\n", "\n")
                    .replace("\\r", "\r")
                    .replace("\\t", "\t")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\u003C", "<")
                    .replace("\\u003E", ">");
        } catch (Exception e) {
            return value;
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("EyesWidgetBridge");
            webView.destroy();
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private final class PageBridge {
        @JavascriptInterface
        public void onPageText(String text) {
            runOnUiThread(() -> handlePageText(text));
        }
    }
}

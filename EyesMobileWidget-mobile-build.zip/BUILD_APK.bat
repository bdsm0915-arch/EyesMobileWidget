@echo off
setlocal
cd /d "%~dp0"
echo [EyesMobileWidget] APK build starting...
call gradlew.bat assembleDebug
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Open this folder in Android Studio and make sure Android SDK 34 / JDK 17 are installed.
  pause
  exit /b 1
)
copy /Y "app\build\outputs\apk\debug\app-debug.apk" "EyesMobileWidget-debug.apk" >nul
echo.
echo DONE: %CD%\EyesMobileWidget-debug.apk
pause

# Mobile build v2.5

Fix: data remaining/used mapping.

Expected example:
- remaining: 146.83 GB
- used: 13.17 GB
- total: 160.00 GB

The parser no longer treats `사용내역` or `사용량조회` as the actual `사용량` field.

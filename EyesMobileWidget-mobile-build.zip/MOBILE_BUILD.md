# 휴대폰만으로 APK 만들기

이 프로젝트에는 GitHub Actions 자동 빌드 파일이 포함되어 있습니다.

## 가장 쉬운 방법
1. ChatGPT에서 GitHub 연결을 허용합니다.
2. 이 프로젝트를 GitHub 저장소에 올립니다.
3. 저장소의 **Actions > Build EyesMobileWidget APK > Run workflow**를 실행합니다.
4. 빌드가 끝나면 **EyesMobileWidget-debug-apk** 아티팩트를 다운로드합니다.
5. 압축을 풀어 `EyesMobileWidget-debug.apk`를 Android 폰에 설치합니다.

PC나 Android Studio는 필요하지 않습니다.

## 빌드 설정
- JDK 17
- Gradle 8.2.1
- Android Gradle Plugin 8.2.2
- compileSdk / targetSdk 34
- minSdk 24

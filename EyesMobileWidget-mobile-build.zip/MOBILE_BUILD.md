# EyesMobileWidget v3.2 mobile build

GitHub Actions에서 `EyesMobileWidget-mobile-build.zip`을 빌드하세요.

v3.2는 오래된 세션에서 자동로그인 판정을 앞당기고 post-login 확인 대기를 줄여 장시간 미사용 후 첫 새로고침 시간을 단축한 버전입니다.

# EyesMobileWidget v3.0 mobile build

핵심 수정:
- 위젯 새로고침 장시간 작업을 BroadcastReceiver/goAsync에서 JobService로 이동
- Android가 백그라운드 BroadcastReceiver 프로세스를 정리해 새로고침이 중간에서 멈추는 문제 방지
- 자동 로그인 -> 새 세션 -> MyPage -> 사용량 비동기 응답 -> 위젯 저장까지 한 작업으로 유지
- /mypage/main을 사용량조회 링크 때문에 반복 재로딩하지 않음
- 사용량 DOM 비동기 응답 대기 시간을 확대

GitHub Actions에서 app-debug.apk를 빌드하세요.

# Mobile build v2.4

Upload this ZIP to the repository as `EyesMobileWidget-mobile-build.zip`. GitHub Actions builds the debug APK.

After installation:
1. Open the app and confirm auto-login is still configured.
2. Log in once if needed.
3. Press the widget refresh button.
4. The app stays closed; an off-screen WebView loads a no-cache MyPage and automatically follows `사용량조회`.
5. The widget shows either `사용량 갱신됨` or `조회 완료 · 값 변동 없음`.

v2.4 intentionally rejects generic plan recommendation numbers such as 10GB/15GB unless they are inside a real usage context.

# EyesMobileWidget v7.6 mobile build

- Normal data/voice/SMS parsing is isolated from supplementary-call parsing.
- A bare `부가통화 300분` is treated as allowance, never as used time.
- Supplementary-call usage defaults to `0초` when no usage is reported.
- Supplementary-call total is fixed at `300분 제공`.
- Supplementary-call gauge percent is recalculated from used duration / 300 minutes.
- Old v7.0-v7.5 supplementary-call cache is discarded once on upgrade.
- Removes the fake 78% gauge fallback; unknown tiny non-zero usage gets only a 1% marker.


## v7.9
- Widget typography changed from monospace to regular upright sans-serif.
- Removed bold styling from widget labels/captions so Korean text appears as a clean regular typeface.
- Gauge text now uses regular sans-serif instead of monospace bold.

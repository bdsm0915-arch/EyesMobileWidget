# EyesMobileWidget mobile build

Version 5.5

Changes:
- Automatic refresh runs through a background-only direct usage request instead of the manual WebView JobService path.
- One silent direct HTTP auto-login attempt is allowed when the server clearly reports an expired session.
- A short partial wake lock keeps the CPU awake while the automatic network request finishes.
- Exact alarms are used when Android grants Alarm & reminders access; otherwise the previous idle-safe inexact alarm remains as fallback.
- Existing choices remain: manual, 10m, 30m, 1h, 2h, 12h, 24h.

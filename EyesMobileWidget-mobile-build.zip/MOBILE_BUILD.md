
## v5.4
- 설정에 위젯 자동 갱신 주기 추가: 수동 / 10분 / 30분 / 1시간 / 2시간 / 12시간 / 24시간.
- 선택한 주기는 앱 재시작/재부팅 후에도 유지되며 부팅 후 자동으로 다시 예약됩니다.
- 자동 갱신은 백그라운드 JobService를 사용하며 Android 절전 모드에서는 선택 시간보다 늦게 실행될 수 있습니다.
- 수동 새로고침과 v5.3의 실제 WebView 자동로그인/팝업 억제 동작은 그대로 유지합니다.

v4.7 refresh target update

- Keep the existing logged-in fast path unchanged.
- Expired-session recovery target: roughly 7 seconds when the site responds normally.
- HTTP auto-login gets a short 1.25 s opportunistic window while hidden WebView is pre-warmed in parallel.
- Stale-session login-form probe starts earlier.
- Post-login polling is tightened and the full refresh recovery guard is 8.2 s instead of 24 s.
- No new settings, diagnostics, or UI controls were added.

v4.6 speed update

- No settings/UI changes.
- Preserves the existing logged-in fast refresh path.
- Expired-session recovery now pre-warms the hidden WebView in parallel with a 1-second opportunistic HTTP auto-login.
- The two login paths do not submit credentials simultaneously; if HTTP fails, the already-loaded WebView continues immediately.
- Off-screen login and post-login probes use shorter waits to target roughly the 7-second range when network/server response is normal.

---

v4.5: fast-login hard budget + best-effort 15-minute session keep-alive.

# v4.2
Refresh latency optimization: parallel direct API/WebView race, tighter DOM success probes, and more accurate learned API request replay.

# v3.8 모바일 빌드

위젯 상단 아이즈모바일 워드마크를 홈페이지 로고 형태로 교체. 기존 기능 유지.

# Mobile build v3.6

v3.6은 `/mypage/main` HTML 직접 조회를 버리고, 정상 WebView 조회 중 실제 사용량을 반환하는 same-origin GET 요청을 학습/검증합니다. 확인된 엔드포인트가 생기면 다음 위젯 새로고침부터 직접 API를 먼저 호출하고, 실패하거나 650ms 안에 끝나지 않으면 hidden WebView로 자동 폴백합니다. 상태줄에는 실제 소요시간과 `빠른조회`/`웹조회`가 표시됩니다.

# Mobile build v3.5

v3.5는 최근 검증된 로그인 세션에서 direct HTTP fast path와 기존 hidden WebView fallback을 병렬로 시작합니다. HTTP에서 사용량 파싱이 먼저 성공하면 hidden WebView를 즉시 취소하고 위젯을 갱신합니다. HTTP가 실패해도 WebView는 이미 실행 중이라 기존 새로고침 시간 앞에 별도 대기시간을 추가하지 않습니다. 20분 이상 지난 세션은 direct path를 생략하고 기존 자동로그인 흐름으로 바로 갑니다.


## v4.0
- Widget refresh recovery: when usage DOM stays empty and login expiry is not explicit, probe the off-screen login UI once and resume auto-login/usage flow if needed.
- Preserves v3.9 logo/tagline spacing.


## v4.1
- 위젯 상태 문구 간소화: 조회 중… / 업데이트 완료 / 로그인 필요 / 조회 실패만 표시
- 값 변동 없음, 소요 시간, 웹조회/빠른조회 등 내부 진단 문구를 위젯에서 제거


## v4.4 fast auto-login path

- If the learned usage endpoint reports an expired/missing session and encrypted auto-login credentials exist, the widget first tries a direct same-origin HTTP login instead of immediately launching the hidden WebView.
- The login page is fetched fresh so hidden CSRF form values are not persisted. Credentials are still read only from `SecureCredentialStore` (Android Keystore backed).
- Session cookies/credentials are never forwarded outside `eyes.co.kr`; external SSO/OTP/CAPTCHA flows fall back to the existing hidden WebView path.
- After the HTTP login creates a fresh session, the learned usage endpoint is called immediately and the widget is updated in the same refresh tap.
- If the direct login form cannot be safely reproduced, v4.4 falls back to the existing WebView auto-login rather than guessing.

## v4.3 speed path
- User refresh first tries the learned direct usage endpoint immediately without JobScheduler.
- Hidden WebView is scheduled only after that direct request fails.
- MyPage no longer uses a unique cache-busting URL on every refresh.
- Direct HTTP timeout is bounded more tightly for faster fallback.

# EyesMobileWidget v3.1 mobile build

GitHub Actions로 `EyesMobileWidget-mobile-build.zip`을 빌드합니다.

v3.1은 v3.0의 로그인/JobService 안정화 구조를 유지하면서 WebView 캐시 및 대기/폴링 간격을 최적화해 새로고침 체감 속도를 줄인 버전입니다.

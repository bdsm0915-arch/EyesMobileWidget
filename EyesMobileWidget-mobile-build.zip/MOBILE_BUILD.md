# Mobile build package - v2.6

GitHub 저장소의 `EyesMobileWidget-mobile-build.zip` 파일을 이 패키지로 교체하면 Actions에서 debug APK를 빌드합니다.

v2.6 변경사항:
- stale cookie snapshot restore 제거
- WebSessionStateStore restore 제거
- login layer 자동 오픈 + visible login form 자동 입력/submit
- 만료된 서버 세션은 보존하지 않고 새 로그인 세션 생성
- v2.5 사용량 파서 수정 유지

# Mobile build v2.3

Upload this ZIP to the repository as `EyesMobileWidget-mobile-build.zip`. GitHub Actions builds the debug APK.

After installation:
1. Open the app.
2. Tap `자동 로그인`.
3. Enter the EyesMobile login ID/account and password once.
4. Tap `암호화 저장`.
5. Log in normally once if the web page is currently logged out.

When the server expires the session later, the app/widget refresh tries encrypted auto-login automatically.

# EyesMobileWidget Mobile Build

Version 6.8

- Auto refresh intervals: manual / 5m / 10m / 30m / 1h / 2h / 12h / 24h
- Captures the actual EyesMobile usage fetch/XHR response before DOM paint
- Learns replayable GET/POST request recipe including request body and required headers
- Uses the learned recipe for reliable silent background refresh
- Keeps WebView fallback and existing manual refresh behavior


Build fix: enabled AndroidX (`android.useAndroidX=true`) for androidx.webkit dependency.

## v6.8 login reliability
- Long-idle age is now only a hint; the app no longer deletes live EyesMobile cookies before proving the session is actually logged out.
- Logged-out detection uses the currently visible login UI marker instead of hidden login/password dialogs that always exist in the page DOM.
- Auto-login finds the visible email/password/button across the whole login dialog, including the current `아이디(이메일)` UI.
- Attached manual auto-login submits with a trusted Android-native tap after credentials are filled.
- Only after a real login attempt fails does the hard retry clear stale cookies/WebStorage, while native encrypted credentials remain untouched.




## v6.8 post-login fix
- Attached/manual auto-login uses the Android-native touch path as the primary submit action after credentials are filled.
- Native tap now scrolls first, waits for WebView layout, re-measures the button, then taps its center; this avoids stale coordinates and social-login mis-taps.
- The refresher no longer reloads MyPage while the visible login UI is still present, so an AJAX login request cannot be cancelled by our own recovery navigation.
- Login success no longer requires the URL to leave `/login`; disappearance of the visible login UI on a usable document is enough to continue to MyPage.
- One delayed second native tap is allowed only if the first trusted tap produced no transition; no Enter key is synthesized.

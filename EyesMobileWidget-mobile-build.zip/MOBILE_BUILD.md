# EyesMobileWidget Mobile Build

Version 7.0

- Auto refresh intervals: manual / 5m / 10m / 30m / 1h / 2h / 12h / 24h
- Captures the actual EyesMobile usage fetch/XHR response before DOM paint
- Learns replayable GET/POST request recipe including request body and required headers
- Uses the learned recipe for reliable silent background refresh
- Keeps WebView fallback and existing manual refresh behavior


Build fix: enabled AndroidX (`android.useAndroidX=true`) for androidx.webkit dependency.

## v6.8 login reliability
- Long-idle age is now only a hint; the app no longer deletes live EyesMobile cookies before proving the session is actually logged out.
- Logged-out detection uses the currently visible login UI marker instead of hidden login/password dialogs that always exist in the page DOM.
- Auto-login finds the visible email/password/button across the whole login dialog, including the current `아이디(이메일)` UI.
- Attached manual auto-login submits with a trusted Android-native tap after credentials are filled.
- Only after a real login attempt fails does the hard retry clear stale cookies/WebStorage, while native encrypted credentials remain untouched.




## v6.8 post-login fix
- Attached/manual auto-login uses the Android-native touch path as the primary submit action after credentials are filled.
- Native tap now scrolls first, waits for WebView layout, re-measures the button, then taps its center; this avoids stale coordinates and social-login mis-taps.
- The refresher no longer reloads MyPage while the visible login UI is still present, so an AJAX login request cannot be cancelled by our own recovery navigation.
- Login success no longer requires the URL to leave `/login`; disappearance of the visible login UI on a usable document is enough to continue to MyPage.
- One delayed second native tap is allowed only if the first trusted tap produced no transition; no Enter key is synthesized.


## v7.0 additional-call display
- Adds a fourth widget card for 부가통화 (including 영상통화/부가통화 labels).
- Parses used/total supplementary call minutes separately from normal voice calls.
- Prevents the word 통화 inside 부가통화 from being mistaken for the normal voice category.
- Stores supplementary-call usage for manual and automatic refreshes and shows it in the settings preview.

## v7.1
- 위젯 카드 순서를 데이터 / 음성 / 부가통화 / 문자로 변경
- 게이지 중앙 사용량/잔여량 숫자 글씨 크기 확대

## v7.2
- 부가통화 총 제공량 인식 강화: `사용 / 총량`, `잔여 / 제공량`, `기본 제공` 문구를 모두 처리
- 진행 게이지의 `aria-valuenow/aria-valuemax`, progress/meter value/max에만 총량이 있는 경우도 수집
- 사용량과 퍼센트만 제공되면 가능한 경우 총 제공량을 역산


## v7.3
- 부가통화 총량 2차 탐색: 사용량 카드 밖의 요금제/혜택/기본제공 영역에서도 총 제공량을 찾음
- DOM의 aria-label/title/data-total/data-max 및 부가통화 주변 상위 영역을 별도 힌트로 수집
- 총량을 실제로 확인할 수 없는 경우 `총량 확인 필요` 대신 `사용량`으로 표시하여 현재 사용량은 정상 노출

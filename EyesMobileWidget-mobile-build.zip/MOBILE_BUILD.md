# EyesMobileWidget Mobile Build

Version 6.7

- Auto refresh intervals: manual / 5m / 10m / 30m / 1h / 2h / 12h / 24h
- Captures the actual EyesMobile usage fetch/XHR response before DOM paint
- Learns replayable GET/POST request recipe including request body and required headers
- Uses the learned recipe for reliable silent background refresh
- Keeps WebView fallback and existing manual refresh behavior


Build fix: enabled AndroidX (`android.useAndroidX=true`) for androidx.webkit dependency.

## v6.7 login reliability
- Long-idle age is now only a hint; the app no longer deletes live EyesMobile cookies before proving the session is actually logged out.
- Logged-out detection uses the currently visible login UI marker instead of hidden login/password dialogs that always exist in the page DOM.
- Auto-login finds the visible email/password/button across the whole login dialog, including the current `아이디(이메일)` UI.
- If a JavaScript click is ignored, an attached manual refresh gets one Android-native Enter submit fallback.
- Only after a real login attempt fails does the hard retry clear stale cookies/WebStorage, while native encrypted credentials remain untouched.


v6.7: Removed KEYCODE_ENTER login fallback. If EyesMobile ignores synthetic JS click, the attached WebView now resolves the visible login button and dispatches one native touch to that button. This prevents Enter from being misrouted to search/external apps such as Naver.

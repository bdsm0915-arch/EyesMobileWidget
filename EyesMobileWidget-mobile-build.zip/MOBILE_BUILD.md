# EyesMobileWidget Mobile Build

Version 6.4

- Auto refresh intervals: manual / 5m / 10m / 30m / 1h / 2h / 12h / 24h
- Captures the actual EyesMobile usage fetch/XHR response before DOM paint
- Learns replayable GET/POST request recipe including request body and required headers
- Uses the learned recipe for reliable silent background refresh
- Keeps WebView fallback and existing manual refresh behavior


Build fix: enabled AndroidX (`android.useAndroidX=true`) for androidx.webkit dependency.

## v6.4 login reliability
- Auto-login is now two-phase: fill credentials, wait for site state/validation, then submit only when values are still present and the login control is enabled.
- Long-idle recovery clears stale browser session state and bootstraps a fresh login from the public EyesMobile home page rather than resubmitting inside a stale MyPage document.
- One clean retry is allowed when the first login UI attempt does not submit; authenticated usage is still required before success is accepted.
- Post-login recovery window increased to handle slow session rotation without immediately declaring failure.

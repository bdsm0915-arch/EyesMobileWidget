# EyesMobileWidget v2.2

Login persistence hardening:
- backs up cookies from root and exact MyPage paths
- restores missing cookie names even when unrelated cookies still exist
- persists WebView sessionStorage/localStorage after confirmed login
- restores Web Storage before opening MyPage
- flushes WebView cookies on lifecycle transitions
- silent inexact keep-alive approximately every 20 minutes
- widget refresh stays off-screen and does not open MainActivity

Build with GitHub Actions using `.github/workflows/build-apk.yml`.

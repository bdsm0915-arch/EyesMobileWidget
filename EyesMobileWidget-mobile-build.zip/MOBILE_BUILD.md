# EyesMobileWidget mobile build

Version 5.9

Changes:
- Adds 5-minute automatic refresh choice: manual / 5m / 10m / 30m / 1h / 2h / 12h / 24h.
- Keeps AlarmManager + JobScheduler dual scheduling from v5.6/v5.7.
- Fixes intermittent v5.8 `WEB_NO_UPDATE|NO_ENDPOINT` cycles by giving silent background WebView refresh more time for EyesMobile's async usage request.
- If a recently verified session gets no DOM update, waits briefly and retries once with a fresh off-screen WebView instead of immediately failing.
- Extends the auto-refresh wake lock to cover that one retry.
- Makes background endpoint verification less aggressive on timeouts so a successful WebView cycle has a better chance to learn the real usage endpoint for later fast refreshes.
- Manual refresh timing/path is kept unchanged.

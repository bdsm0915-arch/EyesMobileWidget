# EyesMobileWidget Mobile Build

Version 6.2

- Auto refresh intervals: manual / 5m / 10m / 30m / 1h / 2h / 12h / 24h
- Captures the actual EyesMobile usage fetch/XHR response before DOM paint
- Learns replayable GET/POST request recipe including request body and required headers
- Uses the learned recipe for reliable silent background refresh
- Keeps WebView fallback and existing manual refresh behavior


Build fix: enabled AndroidX (`android.useAndroidX=true`) for androidx.webkit dependency.

# EyesMobileWidget v2.8 mobile build

핵심 수정:
- 위젯 ↻ 새로고침의 숨은 WebView와 설정 화면 WebView의 로그인 동작을 맞춤
- 숨은 WebView에 WebChromeClient 추가
- 화면에 붙지 않은 WebView도 1080x1920으로 measure/layout하여 로그인 DOM 컨트롤을 정상 인식
- AutoLoginHelper에 off-screen 모드 추가: CSS로 숨겨진 요소는 제외하되 0x0 화면 좌표만으로 로그인 UI를 실패 처리하지 않음
- 세션 만료 감지 → 자동 로그인 → 새 세션 안정화 대기 → 사용량 페이지 재조회 → 위젯 갱신
- 자동 로그인 단계가 위젯 상태 문구에 표시됨

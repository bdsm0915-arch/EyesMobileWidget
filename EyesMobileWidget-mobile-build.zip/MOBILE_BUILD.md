# Mobile build v3.5

v3.5는 최근 검증된 로그인 세션에서 direct HTTP fast path와 기존 hidden WebView fallback을 병렬로 시작합니다. HTTP에서 사용량 파싱이 먼저 성공하면 hidden WebView를 즉시 취소하고 위젯을 갱신합니다. HTTP가 실패해도 WebView는 이미 실행 중이라 기존 새로고침 시간 앞에 별도 대기시간을 추가하지 않습니다. 20분 이상 지난 세션은 direct path를 생략하고 기존 자동로그인 흐름으로 바로 갑니다.

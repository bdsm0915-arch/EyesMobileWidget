# EyesMobileWidget v7.5 mobile build

- Restores the exact v7.1 usage parser/DOM snapshot for data, voice and SMS.
- Supplementary-call allowance is fixed only at storage/render time: 300 minutes.
- Widget caption always shows `300분 제공` for supplementary calls.
- Cached supplementary-call totals from v7.2-v7.4 are repaired on load.
- One normal refresh is scheduled after package replacement to replace stale v7.3/v7.4 cached data with the restored parser output.

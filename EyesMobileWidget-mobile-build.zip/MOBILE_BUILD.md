# EyesMobileWidget mobile build

Version 5.7

Changes:
- Fixes a scheduling bug where reopening the app/settings could restart the selected countdown.
- Keeps AlarmManager + JobScheduler dual scheduling, but does not re-arm needlessly on every resume/redraw.
- Adds a background-specific network profile with longer timeouts and one retry for cold radio/network wakeups.
- Gives background HTTP auto-login a larger time budget than the manual fast path.
- Adds a compact auto-refresh status line showing the next scheduled time and the most recent trigger/result.
- Existing choices remain: manual, 10m, 30m, 1h, 2h, 12h, 24h.

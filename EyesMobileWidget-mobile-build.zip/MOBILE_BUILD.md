# v3.8 모바일 빌드

위젯 상단 아이즈모바일 워드마크를 홈페이지 로고 형태로 교체. 기존 기능 유지.

# Mobile build v3.6

v3.6은 `/mypage/main` HTML 직접 조회를 버리고, 정상 WebView 조회 중 실제 사용량을 반환하는 same-origin GET 요청을 학습/검증합니다. 확인된 엔드포인트가 생기면 다음 위젯 새로고침부터 직접 API를 먼저 호출하고, 실패하거나 650ms 안에 끝나지 않으면 hidden WebView로 자동 폴백합니다. 상태줄에는 실제 소요시간과 `빠른조회`/`웹조회`가 표시됩니다.

# Mobile build v3.5

v3.5는 최근 검증된 로그인 세션에서 direct HTTP fast path와 기존 hidden WebView fallback을 병렬로 시작합니다. HTTP에서 사용량 파싱이 먼저 성공하면 hidden WebView를 즉시 취소하고 위젯을 갱신합니다. HTTP가 실패해도 WebView는 이미 실행 중이라 기존 새로고침 시간 앞에 별도 대기시간을 추가하지 않습니다. 20분 이상 지난 세션은 direct path를 생략하고 기존 자동로그인 흐름으로 바로 갑니다.


## v4.0
- Widget refresh recovery: when usage DOM stays empty and login expiry is not explicit, probe the off-screen login UI once and resume auto-login/usage flow if needed.
- Preserves v3.9 logo/tagline spacing.

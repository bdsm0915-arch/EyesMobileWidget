# EyesMobileWidget v3.4 mobile build

GitHub Actions에서 `EyesMobileWidget-mobile-build.zip`을 빌드하세요.

v3.4는 1분 미만 통화 사용량과 분+초 조합을 정확히 처리합니다. `0분 35초`를 `0분`으로 잘라 저장/표시하던 문제를 수정해 `35초`, `1분 20초`처럼 초 단위까지 위젯에 반영합니다. v3.3의 정상 세션 빠른 새로고침 경로는 그대로 유지합니다.

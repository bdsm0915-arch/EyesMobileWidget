# EyesMobileWidget v3.3 mobile build

GitHub Actions에서 `EyesMobileWidget-mobile-build.zip`을 빌드하세요.

v3.3은 로그인 세션이 살아있는 정상 새로고침에서 페이지 전체 완료를 기다리지 않고 사용량 DOM이 준비되는 즉시 파싱하는 fast path를 추가한 버전입니다. 이미지 로딩도 차단해 체감 갱신 시간을 줄입니다.

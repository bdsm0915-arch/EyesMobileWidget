
## v5.4
- 설정에 위젯 자동 갱신 주기 추가: 수동 / 10분 / 30분 / 1시간 / 2시간 / 12시간 / 24시간.
- 선택한 주기는 앱 재시작/재부팅 후에도 유지되며 부팅 후 자동으로 다시 예약됩니다.
- 자동 갱신은 백그라운드 JobService를 사용하며 Android 절전 모드에서는 선택 시간보다 늦게 실행될 수 있습니다.
- 수동 새로고침과 v5.3의 실제 WebView 자동로그인/팝업 억제 동작은 그대로 유지합니다.

v4.7 refresh target update

- Keep the existing logged-in fast path unchanged.
- Expired-session recovery target: roughly 7 seconds when the site responds normally.
- HTTP auto-login gets a short 1.25 s opportunistic window while hidden WebView is pre-warmed in parallel.
- Stale-session login-form probe starts earlier.
- Post-login polling is tightened and the full refresh recovery guard is 8.2 s instead of 24 s.
- No new settings, diagnostics, or UI controls were added.

v4.6 speed update

- No settings/UI changes.
- Preserves the existing logged-in fast refresh path.
- Expired-session recovery now pre-warms the hidden WebView in parallel with a 1-second opportunistic HTTP auto-login.
- The two login paths do not submit credentials simultaneously; if HTTP fails, the already-loaded WebView continues immediately.
- Off-screen login and post-login probes use shorter waits to target roughly the 7-second range when network/server response is normal.

---

v4.5: fast-login hard budget + best-effort 15-minute session keep-alive.

## v4.2 speed refresh
- Starts learned direct usage API and hidden WebView simultaneously; no 650ms fallback wait.
- Replays safe request headers (Accept / X-Requested-With / Referer) learned from the real usage request.
- Uses endpoint-specific cookies for direct refresh.
- Polls the live usage DOM more frequently so values are committed as soon as they appear.
- Keeps v4.1 simplified widget status text and v4.0 login recovery.

# EyesMobileWidget v3.8

## 홈페이지 로고 워드마크 반영
- 위젯 상단 `아이즈모바일`을 일반 안드로이드 굵은 글꼴 대신 사용자가 제공한 홈페이지 로고의 실제 워드마크 형태로 교체했습니다.
- 워드마크는 투명 이미지 마스크로 넣고 위젯의 선택된 글자색에 맞춰 자동으로 색상이 바뀝니다.
- 아래 `MOVE, BETTER`는 기존처럼 얇은 회색 톤을 유지합니다.
- 설정 화면의 위젯 미리보기에도 같은 워드마크를 적용했습니다.
- v3.6의 사용량 API 학습/빠른조회 기능과 v3.4의 통화 초 단위 표시는 그대로 유지합니다.

# EyesMobileWidget v3.6

## v3.6 실제 사용량 API 학습 + 측정 기반 초고속 조회

- v3.5의 `/mypage/main` 직접 HTTP 조회는 제거했습니다. 아이즈모바일 사용량은 페이지 로드 후 별도 비동기 요청으로 들어오기 때문에 서버 렌더링 HTML만 받아서는 빠른 조회가 거의 성공하지 않았습니다.
- 숨은 WebView가 정상 사용량을 읽는 동안 같은 사이트의 동적 GET 요청을 관찰합니다. 응답을 가로채거나 변경하지 않습니다.
- WebView 조회가 성공한 뒤 관찰된 후보를 백그라운드에서 검증하고, 실제로 데이터/통화/문자 사용량이 파싱되는 요청만 `확인된 사용량 API`로 기기에 저장합니다.
- 확인된 API가 생긴 다음 새로고침부터는 해당 API에 짧은 직접 요청을 먼저 보내며, 성공하면 WebView 자체를 열지 않습니다.
- 직접 API가 실패하거나 0.65초 안에 끝나지 않으면 기존 숨은 WebView가 자동으로 시작되므로 안정성 폴백은 유지됩니다.
- 정상 로그인 세션에서 사용량 응답이 조금 늦다는 이유만으로 자동로그인을 억지로 실행하던 v3.5의 추측성 재로그인을 제거했습니다. 자동로그인은 실제 로그아웃 화면이 확인될 때만 시작합니다.
- 상태줄에 `빠른조회`/`웹조회`와 실제 소요시간을 표시합니다. 이후 속도 문제를 감으로 판단하지 않고 실제 경로와 시간으로 확인할 수 있습니다.
- 중간 상태마다 3개 게이지를 다시 그리던 불필요한 위젯 렌더링을 줄였습니다.
- v3.4의 통화 초 단위 표시와 JobService/자동로그인 안정화 구조는 유지합니다.

> 첫 v3.6 조회는 아직 `웹조회`일 수 있습니다. 이 성공 조회에서 실제 사용량 API를 학습한 뒤, 다음 조회부터 `빠른조회`가 활성화되는 구조입니다. 사이트가 POST 방식만 사용한다면 직접 GET API 학습이 되지 않으므로 상태가 계속 `웹조회`로 표시됩니다.

# EyesMobileWidget v3.5

## v3.5 초고속 조회 우선 + WebView 자동 폴백

- 최근 정상 확인된 로그인 세션에서는 **기존 숨은 WebView와 동시에** 짧은 HTTP 직접 조회를 먼저 시도합니다.
- HTTP 응답에서 실제 데이터/통화/문자 사용량이 바로 파싱되면 WebView 로딩을 즉시 취소하고 위젯을 바로 갱신합니다.
- 사이트가 JavaScript/XHR 방식이라 HTTP 빠른 경로에서 값을 못 얻어도, 기존 WebView 조회가 이미 병렬로 실행 중이므로 **기존 조회 앞에 추가 대기시간을 붙이지 않습니다.**
- 20분 이상 지난 세션은 빠른 HTTP 경로를 건너뛰고 기존 자동로그인/WebView 경로로 바로 진행해 만료 세션 확인 때문에 느려지는 것을 피합니다.
- 직접 조회는 짧은 connect/read timeout, no-cache, 기존 WebView User-Agent/쿠키를 사용합니다.
- 빠른 경로가 성공한 경우에만 응답 쿠키를 CookieManager에 반영합니다. 실패/로그인 페이지의 쿠키는 현재 세션을 덮어쓰지 않습니다.
- v3.4 통화 초 단위 표시와 v3.3/v3.2/v3.0 안정화 구조는 그대로 유지합니다.

# EyesMobileWidget v3.4

## v3.4 통화 사용량 초 단위 갱신

- `0분 35초`처럼 분+초로 내려오는 통화 사용량을 하나의 값으로 파싱합니다.
- 1분 미만은 `35초`, 1분 이상이며 초가 남으면 `1분20초`처럼 표시합니다.
- `1시간 2분 3초` 형태도 전체 시간을 보존합니다.
- 0초는 기존 표시와 호환되도록 `0분`으로 유지합니다.
- v3.3의 정상 로그인 fast path와 v3.2/v3.0의 세션/JobService 구조는 그대로 유지합니다.

# EyesMobileWidget v3.3

## v3.3 정상 로그인 상태 새로고침 가속

- 정상 로그인 상태에서는 `onPageFinished`를 기다리지 않고 사용량 DOM이 나타나는 즉시 성공 파싱을 시도합니다.
- 숨은 WebView에서 이미지 다운로드를 막아 사용량과 무관한 리소스 로딩 시간을 줄였습니다.
- 초기 약 1.5초 동안 빠른 간격으로 사용량 DOM을 확인하고, 값이 잡히는 즉시 남은 페이지 로딩을 중단합니다.
- 빠른 경로는 **성공 판정만** 하므로 페이지가 덜 로드된 상태를 로그인 만료로 오판하지 않습니다.
- 성공 시 중복 위젯 렌더링 1회를 제거했습니다.
- v3.2의 오래된 세션 빠른 자동로그인, v3.0 JobService 안정화 구조는 그대로 유지합니다.

# EyesMobileWidget v3.2

## v3.2 오래된 세션 빠른 재로그인

- 마지막 검증 세션이 20분 이상 지난 경우 사용량 응답을 오래 기다리지 않고 빠르게 자동로그인 가능성을 확인합니다.
- 정상 세션에서는 기존 사용량 조회 흐름을 유지합니다.
- 오프스크린 WebView에서 로그인 UI가 없을 때 불필요하게 여러 번 기다리던 재시도를 줄였습니다.
- 로그인 제출 후 새 세션 확인 폴링과 페이지 동기화 대기시간을 단축했습니다.
- 주기적 keep-alive는 다시 넣지 않아 기존 로그인 안정화 원칙을 유지합니다.
- v3.0의 JobService 안정화 구조와 자동 로그인 흐름은 그대로 유지
- 숨은 WebView에서 매번 전체 캐시를 삭제하던 동작 제거: 정적 리소스는 재사용
- 마이페이지 자체는 timestamp + no-cache 헤더로 최신 요청 유지
- 첫 DOM 확인: 1.0초 → 0.3초
- 사용량 응답 폴링: 0.95초 → 0.4초
- 이미 마이페이지인 경우 불필요한 1.2초 재대기 제거
- 자동 로그인 폼 탐색/세션 확인 간격 단축
- 성공 시 즉시 파싱/갱신, 실패 타임아웃도 52초 → 30초로 단축


## v3.0 핵심
위젯 새로고침 중 로그인 세션이 만료됐을 때 자동 로그인은 성공하지만 `자동 로그인 전송 완료 · 새 세션 확인 중…`에서 멈춰 사용자가 다시 한 번 새로고침해야 했던 흐름을 수정했습니다.

- 로그인 제출 후 고정 시간 대기 1회 방식 제거
- 로그인 화면이 실제로 사라지고 새 세션이 준비될 때까지 짧게 상태 확인
- 새 세션 확인 즉시 마이페이지를 다시 열고 사용량조회 화면으로 자동 진행
- 사용량 파싱 성공 후 위젯을 갱신하고 한 번의 새로고침으로 종료
- SPA/XHR 방식 로그인도 대비해 onPageFinished가 없어도 후속 조회를 계속 수행
- 로그인 직후 너무 이른 강제 reload가 새 세션 생성을 끊지 않도록 지연/상태 기반 동기화

# EyesMobileWidget v2.8

## v2.8 핵심
위젯 새로고침에서만 자동 로그인이 실패하고 설정 화면을 열면 자동 로그인되는 차이를 수정했습니다.

원인은 숨은 WebView가 화면에 붙어 있지 않아 DOM 요소 크기가 0으로 계산될 수 있는데, 기존 자동 로그인 코드가 이 값을 로그인 UI가 없다는 뜻으로 처리할 수 있었던 점과, 숨은 WebView에 설정 화면과 같은 WebChromeClient가 없었던 점입니다.

v2.8에서는 숨은 WebView에 실제 viewport를 부여하고, off-screen 전용 DOM 판별을 사용하며, 자동 로그인 제출 뒤 서버가 새 세션 쿠키를 만들 시간을 충분히 준 다음 사용량을 다시 조회합니다.

# EyesMobileWidget v2.7

아이즈모바일 사용량 홈 화면 위젯.

## v2.7 로그인 안정화 핵심

- 만료된 인증 쿠키를 SharedPreferences 백업에서 되살리던 기존 구조 제거
- WebView CookieManager의 현재 쿠키만 사용
- 서버 세션 만료 시 저장된 자동 로그인 계정으로 새 세션 생성
- 로그인 폼이 닫혀 있으면 사이트의 `로그인` 버튼을 먼저 자동으로 열고 로그인 폼을 찾음
- 로그인 폼에서 아이디/비밀번호를 채운 뒤 버튼/폼 submit까지 자동 처리
- 이전 v2.2의 sessionStorage/localStorage 강제 복원 중지
- 위젯 새로고침은 앱 화면을 띄우지 않고 숨은 WebView에서 같은 방식으로 자동 재로그인 가능
- 자동 로그인 비밀번호는 Android Keystore 암호화 저장을 계속 사용

## v2.5 사용량 수정 유지

- 데이터 사용량/잔여량/제공량을 구분해 파싱
- 실제 사용량조회 화면 우선 탐색
- WebView 캐시 우회

## 테스트

v2.7 설치 후 기존 자동 로그인 정보가 남아 있으면 그대로 사용됩니다.
처음 한 번 앱을 열어 사용량이 정상 표시되는지 확인한 뒤 앱을 종료하고 다시 실행하거나 위젯 새로고침을 눌러 자동 재로그인을 확인합니다.

## v2.7 로그인 안정화
- 사용량 파싱에 실제로 성공한 시점의 CookieManager 세션만 `VerifiedSessionStore`에 저장합니다.
- 앱 프로세스가 다시 시작되면 현재 CookieManager에 없는 쿠키 이름만 복원하고, 기존의 더 새로운 쿠키 값은 덮어쓰지 않습니다.
- 복원된 세션이 서버에서 로그아웃 상태로 판정되면 검증 세션 백업을 즉시 폐기하고 Android Keystore에 사용자가 저장한 계정으로 새 로그인을 시도합니다.
- 자동 로그인 설정 버튼이 `자동 로그인 ON` / `자동 로그인 설정`으로 현재 상태를 직접 보여줍니다.
- 숨은 WebView 자동 로그인 실패 시 실패 코드가 위젯 상태에 표시됩니다.


## v3.0 핵심 수정
- 위젯 새로고침의 장시간 WebView 작업을 BroadcastReceiver/goAsync에서 JobService로 이동
- Android가 새로고침 중 프로세스를 정리해 상태 문구만 남는 문제 방지
- /mypage/main에서 사용량 링크를 같은 페이지로 반복 재로딩하지 않음
- 사용량 API의 비동기 응답을 최대 약 20초간 DOM에서 기다린 뒤 판단
- 자동 로그인 후 한 번의 새로고침 흐름 안에서 사용량 파싱까지 계속 진행


## v4.0
- Widget refresh recovery: when usage DOM stays empty and login expiry is not explicit, probe the off-screen login UI once and resume auto-login/usage flow if needed.
- Preserves v3.9 logo/tagline spacing.


## v4.1
- 위젯 상태 문구 간소화: 조회 중… / 업데이트 완료 / 로그인 필요 / 조회 실패만 표시
- 값 변동 없음, 소요 시간, 웹조회/빠른조회 등 내부 진단 문구를 위젯에서 제거


## v4.4 fast auto-login path

- If the learned usage endpoint reports an expired/missing session and encrypted auto-login credentials exist, the widget first tries a direct same-origin HTTP login instead of immediately launching the hidden WebView.
- The login page is fetched fresh so hidden CSRF form values are not persisted. Credentials are still read only from `SecureCredentialStore` (Android Keystore backed).
- Session cookies/credentials are never forwarded outside `eyes.co.kr`; external SSO/OTP/CAPTCHA flows fall back to the existing hidden WebView path.
- After the HTTP login creates a fresh session, the learned usage endpoint is called immediately and the widget is updated in the same refresh tap.
- If the direct login form cannot be safely reproduced, v4.4 falls back to the existing WebView auto-login rather than guessing.

## v4.3 speed path
- User refresh first tries the learned direct usage endpoint immediately without JobScheduler.
- Hidden WebView is scheduled only after that direct request fails.
- MyPage no longer uses a unique cache-busting URL on every refresh.
- Direct HTTP timeout is bounded more tightly for faster fallback.


## v5.3
- 위젯 새로고침용 투명 Activity에서 EyesMobile 페이지의 JavaScript 경고창을 자동 확인 처리해 화면에 표시되지 않도록 변경.
- 실제 WebView 자동로그인 복구 방식은 그대로 유지.

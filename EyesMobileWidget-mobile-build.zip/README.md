# EyesMobileWidget v2.3

v2.3 changes login recovery from repeated keep-alive attempts to an optional encrypted auto-login fallback.

- No periodic background keep-alive requests.
- Existing WebView cookies/storage are reused first.
- If EyesMobile expires the server session, the app can automatically log in again.
- Credentials are optional and are encrypted with Android Keystore; plaintext credentials are not written to disk or hard-coded in the APK.
- The widget refresh button remains silent and does not open the Activity.
- Auto-login setup is a compact dialog opened by the `자동 로그인` button, so the web login area stays large.

## v6.9

- Long-idle age no longer clears the live EyesMobile browser session before first use.
- Auto-login submits the exact EyesMobile login DOM button first; native touch is only a fallback.
- Native fallback verifies the target under the tap and uses one isotropic CSS-to-WebView scale, fixing vertical mis-taps when the IME/viewport changes height.
- Known Naver/Kakao/Google/Apple/Facebook login navigation is blocked during automatic EyesMobile login recovery.

## v6.8

자동로그인 장시간 세션 복구와 자동 갱신 안정성 개선. 아이즈모바일 페이지의 실제 fetch/XHR 사용량 응답을 문서 시작 시점부터 캡처하고, GET뿐 아니라 POST 요청 방식/본문/필수 헤더까지 저장해 이후 자동 갱신에서 직접 재사용합니다. 5분 자동 갱신 포함.


v6.8: Removed KEYCODE_ENTER login fallback. If EyesMobile ignores synthetic JS click, the attached WebView now resolves the visible login button and dispatches one native touch to that button. This prevents Enter from being misrouted to search/external apps such as Naver.


v8.0: 위젯 글꼴을 기기 설정과 분리해 Pretendard Regular/SemiBold로 고정. iOS 스타일에 가까운 깔끔한 한글 UI 타이포그래피 적용.


v8.1: 카드 제목과 캡션까지 Pretendard 비트맵 렌더링으로 고정해 삼성 런처 사용자 글꼴 치환을 차단.

# EyesMobileWidget v2.5

v2.5 fixes the data remaining/used mapping.

The EyesMobile usage page shows values such as:
- 데이터잔여량 146.83 GB
- 사용량 13.17 GB
- 제공량 160.00 GB

Previous parsing could match the word `사용` inside `사용내역` or `사용량조회` and mistake the remaining amount for the used amount. v2.5 only accepts explicit usage labels such as `사용량`, so the widget displays remaining data as `total - used` = 146.83 GB.

Refresh after installing to replace the previously cached value.

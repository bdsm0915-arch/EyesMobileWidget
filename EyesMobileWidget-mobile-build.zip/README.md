# EyesMobileWidget v2.4

v2.4 fixes stale/incorrect usage reads.

- Widget refresh no longer trusts the whole MyPage text.
- It first loads MyPage with WebView cache disabled and a cache-busting URL.
- If the actual usage cards are not on the first page, it automatically opens the `사용량조회` menu.
- A DOM-focused extractor ranks small usage-card regions and ignores plan/recommendation cards.
- The parser prefers explicit `사용 / 잔여 / 제공량` labels instead of blindly using the first two numbers.
- Recommendation prices/plan allowances are strongly penalized and a successful read requires at least two usage categories.
- Widget status now distinguishes `사용량 갱신됨` from `조회 완료 · 값 변동 없음`.
- v2.3 encrypted auto-login fallback remains enabled.

Note: EyesMobile/carrier usage itself can be delayed upstream. `값 변동 없음` means the site was queried again but returned the same usage values.

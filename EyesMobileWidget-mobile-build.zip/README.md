# EyesMobileWidget

아이즈모바일(`https://www.eyes.co.kr/mypage/main`) 로그인 세션을 이용해 홈 화면에서 데이터/음성/문자 사용량을 보여 주는 4×2 다크 위젯입니다.

## 기능
- 검정색 4×2 홈 화면 위젯
- 데이터 / 음성 / 문자 사용량 표시
- 위젯 새로고침 버튼
- Android AppWidget 30분 주기 갱신 요청
- 앱 내 WebView에서 아이즈모바일 로그인
- 비밀번호를 별도 SharedPreferences에 저장하지 않음
- 로그인 웹 세션 쿠키로 마이페이지 자동 조회 시도
- 웹페이지 구조가 달라 자동 파싱이 실패해도, 앱에서 실제 사용량조회 페이지를 연 뒤 `위젯 갱신` 버튼을 누르면 화면 텍스트를 파싱해 반영

## 빌드
Android Studio에서 이 폴더를 열고 **Build > Build APK(s)** 를 실행합니다.

명령줄에서는 JDK 17 + Android SDK 34가 준비된 상태에서:

```bash
./gradlew assembleDebug
```

APK 위치:
`app/build/outputs/apk/debug/app-debug.apk`

## 첫 사용
1. 앱 실행
2. 아이즈모바일 로그인
3. 마이페이지의 `사용량조회` 화면 열기
4. 상단 `위젯 갱신` 누르기
5. 홈 화면 길게 누르기 > 위젯 > 아이즈모바일 추가

## 참고
아이즈모바일의 로그인 후 HTML/API 구조는 공개 문서가 아니므로 사이트 구조가 변경되면 `UsageParser.java`의 패턴을 조정해야 할 수 있습니다.

## v1.2 디자인
- 아이즈모바일 핑크 헤더
- 데이터/음성/문자 반원형 잔여량 게이지
- BLACK / WHITE 위젯 배경 전환
- 배경 투명도 조절
- 글자 색상 선택
- 고정 디버그 서명으로 이후 APK 업데이트 설치 가능

## v1.9 session stability
- Never overwrite a live WebView cookie jar with an older backup.
- Background usage requests reuse the exact WebView User-Agent.
- Redirect cookies are kept in a temporary request jar and are committed to WebView only after a valid usage page is parsed.
- The settings checkmark no longer launches a second HTTP refresh that could disturb the active WebView login session.

## v2.0 session-safe mode
- Disabled periodic/background HttpURLConnection refreshes that could disturb the login session.
- Widget refresh opens MainActivity and refreshes through the logged-in WebView only.
- Last known-good cookies are backed up only after a valid usage page is parsed.
- If a login page appears, the last known-good cookie snapshot is restored once and MyPage is retried.

## v2.1
- 위젯 새로고침 버튼이 MainActivity를 열지 않도록 수정했습니다.
- 홈 화면에서 숨은 WebView가 동일한 CookieManager 세션으로 마이페이지를 읽고 위젯만 갱신합니다.
- 백그라운드 HTTP fetch는 사용하지 않습니다.
- 자동 주기 갱신은 비활성화 상태를 유지합니다.

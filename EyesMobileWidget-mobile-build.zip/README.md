## v6.7

자동로그인 장시간 세션 복구와 자동 갱신 안정성 개선. 아이즈모바일 페이지의 실제 fetch/XHR 사용량 응답을 문서 시작 시점부터 캡처하고, GET뿐 아니라 POST 요청 방식/본문/필수 헤더까지 저장해 이후 자동 갱신에서 직접 재사용합니다. 5분 자동 갱신 포함.


v6.7: Removed KEYCODE_ENTER login fallback. If EyesMobile ignores synthetic JS click, the attached WebView now resolves the visible login button and dispatches one native touch to that button. This prevents Enter from being misrouted to search/external apps such as Naver.

package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Creates the Aldot session natively and imports every server cookie into WebView. */
public final class AldotSessionLogin {
    private static final String API = "https://api.uplusmvno.com/umah/fo/user/v1/login";
    private static final String ORIGIN = "https://www.uplusmvno.com";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();

    private AldotSessionLogin() {}

    public interface Callback {
        void onResult(boolean success, String detail);
    }

    public static void login(Context context, Callback callback) {
        Context app = context.getApplicationContext();
        SecureCredentialStore.Credentials credentials = SecureCredentialStore.load(app);
        if (credentials == null) {
            if (callback != null) callback.onResult(false, "NO_CREDENTIALS");
            return;
        }
        String userAgent = SessionCookieStore.getUserAgent(app);
        String cookies = CookieManager.getInstance().getCookie(API);
        EXEC.execute(() -> {
            Result result = request(credentials, userAgent, cookies);
            MAIN.post(() -> {
                if (result.success) {
                    CookieManager manager = CookieManager.getInstance();
                    manager.setAcceptCookie(true);
                    for (String cookie : result.cookies) {
                        manager.setCookie(API, cookie);
                    }
                    manager.flush();
                    SessionCookieStore.flush();
                }
                if (callback != null) callback.onResult(result.success, result.detail);
            });
        });
    }

    private static Result request(SecureCredentialStore.Credentials c,
                                  String userAgent,
                                  String cookies) {
        HttpURLConnection connection = null;
        try {
            JSONObject body = new JSONObject();
            body.put("mbrLginId", c.userId);
            body.put("mbrLginPswd", c.password);
            body.put("socialFlag", "E");
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);

            connection = (HttpURLConnection) new URL(API).openConnection();
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(10000);
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Accept", "application/json, text/plain, */*");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Origin", ORIGIN);
            connection.setRequestProperty("Referer", ORIGIN + "/login");
            connection.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en;q=0.7");
            if (userAgent != null && !userAgent.trim().isEmpty()) {
                connection.setRequestProperty("User-Agent", userAgent);
            }
            if (cookies != null && !cookies.trim().isEmpty()) {
                connection.setRequestProperty("Cookie", cookies);
            }
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(bytes);
            }

            int status = connection.getResponseCode();
            InputStream input = status >= 200 && status < 400
                    ? connection.getInputStream() : connection.getErrorStream();
            String response = read(input);
            JSONObject json = response.isEmpty() ? new JSONObject() : new JSONObject(response);
            String code = json.optString("resultCode", json.optString("code", "HTTP_" + status));

            if (status >= 200 && status < 300 && "0000".equals(code)) {
                if ("Y".equals(json.optString("sixMothPw"))) {
                    return Result.fail("PASSWORD_CHANGE_REQUIRED");
                }
                if ("Y".equals(json.optString("resetPw"))) {
                    return Result.fail("PASSWORD_RESET_REQUIRED");
                }
                List<String> setCookies = collectCookies(connection);
                if (setCookies.isEmpty()) return Result.fail("SUCCESS_WITHOUT_COOKIE");
                return Result.ok(setCookies);
            }
            return Result.fail("API_" + code);
        } catch (java.net.SocketTimeoutException e) {
            return Result.fail("API_TIMEOUT");
        } catch (Throwable e) {
            return Result.fail("API_ERROR_" + e.getClass().getSimpleName());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static List<String> collectCookies(HttpURLConnection connection) {
        List<String> result = new ArrayList<>();
        Map<String, List<String>> headers = connection.getHeaderFields();
        if (headers == null) return result;
        for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
            if (entry.getKey() == null || !"set-cookie".equalsIgnoreCase(entry.getKey())) continue;
            if (entry.getValue() == null) continue;
            for (String value : entry.getValue()) {
                if (value != null && !value.trim().isEmpty()) result.add(value);
            }
        }
        return result;
    }

    private static String read(InputStream input) throws Exception {
        if (input == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) out.append(line);
        }
        return out.toString();
    }

    private static final class Result {
        final boolean success;
        final String detail;
        final List<String> cookies;

        private Result(boolean success, String detail, List<String> cookies) {
            this.success = success;
            this.detail = detail;
            this.cookies = cookies;
        }

        static Result ok(List<String> cookies) { return new Result(true, "ALDOT_API_0000", cookies); }
        static Result fail(String detail) { return new Result(false, detail, new ArrayList<>()); }
    }
}

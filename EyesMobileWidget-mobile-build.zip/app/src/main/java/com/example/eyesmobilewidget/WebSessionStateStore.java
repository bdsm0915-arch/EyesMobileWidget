package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.WebView;

import org.json.JSONObject;

/**
 * Persists Web Storage that CookieManager cannot preserve for a destroyed WebView tab.
 * localStorage is normally persistent by WebView, but sessionStorage is tab-scoped, so we
 * explicitly snapshot both after a confirmed logged-in usage page and restore them on startup.
 */
public final class WebSessionStateStore {
    private static final String PREF = "eyes_web_session_state";
    private static final String KEY_SNAPSHOT = "storage_snapshot_v22";
    private static final String KEY_SAVED_AT = "storage_saved_at_v22";

    private WebSessionStateStore() {}

    public static boolean hasSnapshot(Context context) {
        String value = prefs(context).getString(KEY_SNAPSHOT, null);
        return value != null && !value.trim().isEmpty();
    }

    public static long getSavedAt(Context context) {
        return prefs(context).getLong(KEY_SAVED_AT, 0L);
    }

    public static void backupFromWebView(Context context, WebView webView) {
        backupFromWebView(context, webView, null);
    }

    public static void backupFromWebView(Context context, WebView webView, Runnable done) {
        if (webView == null) {
            if (done != null) done.run();
            return;
        }
        try {
            webView.evaluateJavascript(
                    "(function(){try{" +
                            "var o={session:{},local:{}};" +
                            "for(var i=0;i<sessionStorage.length;i++){var k=sessionStorage.key(i);o.session[k]=sessionStorage.getItem(k);}" +
                            "for(var j=0;j<localStorage.length;j++){var q=localStorage.key(j);o.local[q]=localStorage.getItem(q);}" +
                            "return JSON.stringify(o);" +
                            "}catch(e){return '';}})()",
                    raw -> {
                        String decoded = decodeJsString(raw);
                        if (decoded != null && !decoded.trim().isEmpty() && !"{}".equals(decoded)) {
                            prefs(context).edit()
                                    .putString(KEY_SNAPSHOT, decoded)
                                    .putLong(KEY_SAVED_AT, System.currentTimeMillis())
                                    .apply();
                        }
                        if (done != null) done.run();
                    });
        } catch (Throwable ignored) {
            if (done != null) done.run();
        }
    }

    /**
     * Must be called after any page from https://www.eyes.co.kr has loaded so the origin exists.
     */
    public static void restoreIntoWebView(Context context, WebView webView, Runnable done) {
        String snapshot = prefs(context).getString(KEY_SNAPSHOT, null);
        if (webView == null || snapshot == null || snapshot.trim().isEmpty()) {
            if (done != null) done.run();
            return;
        }
        try {
            String quoted = JSONObject.quote(snapshot);
            String js = "(function(){try{" +
                    "var o=JSON.parse(" + quoted + ");" +
                    "if(o.session){Object.keys(o.session).forEach(function(k){sessionStorage.setItem(k,o.session[k]);});}" +
                    "if(o.local){Object.keys(o.local).forEach(function(k){localStorage.setItem(k,o.local[k]);});}" +
                    "return 'ok';" +
                    "}catch(e){return 'fail';}})()";
            webView.evaluateJavascript(js, ignored -> {
                if (done != null) done.run();
            });
        } catch (Throwable ignored) {
            if (done != null) done.run();
        }
    }

    private static String decodeJsString(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            if (value.startsWith("\"") && value.endsWith("\"")) {
                value = value.substring(1, value.length() - 1);
            }
            return value.replace("\\n", "\n")
                    .replace("\\r", "\r")
                    .replace("\\t", "\t")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\u003C", "<")
                    .replace("\\u003E", ">");
        } catch (Throwable e) {
            return value;
        }
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
}

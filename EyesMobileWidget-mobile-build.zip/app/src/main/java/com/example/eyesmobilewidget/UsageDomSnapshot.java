package com.example.eyesmobilewidget;

import android.webkit.WebView;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/** Builds a small, usage-focused DOM snapshot instead of parsing the whole MyPage text. */
public final class UsageDomSnapshot {
    private UsageDomSnapshot() {}

    public interface Callback {
        void onSnapshot(String snapshot);
    }

    public static void capture(WebView webView, Callback callback) {
        if (webView == null) {
            if (callback != null) callback.onSnapshot("");
            return;
        }
        try {
            webView.evaluateJavascript(JS, value -> {
                String decoded = decodeJsString(value);
                if (callback != null) callback.onSnapshot(decoded == null ? "" : decoded);
            });
        } catch (Throwable t) {
            if (callback != null) callback.onSnapshot("");
        }
    }

    public static String freshMyPageUrl() {
        return EyesMobileFetcher.MY_PAGE_URL;
    }

    public static void loadFresh(WebView webView) {
        if (webView == null) return;
        // v4.3: do not manufacture a unique URL and force a full HTML/cache miss on every tap.
        // The MyPage shell may be reused by WebView while EyesMobile's own usage request remains
        // responsible for retrieving the live counters.
        webView.loadUrl(EyesMobileFetcher.MY_PAGE_URL);
    }

    private static final String JS =
            "(function(){try{" +
            "function clean(s){return (s||'').replace(/\\u00a0/g,' ').replace(/[\\t\\r]+/g,' ').replace(/ *\\n */g,'\\n').replace(/\\n{3,}/g,'\\n\\n').trim();}" +
            "function visible(e){try{var st=getComputedStyle(e);if(st.display==='none'||st.visibility==='hidden'||st.opacity==='0')return false;var r=e.getBoundingClientRect();return !!((r.width>0&&r.height>0)||e.getClientRects().length);}catch(x){return true;}}" +
            "function txt(e){return ((e&&((e.innerText||e.value||e.textContent)||''))+'').replace(/\\s+/g,' ').trim();}" +
            "function badLoginPw(e){var k=((e.placeholder||'')+' '+(e.name||'')+' '+(e.id||'')+' '+(e.autocomplete||'')+' '+txt(e.parentElement)).toLowerCase();return /신규|재확인|확인용|new\\s*password|confirm|비밀번호\\s*변경/.test(k);}" +
            "function loggedOutUi(){var ps=document.querySelectorAll('input[type=password]');for(var pi=0;pi<ps.length;pi++){if(visible(ps[pi])&&!badLoginPw(ps[pi]))return true;}var bs=document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit]');for(var bi=0;bi<bs.length;bi++){if(!visible(bs[bi]))continue;var q=txt(bs[bi]).replace(/\\s/g,'');if(q==='로그인'||q==='로그인하기')return true;}return false;}" +
            // 알닷의 실시간 사용량은 접힌 아코디언 안에 있고, 전체 DOM 후보를 매번
            // 순회하면 큰 SPA 문서에서 evaluateJavascript 자체가 수 초씩 밀릴 수 있다.
            // 정확한 네 행의 라벨만 찾아 가까운 카드 textContent를 뽑아 빠르게 반환한다.
            "function aldotRows(){var specs=[/월\\s*기본\\s*제공\\s*데이터/i,/집\\s*[\\/·]\\s*이동전화/i,/영상\\s*[\\/·]\\s*부가통화/i,/문자\\s*메시지/i];var es=document.querySelectorAll('body *');var rows=[];for(var si=0;si<specs.length;si++){var best='';for(var ei=0;ei<es.length;ei++){var e=es[ei];var own=txt(e);if(!specs[si].test(own)||own.length>80)continue;var n=e;for(var up=0;n&&up<7;up++,n=n.parentElement){var nt=clean(n.textContent||n.innerText||'');if(nt.length<own.length||nt.length>900)continue;if(!specs[si].test(nt))continue;if(/사용|남음|제공|무제한|기본제공/i.test(nt)){best=nt;break;}}if(best)break;}if(best)rows.push('[[EYES_ALDOT_ROW_'+si+']]\\n'+best);}return rows.join('\\n');}" +
            "if(/(^|\\.)uplusmvno\\.com$/i.test(location.hostname)){var ar=aldotRows();var rr=document.querySelector('main,#content,[role=main]')||document.body;var rb=clean(rr?(rr.textContent||rr.innerText||''):'');return '[[EYES_URL]]\\n'+location.href+'\\n[[EYES_TITLE]]\\n'+document.title+'\\n[[EYES_LOGGED_OUT_UI]]\\n'+(loggedOutUi()?'1':'0')+'\\n'+ar+'\\n[[EYES_BODY]]\\n'+rb.slice(0,50000);}" +
            "function has(re,t){return re.test(t);}" +
            "function score(t){" +
            "if(!t||t.length<12||t.length>2200)return -9999;" +
            "var d=has(/데이터|\\bdata\\b/i,t),v=has(/음성|통화|\\bvoice\\b|\\bcall\\b/i,t),s=has(/문자|\\bsms\\b/i,t);" +
            "var cats=(d?1:0)+(v?1:0)+(s?1:0);if(cats===0)return -9999;" +
            "var vals=(t.match(/\\d[\\d,.]*\\s*(?:TB|GB|MB|KB|G|M|분|초|건|회|개|%)/gi)||[]).length;" +
            "var strong=has(/사용량|잔여|남은|잔량|제공량|소진|이용량/i,t);var basic=has(/기본제공|무제한/i,t);" +
            "var bad=(t.match(/요금제추천|가입신청|추천상품|특별할인|월\\s*[\\d,]+\\s*원|통신상품|요금제.*월/gi)||[]).length;" +
            "var z=cats*16+Math.min(vals,12)*3+(strong?52:0)+(basic?6:0)+(cats===3?24:0);" +
            "if(has(/사용량조회|사용량 조회/i,t))z+=18;if(has(/데이터\\s*사용량|통화\\s*사용량|음성\\s*사용량|문자\\s*사용량/i,t))z+=22;" +
            "z-=bad*60;z-=Math.floor(t.length/500);return z;}" +
            "var all=document.querySelectorAll('main,section,article,div,li,ul,ol,table,tbody');var c=[];" +
            "for(var i=0;i<all.length;i++){var e=all[i];if(!visible(e))continue;var t=clean(e.innerText);var sc=score(t);if(sc>15)c.push({s:sc,t:t,l:t.length});}" +
            "c.sort(function(a,b){if(b.s!==a.s)return b.s-a.s;return a.l-b.l;});" +
            "var out=[];var seen={};for(var j=0;j<c.length&&out.length<10;j++){var t=c[j].t;var key=t.slice(0,180);if(seen[key])continue;seen[key]=1;out.push('[[EYES_USAGE_BLOCK_'+out.length+']]\\n'+t);}" +
            "var addon=[];var addonSeen={};var ae=document.querySelectorAll('body *');" +
            "for(var ai=0;ai<ae.length&&addon.length<8;ai++){var at=txt(ae[ai]);if(!at||at.length>180)continue;if(!/(부가\\s*통화|영상\\s*[\\/·+]?\\s*부가|부가\\s*음성|영상\\s*통화)/i.test(at))continue;var node=ae[ai],best=at;for(var up=0;node&&up<5;up++,node=node.parentElement){var nt=clean(node.innerText||node.textContent||'');if(nt.length<4||nt.length>520)continue;if(!/(부가\\s*통화|영상\\s*[\\/·+]?\\s*부가|부가\\s*음성|영상\\s*통화)/i.test(nt))continue;best=nt;if(/\\d[\\d,.]*\\s*(?:시간|분|초)|\\d{1,3}:\\d{2}(?::\\d{2})?/i.test(nt))break;}var ak=best.replace(/\\s+/g,' ').slice(0,240);if(!addonSeen[ak]){addonSeen[ak]=1;addon.push('[[EYES_ADDON_BLOCK_'+addon.length+']]\\n'+best);}}" +
            // 알닷 renders the usage accordions collapsed in background WebViews. innerText omits
            // those hidden rows, leaving the widget stuck on old cached values. textContent keeps
            // the customer-visible row data even while an accordion is closed. Prefer the main
            // content root so navigation/script text cannot push the SMS row beyond the limit.
            "var root=document.querySelector('main,#content,[role=main]')||document.body;var body=clean(root?(root.textContent||root.innerText||''):'');" +
            "return '[[EYES_URL]]\\n'+location.href+'\\n[[EYES_TITLE]]\\n'+document.title+'\\n[[EYES_LOGGED_OUT_UI]]\\n'+(loggedOutUi()?'1':'0')+'\\n'+addon.join('\\n')+'\\n'+out.join('\\n')+'\\n[[EYES_BODY]]\\n'+body.slice(0,40000);" +
            "}catch(e){return '[[EYES_ERROR]]\\n'+String(e);}})()";

    private static String decodeJsString(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            if (value.startsWith("\"") && value.endsWith("\"")) {
                value = value.substring(1, value.length() - 1);
            }
            return value.replace("\\n", "\n")
                    .replace("\\r", "\r")
                    .replace("\\t", "\t")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\u003C", "<")
                    .replace("\\u003E", ">");
        } catch (Throwable e) {
            return value;
        }
    }
}

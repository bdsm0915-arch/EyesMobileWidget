package com.example.eyesmobilewidget;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** JobScheduler backup for automatic refresh when exact/inexact alarms are deferred. */
public final class AutoRefreshJobService extends JobService {
    @Override
    public boolean onStartJob(JobParameters params) {
        if (AutoRefreshScheduler.getIntervalMinutes(this) <= 0) {
            AutoRefreshScheduler.cancel(this);
            jobFinished(params, false);
            return false;
        }

        if (!AutoRefreshScheduler.claimRun(this)) {
            // The alarm already won this interval and has armed the next cycle.
            jobFinished(params, false);
            return false;
        }

        // This backup job won the race. Remove the old alarm so it cannot arrive while the job
        // is running. Re-arm the next alarm+job pair only after this JobService has finished,
        // because scheduling the same job id while it is running can stop/replace the current job.
        AutoRefreshScheduler.cancelAlarm(this);
        AutoRefreshWorker.run(this, () -> {
            jobFinished(params, false);
            AutoRefreshScheduler.scheduleNext(this);
        });
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        // Ask Android to retry if it stops the network work early.
        return true;
    }
}

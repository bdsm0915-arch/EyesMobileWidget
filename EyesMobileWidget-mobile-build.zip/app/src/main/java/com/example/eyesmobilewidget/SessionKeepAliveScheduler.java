package com.example.eyesmobilewidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

/**
 * Best-effort keep-alive for sites that expire sessions after inactivity.
 * Uses an inexact alarm so Android can batch wakeups; it never opens an Activity.
 */
public final class SessionKeepAliveScheduler {
    private static final long INTERVAL_MS = 20L * 60L * 1000L;
    private static final int REQUEST_CODE = 2202;

    private SessionKeepAliveScheduler() {}

    public static void schedule(Context context) {
        if (!SessionCookieStore.hasBackup(context) && !WebSessionStateStore.hasSnapshot(context)) return;
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            PendingIntent pi = pendingIntent(context);
            long first = SystemClock.elapsedRealtime() + INTERVAL_MS;
            am.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    first, INTERVAL_MS, pi);
        } catch (Throwable ignored) {
        }
    }

    public static void cancel(Context context) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.cancel(pendingIntent(context));
        } catch (Throwable ignored) {
        }
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, EyesMobileWidgetProvider.class)
                .setAction(EyesMobileWidgetProvider.ACTION_KEEP_ALIVE)
                .setPackage(context.getPackageName());
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}

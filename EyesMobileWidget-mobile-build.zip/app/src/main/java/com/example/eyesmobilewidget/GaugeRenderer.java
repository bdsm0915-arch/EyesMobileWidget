package com.example.eyesmobilewidget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class GaugeRenderer {
    private static final int ACCENT = Color.rgb(126, 103, 248);

    private GaugeRenderer() {}

    public static Bitmap renderGauge(Context context, int usedPercent, String topLabel, String mainText,
                                     int labelColor, int trackColor) {
        return renderGauge(context, usedPercent, topLabel, mainText, labelColor, trackColor, true);
    }

    public static Bitmap renderGauge(Context context, int usedPercent, String topLabel, String mainText,
                                     int labelColor, int trackColor, boolean showRemainingArc) {
        int w = 280;
        int h = 178;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(18f);

        float pad = 28f;
        RectF oval = new RectF(pad, 18f, w - pad, h + 96f);
        p.setColor(trackColor);
        c.drawArc(oval, 180f, 180f, false, p);

        int arcPercent = showRemainingArc ? Math.max(0, Math.min(100, 100 - usedPercent))
                : Math.max(0, Math.min(100, usedPercent));

        if ((usedPercent < 0 || usedPercent > 100 || (usedPercent == 0 && numericFromText(mainText) > 0))
                && mainText != null
                && !mainText.trim().isEmpty()
                && !mainText.contains("--")
                && !mainText.contains("확인 필요")) {
            arcPercent = 78;
        }

        p.setColor(ACCENT);
        c.drawArc(oval, 180f, 180f * arcPercent / 100f, false, p);

        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setColor(labelColor);
        p.setTextSize(28f);
        c.drawText(topLabel, w / 2f, 94f, p);

        p.setColor(ACCENT);
        p.setTextSize(mainText != null && mainText.length() > 7 ? 32f : 38f);
        String value = (mainText == null || mainText.trim().isEmpty()) ? "--" : mainText;
        c.drawText(value, w / 2f, 138f, p);
        return bmp;
    }

    public static Bitmap renderBodyBackground(Context context, int color) {
        int w = 1024;
        int h = 512;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        c.drawRect(0f, 0f, w, h, p);
        return bmp;
    }

    public static String mainDisplay(String label, String used, String total) {
        if ("데이터".equals(label)) return dataRemainingOrUsed(used, total);
        if ("음성".equals(label)) return normalizeVoiceUsage(used, total);
        if ("문자".equals(label)) return normalizeSmsUsage(used, total);
        return used == null ? "--" : compactUnit(used);
    }

    public static String dataRemainingOrUsed(String used, String total) {
        double u = numericToBase(used, true);
        double t = numericToBase(total, true);
        if (u < 0) return "--";
        if (t < 0 || t < u) return formatData(u);
        double rem = t - u;
        if (rem >= 0) return formatData(rem);
        return formatData(u);
    }

    public static String topLabel(String used, String total, boolean data) {
        if (!data) return "사용";
        return "잔여";
    }

    public static String caption(String label, String used, String total) {
        if (label.equals("데이터")) {
            if (total == null || total.equals("--")) return "총량 확인 필요";
            return total + " 기준";
        }
        if (containsAny(total, "기본제공", "무제한", "unlimited")) {
            return "기본제공";
        }
        if (label.equals("음성") || label.equals("문자")) {
            return "기본제공";
        }
        if (used != null && !used.equals("--") && total != null && !total.equals("--")) {
            return used + " / " + total;
        }
        if (total == null || total.equals("--")) return label + " 확인 필요";
        return total;
    }

    private static String normalizeVoiceUsage(String used, String total) {
        if (used != null && !used.equals("--")) {
            String v = used.replaceAll("\\s+", "");
            if (v.contains("초")) {
                double sec = numericToBase(v, false);
                double min = Math.floor(sec / 60d);
                return trim(Math.max(0, min)) + "분";
            }
            if (containsAny(v, "분", "MIN", "MINUTE")) return trim(numericToBase(v, false)) + "분";
            double num = numericToBase(v, false);
            if (num >= 0) return trim(num) + "분";
            return v;
        }
        return containsAny(total, "기본제공", "무제한") ? "0분" : "--";
    }

    private static String normalizeSmsUsage(String used, String total) {
        if (used != null && !used.equals("--")) {
            double num = numericToBase(used, false);
            if (num >= 0) return trim(num) + "건";
            return compactUnit(used);
        }
        return containsAny(total, "기본제공", "무제한") ? "0건" : "--";
    }

    private static String compactUnit(String s) {
        return s == null ? "--" : s.replaceAll("\\s+", "");
    }

    private static String formatData(double mb) {
        if (mb >= 1024d) {
            double gb = mb / 1024d;
            if (Math.abs(gb - Math.rint(gb)) < 0.005) return String.format(Locale.KOREA, "%.0fGB", gb);
            return String.format(Locale.KOREA, "%.2fGB", gb).replaceAll("0+$", "").replaceAll("\\.$", "") + "";
        }
        return trim(mb) + "MB";
    }

    private static String trim(double n) {
        if (Math.abs(n - Math.rint(n)) < 0.005) return String.format(Locale.KOREA, "%.0f", n);
        return String.format(Locale.KOREA, "%.1f", n).replaceAll("\\.0$", "");
    }

    private static double numericToBase(String value, boolean data) {
        if (value == null) return -1;
        String v = value.replace(",", "").replace(" ", "").toUpperCase(Locale.ROOT);
        Matcher m = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)(GB|MB|KB|G|M|분|초|MINUTE|MIN|건|회|개)?").matcher(v);
        if (!m.find()) return -1;
        double n;
        try { n = Double.parseDouble(m.group(1)); } catch (Exception e) { return -1; }
        String unit = m.group(2) == null ? "" : m.group(2);
        if (data) {
            if (unit.equals("GB") || unit.equals("G")) n *= 1024d;
            else if (unit.equals("KB")) n /= 1024d;
        }
        return n;
    }

    private static double numericFromText(String value) {
        double n = numericToBase(value, false);
        return Math.max(-1, n);
    }

    private static boolean containsAny(String text, String... values) {
        if (text == null) return false;
        String lower = text.toLowerCase(Locale.ROOT);
        for (String v : values) if (lower.contains(v.toLowerCase(Locale.ROOT))) return true;
        return false;
    }
}

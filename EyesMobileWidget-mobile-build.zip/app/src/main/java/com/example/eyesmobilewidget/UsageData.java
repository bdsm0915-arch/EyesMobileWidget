package com.example.eyesmobilewidget;

public final class UsageData {
    public final String dataUsed;
    public final String dataTotal;
    public final int dataPercent;
    public final String voiceUsed;
    public final String voiceTotal;
    public final int voicePercent;
    public final String smsUsed;
    public final String smsTotal;
    public final int smsPercent;
    public final long updatedAt;

    public UsageData(String dataUsed, String dataTotal, int dataPercent,
                     String voiceUsed, String voiceTotal, int voicePercent,
                     String smsUsed, String smsTotal, int smsPercent,
                     long updatedAt) {
        this.dataUsed = dataUsed;
        this.dataTotal = dataTotal;
        this.dataPercent = clamp(dataPercent);
        this.voiceUsed = voiceUsed;
        this.voiceTotal = voiceTotal;
        this.voicePercent = clamp(voicePercent);
        this.smsUsed = smsUsed;
        this.smsTotal = smsTotal;
        this.smsPercent = clamp(smsPercent);
        this.updatedAt = updatedAt;
    }

    private static int clamp(int value) {
        if (value < 0) return 0;
        return Math.min(value, 100);
    }
}

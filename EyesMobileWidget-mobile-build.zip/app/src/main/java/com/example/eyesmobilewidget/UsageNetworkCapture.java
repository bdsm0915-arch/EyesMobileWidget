package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Captures EyesMobile's live usage XHR/fetch response at document start.
 *
 * v6.0 removes the old assumption that the usage API is always a replayable GET request. The
 * site can populate MyPage from POST/fetch before an unattached WebView has painted the DOM.
 * Capturing the network response lets us update the widget immediately and remember the exact
 * request recipe for later silent HTTP refreshes.
 */
public final class UsageNetworkCapture {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Set<String> ORIGINS = new HashSet<>(Arrays.asList(
            "https://eyes.co.kr", "https://www.eyes.co.kr", "https://*.eyes.co.kr"));

    private UsageNetworkCapture() {}

    public interface Listener {
        void onUsage(UsageData data);
    }

    public static void install(Context context, WebView webView, Listener listener) {
        if (context == null || webView == null) return;
        Context app = context.getApplicationContext();
        try {
            webView.addJavascriptInterface(new Bridge(app, listener), "EyesUsageNative");
        } catch (Throwable ignored) {
        }

        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(webView, SCRIPT, ORIGINS);
            }
        } catch (Throwable ignored) {
            // Modern Android System WebView supports DOCUMENT_START_SCRIPT. If an older WebView
            // does not, the normal DOM parser remains as a fallback.
        }
    }

    private static final class Bridge {
        private final Context app;
        private final Listener listener;
        private final AtomicBoolean delivered = new AtomicBoolean(false);

        Bridge(Context app, Listener listener) {
            this.app = app;
            this.listener = listener;
        }

        @JavascriptInterface
        public void onMessage(String payload) {
            if (payload == null || payload.length() < 2 || delivered.get()) return;
            try {
                JSONObject o = new JSONObject(payload);
                String response = trim(o.optString("response", null), 650_000);
                if (response == null || response.isEmpty()) return;
                UsageData data = UsageEndpointStore.parseAny(response);
                if (data == null) return;

                String method = trim(o.optString("method", "GET"), 12);
                String url = trim(o.optString("url", null), 4000);
                String body = trim(o.optString("body", null), 250_000);
                String headers = trim(o.optString("headers", null), 24_000);
                String referer = trim(o.optString("referer", null), 4000);
                boolean replayable = o.optBoolean("replayable", false);

                if (replayable && isEyesUrl(url)) {
                    UsageEndpointStore.noteCapturedSuccess(app, method, url, body, headers, referer);
                }

                if (!delivered.compareAndSet(false, true)) return;
                if (listener != null) MAIN.post(() -> listener.onUsage(data));
            } catch (Throwable ignored) {
            }
        }
    }

    private static boolean isEyesUrl(String url) {
        if (url == null) return false;
        String u = url.toLowerCase(Locale.ROOT);
        return u.startsWith("https://eyes.co.kr/") || u.startsWith("https://www.eyes.co.kr/")
                || (u.startsWith("https://") && u.contains(".eyes.co.kr/"));
    }

    private static String trim(String value, int max) {
        if (value == null || "null".equals(value)) return null;
        return value.length() <= max ? value : value.substring(0, max);
    }

    private static final String SCRIPT =
            "(function(){try{" +
            "if(window.__eyesUsageCaptureV60)return;window.__eyesUsageCaptureV60=1;" +
            "function eyesHost(u){try{var h=new URL(u,location.href).hostname.toLowerCase();return h==='eyes.co.kr'||h.endsWith('.eyes.co.kr');}catch(e){return false;}}" +
            "function hdrObj(h){var o={};try{if(h&&h.forEach)h.forEach(function(v,k){o[k]=v;});else if(h){for(var k in h)if(Object.prototype.hasOwnProperty.call(h,k))o[k]=String(h[k]);}}catch(e){}return o;}" +
            "function send(m,u,b,h,r,rep){try{if(!eyesHost(u)||!r)return;var x={method:m||'GET',url:new URL(u,location.href).href,body:b||'',headers:JSON.stringify(h||{}),referer:location.href,response:(r.length>650000?r.slice(0,650000):r),replayable:!!rep};if(window.EyesUsageNative&&EyesUsageNative.onMessage)EyesUsageNative.onMessage(JSON.stringify(x));}catch(e){}}" +
            "var OF=window.fetch;if(OF){window.fetch=function(input,init){var req;try{req=new Request(input,init);}catch(e){return OF.apply(this,arguments);}var method=(req.method||'GET').toUpperCase(),url=req.url,hs=hdrObj(req.headers);var bodyP=Promise.resolve(''),rep=true;if(method!=='GET'&&method!=='HEAD'){try{bodyP=req.clone().text().catch(function(){rep=false;return '';});}catch(e){rep=false;}}var p=OF.call(this,req);p.then(function(resp){try{var c=resp.clone();Promise.all([bodyP,c.text().catch(function(){return ''})]).then(function(v){send(method,url,v[0],hs,v[1],rep);});}catch(e){}}).catch(function(){});return p;};}" +
            "var XO=XMLHttpRequest.prototype.open,XS=XMLHttpRequest.prototype.send,XH=XMLHttpRequest.prototype.setRequestHeader;" +
            "XMLHttpRequest.prototype.open=function(m,u){this.__eyesMeta={method:(m||'GET').toUpperCase(),url:u,headers:{}};return XO.apply(this,arguments);};" +
            "XMLHttpRequest.prototype.setRequestHeader=function(k,v){try{if(this.__eyesMeta)this.__eyesMeta.headers[k]=v;}catch(e){}return XH.apply(this,arguments);};" +
            "XMLHttpRequest.prototype.send=function(body){var self=this,meta=this.__eyesMeta||{method:'GET',url:location.href,headers:{}};var b='',rep=true;try{if(body==null)b='';else if(typeof body==='string')b=body;else if(body instanceof URLSearchParams)b=body.toString();else{rep=false;b='';}}catch(e){rep=false;}try{this.addEventListener('loadend',function(){try{var t=(typeof self.responseText==='string')?self.responseText:'';send(meta.method,meta.url,b,meta.headers,t,rep);}catch(e){}});}catch(e){}return XS.apply(this,arguments);};" +
            "}catch(e){}})();";
}

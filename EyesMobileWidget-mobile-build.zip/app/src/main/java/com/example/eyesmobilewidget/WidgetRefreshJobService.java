package com.example.eyesmobilewidget;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

/**
 * Keeps a user-requested widget refresh alive outside BroadcastReceiver's short execution window.
 *
 * v4.2 races the learned direct usage endpoint and the proven hidden WebView path immediately.
 * The first path that returns valid usage wins. Unlike v3.5, the HTTP request is only the learned
 * usage endpoint, never the whole MyPage, so there is no added 650 ms fallback delay.
 */
public class WidgetRefreshJobService extends JobService {
    private static final int JOB_ID = 29071;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private JobParameters activeParams;
    private boolean stopped;
    private boolean fastAttemptStarted;
    private boolean fastAttemptFinished;
    private boolean fastSucceeded;
    private boolean hiddenStarted;

    public static void schedule(Context context) {
        Context app = context.getApplicationContext();
        if (HiddenWebViewRefresher.isRunning() || FastUsageRefresher.isRunning()) {
            WidgetStorage.setStatus(app, "조회 중…");
            EyesMobileWidgetProvider.updateStatusOnly(app);
            return;
        }

        RefreshMetrics.begin();

        JobScheduler scheduler = (JobScheduler) app.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null) {
            WidgetStorage.setStatus(app, "조회 실패");
            EyesMobileWidgetProvider.updateStatusOnly(app);
            return;
        }

        ComponentName component = new ComponentName(app, WidgetRefreshJobService.class);
        int result;
        if (Build.VERSION.SDK_INT >= 31) {
            JobInfo expedited = new JobInfo.Builder(JOB_ID, component)
                    .setExpedited(true)
                    .build();
            result = scheduler.schedule(expedited);
            if (result != JobScheduler.RESULT_SUCCESS) {
                JobInfo normal = new JobInfo.Builder(JOB_ID, component)
                        .setMinimumLatency(0L)
                        .setOverrideDeadline(500L)
                        .build();
                result = scheduler.schedule(normal);
            }
        } else {
            JobInfo normal = new JobInfo.Builder(JOB_ID, component)
                    .setMinimumLatency(0L)
                    .setOverrideDeadline(500L)
                    .build();
            result = scheduler.schedule(normal);
        }

        if (result == JobScheduler.RESULT_SUCCESS) {
            WidgetStorage.setStatus(app, "조회 중…");
        } else {
            WidgetStorage.setStatus(app, "조회 실패");
        }
        EyesMobileWidgetProvider.updateStatusOnly(app);
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        stopped = false;
        activeParams = params;
        fastAttemptStarted = false;
        fastAttemptFinished = false;
        fastSucceeded = false;
        hiddenStarted = false;

        Context app = getApplicationContext();

        if (FastUsageRefresher.shouldTry(app)) {
            fastAttemptStarted = true;
            FastUsageRefresher.refreshAsync(app, (success, detail) -> {
                fastAttemptFinished = true;
                if (stopped || activeParams == null) return;
                if (success) {
                    fastSucceeded = true;
                    HiddenWebViewRefresher.cancelCurrentForFastSuccess();
                    handler.postDelayed(this::checkFinished, 20L);
                } else {
                    startHiddenIfNeeded();
                }
            });
            // v4.2: start the proven WebView path immediately as well. The learned endpoint and
            // WebView race in parallel; whichever returns valid usage first wins. This removes
            // the old 650 ms fallback penalty when the direct endpoint is stale or slow.
            startHiddenIfNeeded();
        } else {
            fastAttemptFinished = true;
            startHiddenIfNeeded();
        }

        handler.postDelayed(this::checkFinished, 80L);
        return true;
    }

    private void startHiddenIfNeeded() {
        if (stopped || activeParams == null || fastSucceeded || hiddenStarted) return;
        hiddenStarted = true;
        HiddenWebViewRefresher.refresh(getApplicationContext(), null, false);
    }

    private void checkFinished() {
        if (stopped || activeParams == null) return;

        boolean hiddenRunning = HiddenWebViewRefresher.isRunning();
        boolean fastRunning = FastUsageRefresher.isRunning();
        boolean fastDone = !fastAttemptStarted || fastAttemptFinished || !fastRunning;

        boolean doneByFast = fastSucceeded && fastDone && !hiddenRunning;
        boolean doneByFallback = hiddenStarted && !hiddenRunning && fastDone;
        if (doneByFast || doneByFallback) {
            JobParameters done = activeParams;
            activeParams = null;
            handler.removeCallbacksAndMessages(null);
            jobFinished(done, false);
            return;
        }
        handler.postDelayed(this::checkFinished, 100L);
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        stopped = true;
        activeParams = null;
        handler.removeCallbacksAndMessages(null);
        return true;
    }
}

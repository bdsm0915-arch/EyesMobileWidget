package com.example.eyesmobilewidget;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

/**
 * Keeps a user-requested widget refresh alive outside BroadcastReceiver's short execution window.
 * The WebView itself still runs on the main looper, while JobScheduler keeps the process/job active
 * until HiddenWebViewRefresher reports completion.
 */
public class WidgetRefreshJobService extends JobService {
    private static final int JOB_ID = 29071;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private JobParameters activeParams;
    private boolean stopped;

    public static void schedule(Context context) {
        Context app = context.getApplicationContext();
        if (HiddenWebViewRefresher.isRunning()) {
            WidgetStorage.setStatus(app, "새로고침 진행 중…");
            EyesMobileWidgetProvider.updateAll(app);
            return;
        }

        JobScheduler scheduler = (JobScheduler) app.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null) {
            WidgetStorage.setStatus(app, "새로고침 예약 실패 · 앱에서 다시 시도");
            EyesMobileWidgetProvider.updateAll(app);
            return;
        }

        ComponentName component = new ComponentName(app, WidgetRefreshJobService.class);
        int result;
        if (Build.VERSION.SDK_INT >= 31) {
            JobInfo expedited = new JobInfo.Builder(JOB_ID, component)
                    .setExpedited(true)
                    .build();
            result = scheduler.schedule(expedited);
            if (result != JobScheduler.RESULT_SUCCESS) {
                JobInfo normal = new JobInfo.Builder(JOB_ID, component)
                        .setMinimumLatency(0L)
                        .setOverrideDeadline(1500L)
                        .build();
                result = scheduler.schedule(normal);
            }
        } else {
            JobInfo normal = new JobInfo.Builder(JOB_ID, component)
                    .setMinimumLatency(0L)
                    .setOverrideDeadline(1500L)
                    .build();
            result = scheduler.schedule(normal);
        }

        if (result == JobScheduler.RESULT_SUCCESS) {
            WidgetStorage.setStatus(app, "새로고침 준비 중…");
        } else {
            WidgetStorage.setStatus(app, "새로고침 예약 실패 · 앱에서 다시 시도");
        }
        EyesMobileWidgetProvider.updateAll(app);
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        stopped = false;
        activeParams = params;
        HiddenWebViewRefresher.refresh(getApplicationContext(), null, false);
        handler.postDelayed(this::checkFinished, 350L);
        return true;
    }

    private void checkFinished() {
        if (stopped || activeParams == null) return;
        if (!HiddenWebViewRefresher.isRunning()) {
            JobParameters done = activeParams;
            activeParams = null;
            jobFinished(done, false);
            return;
        }
        handler.postDelayed(this::checkFinished, 500L);
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        stopped = true;
        activeParams = null;
        handler.removeCallbacksAndMessages(null);
        // A stopped system job may be retried later. Cached widget values remain intact.
        return true;
    }
}

package com.example.eyesmobilewidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.widget.RemoteViews;
import android.webkit.WebView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EyesMobileWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.example.eyesmobilewidget.ACTION_REFRESH";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // Render cached data immediately. v2.6 intentionally avoids periodic keep-alive
        // requests because repeated background sessions can invalidate the site login.
        for (int id : appWidgetIds) updateWidget(context, appWidgetManager, id);
        SessionKeepAliveJobService.ensureScheduled(context.getApplicationContext());
        AutoRefreshScheduler.ensureScheduled(context.getApplicationContext());
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent == null ? null : intent.getAction();
        if (ACTION_REFRESH.equals(action)) {
            startUserRefresh(context);
        } else if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            SessionCookieStore.migrateToLiveCookiePolicy(context.getApplicationContext());
            WebSessionStateStore.clear(context.getApplicationContext());
            SessionCookieStore.flush();
            SessionKeepAliveJobService.ensureScheduled(context.getApplicationContext());
            AutoRefreshScheduler.forceReschedule(context.getApplicationContext());
            updateAll(context.getApplicationContext());
        }
    }

    @Override
    public void onDisabled(Context context) {
        AutoRefreshScheduler.cancel(context.getApplicationContext());
        super.onDisabled(context);
    }

    /**
     * v4.3: a user tap should not wait for JobScheduler when a verified direct usage endpoint
     * already exists. Try that tiny HTTP request immediately from goAsync(); only fall back to
     * the durable JobService/WebView path when the direct request cannot produce valid usage.
     */
    private void startUserRefresh(Context context) {
        final Context app = context.getApplicationContext();

        if (HiddenWebViewRefresher.isRunning() || FastUsageRefresher.isRunning() || FastAutoLogin.isRunning()) {
            WidgetStorage.setStatus(app, "조회 중…");
            updateStatusOnly(app);
            return;
        }

        RefreshMetrics.begin();
        WidgetStorage.setStatus(app, "조회 중…");
        updateStatusOnly(app);

        /*
         * v4.8 manual-refresh race:
         *
         * Old path: direct usage -> wait for failure -> schedule JobService -> start WebView.
         * When the session had expired, that serialized hand-off could make the total refresh
         * feel like 15 seconds even though each individual timeout was much shorter.
         *
         * New path: keep the BroadcastReceiver alive with goAsync() and start the proven hidden
         * WebView immediately. If the learned direct endpoint is available, race it at the same
         * time. A valid direct response cancels the WebView. If the direct response proves logout,
         * start the tiny HTTP auto-login while the WebView is already warm; the WebView waits for
         * that decision before ever submitting credentials itself.
         */
        final PendingResult pending = goAsync();
        HiddenWebViewRefresher.refresh(app, pending, false);

        if (!FastUsageRefresher.shouldTry(app)) {
            // No learned endpoint yet: the already-running WebView owns the whole refresh and
            // finishes the PendingResult itself.
            return;
        }

        /*
         * v5.0 long-idle recovery:
         * A verified session older than 20 minutes is very likely to have been deferred by
         * Android's background scheduler or expired on the server. In v4.9 we still spent the
         * first direct-usage timeout proving that fact, then started HTTP auto-login. That left
         * too little of the 8.2 s WebView guard for login + usage XHR to finish.
         *
         * For an old/missing verified session, skip that expendable probe and start the cheap
         * HTTP auto-login immediately while the hidden WebView is already warming. If the live
         * browser session happens to still be valid, the WebView can still win and refresh it.
         */
        long verifiedAge = VerifiedSessionStore.ageMillis(app);
        boolean longIdle = AutoLoginHelper.hasCredentials(app)
                && (verifiedAge < 0L || verifiedAge >= 20L * 60L * 1000L);
        if (longIdle && UsageEndpointStore.getConfirmed(app) != null) {
            VerifiedSessionStore.invalidate(app);
            FastAutoLogin.refreshAsync(app, "LOGGED_OUT|LONG_IDLE", (loginSuccess, loginDetail) -> {
                // The WebView is already running in parallel. A successful direct login cancels
                // it; otherwise it consumes any fresh cookies or performs the DOM fallback.
            });
            return;
        }

        FastUsageRefresher.refreshAsync(app, (success, detail) -> {
            if (success) {
                // Direct HTTP won the race. This also finishes the active PendingResult in v4.8.
                HiddenWebViewRefresher.cancelCurrentForFastSuccess();
                return;
            }

            if (FastAutoLogin.shouldAttempt(app, detail)) {
                VerifiedSessionStore.invalidate(app);
                FastAutoLogin.refreshAsync(app, detail, (loginSuccess, loginDetail) -> {
                    // No JobScheduler hand-off here. The hidden WebView is already alive and will
                    // either consume the fresh cookies/session or perform its own proven fallback.
                });
            }
            // For non-login failures, simply let the already-running WebView finish the refresh.
        });
    }

    /**
     * v5.2: user-initiated refresh from a transparent Activity. The WebView is attached to a
     * real window, which avoids login flows that reject or defer an unattached/headless WebView.
     * The existing direct HTTP path still races in parallel and wins immediately when the session
     * is already healthy.
     */
    public static void startAttachedUserRefresh(Context context, WebView webView, Runnable completion) {
        final Context app = context.getApplicationContext();

        if (HiddenWebViewRefresher.isRunning() || FastUsageRefresher.isRunning() || FastAutoLogin.isRunning()) {
            WidgetStorage.setStatus(app, "조회 중…");
            updateStatusOnly(app);
            if (completion != null) completion.run();
            return;
        }

        RefreshMetrics.begin();
        WidgetStorage.setStatus(app, "조회 중…");
        updateStatusOnly(app);

        // The attached browser owns all login recovery. Do not race a second HTTP login against
        // it: concurrent session rotation was one source of the repeated auto-login failures.
        HiddenWebViewRefresher.refreshAttached(app, webView, completion);

        if (!FastUsageRefresher.shouldTry(app)) return;

        long verifiedAge = VerifiedSessionStore.ageMillis(app);
        boolean longIdle = AutoLoginHelper.hasCredentials(app)
                && (verifiedAge < 0L || verifiedAge >= 20L * 60L * 1000L);
        if (longIdle) {
            // For an old session, go straight through the real attached WebView login flow.
            VerifiedSessionStore.invalidate(app);
            return;
        }

        // Healthy-session fast path: one tiny usage request can still win and close the transparent
        // Activity immediately. On any failure, the attached WebView simply continues.
        FastUsageRefresher.refreshAsync(app, (success, detail) -> {
            if (success) HiddenWebViewRefresher.cancelCurrentForFastSuccess();
        });
    }

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, EyesMobileWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) updateWidget(context, manager, id);
    }

    /** Lightweight status-only widget update used while a refresh is starting. */
    public static void updateStatusOnly(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            ComponentName component = new ComponentName(context, EyesMobileWidgetProvider.class);
            int[] ids = manager.getAppWidgetIds(component);
            if (ids == null || ids.length == 0) return;

            RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.eyes_mobile_widget);
            String status = WidgetStorage.getStatus(context);
            if (status == null || status.trim().isEmpty()) status = "조회 중…";
            rv.setTextViewText(R.id.status_text, status);
            rv.setTextColor(R.id.status_text, withAlpha(WidgetAppearance.getTextColor(context), 165));
            for (int id : ids) manager.partiallyUpdateAppWidget(id, rv);
        } catch (Throwable ignored) {
            updateAll(context);
        }
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        UsageData d = WidgetStorage.load(context);
        RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.eyes_mobile_widget);

        boolean dark = WidgetAppearance.isDark(context);
        int textColor = WidgetAppearance.getTextColor(context);
        int accentColor = WidgetAppearance.getAccentColor();
        int captionColor = withAlpha(textColor, 185);
        int statusColor = withAlpha(textColor, 165);
        int trackColor = WidgetAppearance.getTrackColor(context);

        int surfaceRes = dark ? R.drawable.widget_surface_dark : R.drawable.widget_surface_background;
        int cardRes = dark ? R.drawable.widget_card_dark : R.drawable.widget_card_background;
        rv.setInt(R.id.widget_root, "setBackgroundResource", surfaceRes);
        rv.setInt(R.id.data_card, "setBackgroundResource", cardRes);
        rv.setInt(R.id.voice_card, "setBackgroundResource", cardRes);
        rv.setInt(R.id.sms_card, "setBackgroundResource", cardRes);

        float alpha = Math.max(0.40f, 1f - (WidgetAppearance.getTransparency(context) / 100f));
        rv.setFloat(R.id.widget_root, "setAlpha", alpha);

        String dataText = GaugeRenderer.mainDisplay("데이터", d.dataUsed, d.dataTotal);
        String voiceText = GaugeRenderer.mainDisplay("음성", d.voiceUsed, d.voiceTotal);
        String smsText = GaugeRenderer.mainDisplay("문자", d.smsUsed, d.smsTotal);

        Bitmap dataGauge = GaugeRenderer.renderGauge(context, d.dataPercent,
                GaugeRenderer.topLabel(d.dataUsed, d.dataTotal, true), dataText, textColor, trackColor, true);
        Bitmap voiceGauge = GaugeRenderer.renderGauge(context, d.voicePercent,
                GaugeRenderer.topLabel(d.voiceUsed, d.voiceTotal, false), voiceText, textColor, trackColor, false);
        Bitmap smsGauge = GaugeRenderer.renderGauge(context, d.smsPercent,
                GaugeRenderer.topLabel(d.smsUsed, d.smsTotal, false), smsText, textColor, trackColor, false);

        rv.setImageViewBitmap(R.id.data_gauge, dataGauge);
        rv.setImageViewBitmap(R.id.voice_gauge, voiceGauge);
        rv.setImageViewBitmap(R.id.sms_gauge, smsGauge);

        rv.setTextViewText(R.id.data_caption, GaugeRenderer.caption("데이터", d.dataUsed, d.dataTotal));
        rv.setTextViewText(R.id.voice_caption, GaugeRenderer.caption("음성", d.voiceUsed, d.voiceTotal));
        rv.setTextViewText(R.id.sms_caption, GaugeRenderer.caption("문자", d.smsUsed, d.smsTotal));

        rv.setInt(R.id.logo_wordmark, "setColorFilter", textColor);
        rv.setTextColor(R.id.last_updated, accentColor);
        rv.setTextColor(R.id.refresh_button, accentColor);
        rv.setTextColor(R.id.settings_button, accentColor);
        rv.setTextColor(R.id.data_title, textColor);
        rv.setTextColor(R.id.voice_title, textColor);
        rv.setTextColor(R.id.sms_title, textColor);
        rv.setTextColor(R.id.data_caption, captionColor);
        rv.setTextColor(R.id.voice_caption, captionColor);
        rv.setTextColor(R.id.sms_caption, captionColor);
        rv.setTextColor(R.id.status_text, statusColor);

        if (d.updatedAt > 0) {
            String time = new SimpleDateFormat("M/d HH:mm", Locale.KOREA).format(new Date(d.updatedAt));
            rv.setTextViewText(R.id.last_updated, time);
        } else {
            rv.setTextViewText(R.id.last_updated, "로그인 필요");
        }

        String status = WidgetStorage.getStatus(context);
        if (status == null || status.trim().isEmpty() || "최신 사용량".equals(status)) {
            if (d.updatedAt > 0) {
                String time = new SimpleDateFormat("M/d HH:mm", Locale.KOREA).format(new Date(d.updatedAt));
                rv.setTextViewText(R.id.status_text, "업데이트 완료");
            } else {
                rv.setTextViewText(R.id.status_text, "로그인 필요");
            }
        } else {
            rv.setTextViewText(R.id.status_text, status);
        }

        Intent refresh = new Intent(context, WidgetRefreshActivity.class)
                .setAction(ACTION_REFRESH)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_NO_ANIMATION
                        | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        PendingIntent refreshPi = PendingIntent.getActivity(
                context, 1001, refresh, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.refresh_button, refreshPi);

        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(
                context, 1002, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.widget_root, openPi);
        rv.setOnClickPendingIntent(R.id.settings_button, openPi);

        manager.updateAppWidget(id, rv);
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }
}

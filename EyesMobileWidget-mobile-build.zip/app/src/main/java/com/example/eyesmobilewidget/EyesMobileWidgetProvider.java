package com.example.eyesmobilewidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EyesMobileWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.example.eyesmobilewidget.ACTION_REFRESH";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int id : appWidgetIds) updateWidget(context, appWidgetManager, id);
        refreshAsync(context, goAsync());
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            WidgetStorage.setStatus(context, "새로고침 중…");
            updateAll(context);
            refreshAsync(context, goAsync());
        }
    }

    private static void refreshAsync(Context context, PendingResult pendingResult) {
        Context app = context.getApplicationContext();
        final PendingResult result = pendingResult;
        new Thread(() -> {
            try {
                EyesMobileFetcher.refresh(app);
                updateAll(app);
            } finally {
                if (result != null) result.finish();
            }
        }, "EyesMobileRefresh").start();
    }

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, EyesMobileWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        UsageData d = WidgetStorage.load(context);
        RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.eyes_mobile_widget);

        int titleColor = Color.rgb(27, 22, 52);
        int accentColor = Color.rgb(126, 103, 248);
        int captionColor = Color.rgb(126, 121, 152);
        int statusColor = Color.rgb(140, 137, 161);
        int trackColor = Color.rgb(226, 222, 244);

        String dataText = GaugeRenderer.usageDisplay(d.dataUsed, d.dataTotal, true);
        String voiceText = GaugeRenderer.usageDisplay(d.voiceUsed, d.voiceTotal, false);
        String smsText = GaugeRenderer.usageDisplay(d.smsUsed, d.smsTotal, false);

        Bitmap dataGauge = GaugeRenderer.renderGauge(context, d.dataPercent,
                GaugeRenderer.topLabel(d.dataUsed, d.dataTotal, true), dataText, titleColor, trackColor);
        Bitmap voiceGauge = GaugeRenderer.renderGauge(context, d.voicePercent,
                GaugeRenderer.topLabel(d.voiceUsed, d.voiceTotal, false), voiceText, titleColor, trackColor);
        Bitmap smsGauge = GaugeRenderer.renderGauge(context, d.smsPercent,
                GaugeRenderer.topLabel(d.smsUsed, d.smsTotal, false), smsText, titleColor, trackColor);

        rv.setImageViewBitmap(R.id.data_gauge, dataGauge);
        rv.setImageViewBitmap(R.id.voice_gauge, voiceGauge);
        rv.setImageViewBitmap(R.id.sms_gauge, smsGauge);

        rv.setTextViewText(R.id.data_caption, GaugeRenderer.caption("데이터", d.dataUsed, d.dataTotal));
        rv.setTextViewText(R.id.voice_caption, GaugeRenderer.caption("음성", d.voiceUsed, d.voiceTotal));
        rv.setTextViewText(R.id.sms_caption, GaugeRenderer.caption("문자", d.smsUsed, d.smsTotal));

        rv.setTextColor(R.id.logo_text, titleColor);
        rv.setTextColor(R.id.last_updated, accentColor);
        rv.setTextColor(R.id.refresh_button, accentColor);
        rv.setTextColor(R.id.settings_button, accentColor);
        rv.setTextColor(R.id.data_title, titleColor);
        rv.setTextColor(R.id.voice_title, titleColor);
        rv.setTextColor(R.id.sms_title, titleColor);
        rv.setTextColor(R.id.data_caption, captionColor);
        rv.setTextColor(R.id.voice_caption, captionColor);
        rv.setTextColor(R.id.sms_caption, captionColor);
        rv.setTextColor(R.id.status_text, statusColor);

        if (d.updatedAt > 0) {
            String time = new SimpleDateFormat("M/d HH:mm", Locale.KOREA).format(new Date(d.updatedAt));
            rv.setTextViewText(R.id.last_updated, time);
        } else {
            rv.setTextViewText(R.id.last_updated, "로그인 필요");
        }

        String status = WidgetStorage.getStatus(context);
        if (status == null || status.trim().isEmpty() || "최신 사용량".equals(status)) {
            if (d.updatedAt > 0) {
                String time = new SimpleDateFormat("M/d HH:mm", Locale.KOREA).format(new Date(d.updatedAt));
                rv.setTextViewText(R.id.status_text, time + " 기준 최신 사용량");
            } else {
                rv.setTextViewText(R.id.status_text, "앱을 열어 아이즈모바일에 로그인하세요");
            }
        } else {
            rv.setTextViewText(R.id.status_text, status);
        }

        Intent refresh = new Intent(context, EyesMobileWidgetProvider.class)
                .setAction(ACTION_REFRESH)
                .setPackage(context.getPackageName());
        PendingIntent refreshPi = PendingIntent.getBroadcast(
                context, 1001, refresh, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.refresh_button, refreshPi);

        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(
                context, 1002, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.widget_root, openPi);
        rv.setOnClickPendingIntent(R.id.settings_button, openPi);

        manager.updateAppWidget(id, rv);
    }
}

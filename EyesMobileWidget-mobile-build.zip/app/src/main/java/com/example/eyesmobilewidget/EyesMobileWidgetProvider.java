package com.example.eyesmobilewidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.widget.RemoteViews;
import android.webkit.WebView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EyesMobileWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.example.eyesmobilewidget.ACTION_REFRESH";

    private static volatile boolean refreshAnimating = false;
    private static volatile int refreshAnimationFrame = 0;
    private static volatile Context refreshAnimationContext;

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // Render cached data immediately. v2.6 intentionally avoids periodic keep-alive
        // requests because repeated background sessions can invalidate the site login.
        for (int id : appWidgetIds) updateWidget(context, appWidgetManager, id);
        SessionKeepAliveJobService.ensureScheduled(context.getApplicationContext());
        AutoRefreshScheduler.ensureScheduled(context.getApplicationContext());
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent == null ? null : intent.getAction();
        if (ACTION_REFRESH.equals(action)) {
            startUserRefresh(context);
        } else if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            SessionCookieStore.migrateToLiveCookiePolicy(context.getApplicationContext());
            WebSessionStateStore.clear(context.getApplicationContext());
            SessionCookieStore.flush();
            SessionKeepAliveJobService.ensureScheduled(context.getApplicationContext());
            AutoRefreshScheduler.forceReschedule(context.getApplicationContext());
            updateAll(context.getApplicationContext());
            // v7.6: older builds may have left stale usage values in SharedPreferences.
            // Run one normal refresh after package replacement so the isolated voice/add-on parser
            // replaces stale cache without waiting for a manual refresh.
            if (Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
                WidgetRefreshJobService.schedule(context.getApplicationContext());
            }
        }
    }

    @Override
    public void onDisabled(Context context) {
        AutoRefreshScheduler.cancel(context.getApplicationContext());
        super.onDisabled(context);
    }

    /**
     * v4.3: a user tap should not wait for JobScheduler when a verified direct usage endpoint
     * already exists. Try that tiny HTTP request immediately from goAsync(); only fall back to
     * the durable JobService/WebView path when the direct request cannot produce valid usage.
     */
    private void startUserRefresh(Context context) {
        final Context app = context.getApplicationContext();
        startRefreshAnimation(app);

        // Do not start overlapping requests. The active worker owns the final widget update.
        if (HiddenWebViewRefresher.isRunning()
                || FastUsageRefresher.isRunning()
                || FastAutoLogin.isRunning()) {
            return;
        }

        RefreshMetrics.begin();

        // Most taps have a healthy session and a previously verified usage endpoint. Run that
        // tiny request immediately from the receiver instead of paying JobScheduler + WebView
        // startup cost. goAsync() safely keeps only this short request alive. If it fails, finish
        // the receiver promptly and hand the slower browser/login recovery to the durable job.
        if (FastUsageRefresher.shouldTry(app)) {
            WidgetStorage.setStatus(app, "조회 중…");
            updateStatusOnly(app);
            final PendingResult pending = goAsync();
            FastUsageRefresher.refreshAsync(app, (success, detail) -> {
                try {
                    if (!success) WidgetRefreshJobService.scheduleFallback(app);
                } finally {
                    try { pending.finish(); } catch (Throwable ignored) {}
                }
            });
            return;
        }

        // No verified fast endpoint yet. Keep the whole browser/login flow in JobService so a
        // Galaxy background limit cannot suspend it and leave the widget at "조회 중…".
        WidgetRefreshJobService.schedule(app);
    }

    /**
     * v5.2: user-initiated refresh from a transparent Activity. The WebView is attached to a
     * real window, which avoids login flows that reject or defer an unattached/headless WebView.
     * The existing direct HTTP path still races in parallel and wins immediately when the session
     * is already healthy.
     */
    public static void startAttachedUserRefresh(Context context, WebView webView, Runnable completion) {
        final Context app = context.getApplicationContext();
        startRefreshAnimation(app);

        if (HiddenWebViewRefresher.isRunning() || FastUsageRefresher.isRunning() || FastAutoLogin.isRunning()) {
            WidgetStorage.setStatus(app, "조회 중…");
            updateStatusOnly(app);
            if (completion != null) completion.run();
            return;
        }

        RefreshMetrics.begin();
        WidgetStorage.setStatus(app, "조회 중…");
        updateStatusOnly(app);

        // The attached browser owns all login recovery. Do not race a second HTTP login against
        // it: concurrent session rotation was one source of the repeated auto-login failures.
        HiddenWebViewRefresher.refreshAttached(app, webView, () -> {
            stopRefreshAnimation(app);
            if (completion != null) completion.run();
        });

        if (!FastUsageRefresher.shouldTry(app)) return;

        long verifiedAge = VerifiedSessionStore.ageMillis(app);
        boolean longIdle = AutoLoginHelper.hasCredentials(app)
                && (verifiedAge < 0L || verifiedAge >= 20L * 60L * 1000L);
        if (longIdle) {
            // For an old session, go straight through the real attached WebView login flow.
            VerifiedSessionStore.invalidate(app);
            return;
        }

        // Healthy-session fast path: one tiny usage request can still win and close the transparent
        // Activity immediately. On any failure, the attached WebView simply continues.
        FastUsageRefresher.refreshAsync(app, (success, detail) -> {
            if (success) HiddenWebViewRefresher.cancelCurrentForFastSuccess();
        });
    }

    public static void updateAll(Context context) {
        String currentStatus = WidgetStorage.getStatus(context);
        if (currentStatus == null || !currentStatus.contains("조회 중")) {
            cancelRefreshAnimation();
        }
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, EyesMobileWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) updateWidget(context, manager, id);
    }

    /** Lightweight status-only widget update used while a refresh is starting. */
    public static void updateStatusOnly(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            ComponentName component = new ComponentName(context, EyesMobileWidgetProvider.class);
            int[] ids = manager.getAppWidgetIds(component);
            if (ids == null || ids.length == 0) return;

            RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.eyes_mobile_widget);
            String status = WidgetStorage.getStatus(context);
            if (status == null || status.trim().isEmpty()) status = "조회 중…";
            rv.setImageViewBitmap(R.id.status_text,
                    GaugeRenderer.renderTextLineLeft(context, status,
                            withAlpha(WidgetAppearance.getTextColor(context), 165), false,
                            28f, 1000, 54, 8f));
            rv.setTextViewText(R.id.refresh_button, "↻");
            rv.setTextColor(R.id.refresh_button, WidgetAppearance.getAccentColor());
            for (int id : ids) manager.partiallyUpdateAppWidget(id, rv);
        } catch (Throwable ignored) {
            updateAll(context);
        }
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        UsageData d = WidgetStorage.load(context);
        RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.eyes_mobile_widget);

        boolean dark = WidgetAppearance.isDark(context);
        int textColor = WidgetAppearance.getTextColor(context);
        int accentColor = WidgetAppearance.getAccentColor();
        int captionColor = withAlpha(textColor, 185);
        float titleTextSize = WidgetAppearance.getTitleTextSize(context);
        float captionTextSize = WidgetAppearance.getCaptionTextSize(context);
        int statusColor = withAlpha(textColor, 165);
        int trackColor = WidgetAppearance.getTrackColor(context);

        int surfaceRes = dark ? R.drawable.widget_surface_dark : R.drawable.widget_surface_background;
        int cardRes = dark ? R.drawable.widget_card_dark : R.drawable.widget_card_background;
        rv.setInt(R.id.widget_root, "setBackgroundResource", surfaceRes);
        rv.setInt(R.id.data_card, "setBackgroundResource", cardRes);
        rv.setInt(R.id.voice_card, "setBackgroundResource", cardRes);
        rv.setInt(R.id.sms_card, "setBackgroundResource", cardRes);

        float alpha = Math.max(0.40f, 1f - (WidgetAppearance.getTransparency(context) / 100f));
        rv.setFloat(R.id.widget_root, "setAlpha", alpha);

        String dataText = GaugeRenderer.mainDisplay("데이터", d.dataUsed, d.dataTotal);
        String voiceText = GaugeRenderer.mainDisplay("음성", d.voiceUsed, d.voiceTotal);
        String smsText = GaugeRenderer.mainDisplay("문자", d.smsUsed, d.smsTotal);
        Bitmap dataGauge = GaugeRenderer.renderGauge(context, d.dataPercent,
                GaugeRenderer.topLabel(d.dataUsed, d.dataTotal, true), dataText, textColor, trackColor, true);
        Bitmap voiceGauge = GaugeRenderer.renderGauge(context, d.voicePercent,
                GaugeRenderer.topLabel(d.voiceUsed, d.voiceTotal, false), voiceText, textColor, trackColor, true);
        Bitmap smsGauge = GaugeRenderer.renderGauge(context, d.smsPercent,
                GaugeRenderer.topLabel(d.smsUsed, d.smsTotal, false), smsText, textColor, trackColor, true);

        rv.setImageViewBitmap(R.id.data_gauge, dataGauge);
        rv.setImageViewBitmap(R.id.voice_gauge, voiceGauge);
        rv.setImageViewBitmap(R.id.sms_gauge, smsGauge);

        // v8.3: titles and bottom captions use the same nominal size as the red usage value.
        // Keep the bitmap width aligned with the gauge bitmap so RemoteViews scales them equally.
        rv.setImageViewBitmap(R.id.data_title,
                GaugeRenderer.renderTextLine(context, "데이터", textColor, true, titleTextSize, 280, 64));
        rv.setImageViewBitmap(R.id.voice_title,
                GaugeRenderer.renderTextLine(context, "음성", textColor, true, titleTextSize, 280, 64));
        rv.setImageViewBitmap(R.id.sms_title,
                GaugeRenderer.renderTextLine(context, "문자", textColor, true, titleTextSize, 280, 64));

        rv.setImageViewBitmap(R.id.data_caption,
                GaugeRenderer.renderTextLine(context,
                        GaugeRenderer.caption("데이터", d.dataUsed, d.dataTotal),
                        captionColor, false, captionTextSize, 280, 64));
        rv.setImageViewBitmap(R.id.voice_caption,
                GaugeRenderer.renderTextLine(context,
                        GaugeRenderer.caption("음성", d.voiceUsed, d.voiceTotal),
                        captionColor, false, captionTextSize, 280, 64));
        rv.setImageViewBitmap(R.id.sms_caption,
                GaugeRenderer.renderTextLine(context,
                        GaugeRenderer.caption("문자", d.smsUsed, d.smsTotal),
                        captionColor, false, captionTextSize, 280, 64));

        rv.setInt(R.id.logo_wordmark, "setColorFilter", textColor);
        rv.setTextViewText(R.id.refresh_button, "↻");
        rv.setTextColor(R.id.refresh_button, accentColor);
        rv.setTextColor(R.id.settings_button, accentColor);

        String updateText;
        if (d.updatedAt > 0) {
            updateText = new SimpleDateFormat("M/d HH:mm", Locale.KOREA).format(new Date(d.updatedAt));
        } else {
            updateText = "로그인 필요";
        }
        rv.setImageViewBitmap(R.id.last_updated,
                GaugeRenderer.renderTextLineRight(context, updateText, accentColor,
                        false, 30f, 300, 64, 8f));

        String status = WidgetStorage.getStatus(context);
        if (status == null || status.trim().isEmpty() || "최신 사용량".equals(status)) {
            status = d.updatedAt > 0 ? "업데이트 완료" : "로그인 필요";
        }
        rv.setImageViewBitmap(R.id.status_text,
                GaugeRenderer.renderTextLineLeft(context, status, statusColor,
                        false, 28f, 1000, 54, 8f));

        // Keep manual refresh completely behind the launcher. Starting the transparent
        // WidgetRefreshActivity made Samsung treat the refresh as the foreground screen,
        // which changed the navigation-bar scrim and blocked Home/Back until the network
        // request completed. The provider already owns a background-safe goAsync() path.
        Intent refresh = new Intent(context, EyesMobileWidgetProvider.class)
                .setAction(ACTION_REFRESH);
        PendingIntent refreshPi = PendingIntent.getBroadcast(
                context, 1001, refresh, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.refresh_button, refreshPi);

        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(
                context, 1002, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.widget_root, openPi);
        rv.setOnClickPendingIntent(R.id.settings_button, openPi);

        manager.updateAppWidget(id, rv);
    }

    private static void startRefreshAnimation(Context context) {
        if (context == null) return;
        refreshAnimationContext = context.getApplicationContext();
        refreshAnimationFrame = 0;
        refreshAnimating = false;
        updateRefreshIconOnly(refreshAnimationContext, 0f);
    }

    private static void stopRefreshAnimation(Context context) {
        cancelRefreshAnimation();
        if (context != null) updateRefreshIconOnly(context.getApplicationContext(), 0f);
    }

    private static void cancelRefreshAnimation() {
        refreshAnimating = false;
        refreshAnimationFrame = 0;
        refreshAnimationContext = null;
    }

    private static void updateRefreshIconOnly(Context context, float angle) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            ComponentName component = new ComponentName(context, EyesMobileWidgetProvider.class);
            int[] ids = manager.getAppWidgetIds(component);
            if (ids == null || ids.length == 0) return;
            RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.eyes_mobile_widget);
            rv.setTextViewText(R.id.refresh_button, "↻");
            rv.setTextColor(R.id.refresh_button, WidgetAppearance.getAccentColor());
            for (int id : ids) manager.partiallyUpdateAppWidget(id, rv);
        } catch (Throwable ignored) {
        }
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }
}

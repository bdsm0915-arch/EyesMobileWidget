package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;

import org.json.JSONObject;

/**
 * DOM based auto-login helper for EyesMobile.
 *
 * v2.8 has two execution modes:
 *  - visible: normal Activity WebView
 *  - off-screen: widget refresh WebView that is intentionally not attached to a visible window
 *
 * The old helper used getBoundingClientRect() as a hard visibility test. In an unattached
 * off-screen WebView, perfectly usable login controls can report a zero-sized rectangle, so
 * the widget path returned NO_LOGIN_UI while the exact same account worked as soon as the
 * settings Activity was opened. v2.8 keeps ancestor CSS visibility checks but does not require
 * screen geometry in off-screen mode.
 */
public final class AutoLoginHelper {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final int MAX_OPEN_ATTEMPTS = 8;
    private static final int OFFSCREEN_MAX_OPEN_ATTEMPTS = 4;

    private AutoLoginHelper() {}

    public interface Callback {
        void onResult(boolean submitted, String detail);
    }

    public static boolean hasCredentials(Context context) {
        return SecureCredentialStore.isEnabled(context);
    }

    public static void tryLogin(Context context, WebView webView, Callback callback) {
        tryLoginInternal(context, webView, false, callback);
    }

    /** Login entry point used by the home-screen widget's off-screen WebView. */
    public static void tryLoginOffscreen(Context context, WebView webView, Callback callback) {
        tryLoginInternal(context, webView, true, callback);
    }

    private static void tryLoginInternal(Context context,
                                         WebView webView,
                                         boolean offscreen,
                                         Callback callback) {
        SecureCredentialStore.Credentials c = SecureCredentialStore.load(context);
        if (webView == null) {
            if (callback != null) callback.onResult(false, "NO_WEBVIEW");
            return;
        }
        if (c == null) {
            if (callback != null) {
                if (SecureCredentialStore.isEnabled(context)) {
                    String reason = SecureCredentialStore.getLastLoadError();
                    callback.onResult(false, "CREDENTIAL_READ_ERROR" +
                            (reason == null || reason.isEmpty() ? "" : ":" + reason));
                } else {
                    callback.onResult(false, "NO_CREDENTIALS");
                }
            }
            return;
        }
        attempt(webView, c, callback, 0, offscreen);
    }

    private static void attempt(WebView webView,
                                SecureCredentialStore.Credentials c,
                                Callback callback,
                                int attempt,
                                boolean offscreen) {
        if (webView == null) {
            if (callback != null) callback.onResult(false, "NO_WEBVIEW");
            return;
        }

        String id = JSONObject.quote(c.userId);
        String pw = JSONObject.quote(c.password);
        String off = offscreen ? "true" : "false";
        // v6.4 login is deliberately two phase. EyesMobile updates its login-form state from
        // input/change events asynchronously. The old helper filled the fields and clicked the
        // button in the very same JS turn, so the site could still consider the form empty while
        // we incorrectly reported SUBMITTED_BUTTON. First fill only; submit after the page has
        // had a short event loop turn to accept the new values.
        String js = "(function(){try{" +
                "var OFFSCREEN=" + off + ";" +
                "function cssok(e){if(!e)return false;try{var n=e;while(n&&n!==document){var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden'||s.opacity==='0')return false;n=n.parentElement;}return true;}catch(x){return true;}}" +
                "function vis(e){if(!cssok(e))return false;if(OFFSCREEN)return true;try{var r=e.getBoundingClientRect();return r.width>0&&r.height>0;}catch(x){return true;}}" +
                "function tx(e){return ((e&&((e.innerText||e.value||e.textContent)||''))+'').replace(/\\s+/g,' ').trim();}" +
                "function badPw(p){var z=((p.placeholder||'')+' '+(p.name||'')+' '+(p.id||'')+' '+tx(p.parentElement)).toLowerCase();return /신규|재확인|확인용|new\\s*password|confirm/.test(z);}" +
                "var ps=document.querySelectorAll('input[type=password]'),p=null;" +
                "for(var i=0;i<ps.length;i++){if(vis(ps[i])&&!badPw(ps[i])){p=ps[i];break;}}" +
                "if(!p){" +
                " var cs=document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit]');var best=null;" +
                " for(var j=0;j<cs.length;j++){var e=cs[j];if(!vis(e))continue;var t=tx(e).replace(/\\s/g,'');if(t==='로그인'||t==='로그인하기'){best=e;break;}}" +
                " if(best){best.click();return 'OPENED_LOGIN';}" +
                " return 'NO_LOGIN_UI';" +
                "}" +
                "var root=p.form||p.closest('form')||p.closest('[class*=login]')||p.parentElement||document;" +
                "var ins=root.querySelectorAll?root.querySelectorAll('input'):document.querySelectorAll('input');var u=null,bestScore=-999;" +
                "for(var k=0;k<ins.length;k++){var x=ins[k];if(x===p||!vis(x))continue;var typ=(x.type||'text').toLowerCase();if(typ==='hidden'||typ==='password'||typ==='submit'||typ==='button'||typ==='checkbox'||typ==='radio')continue;" +
                " var key=((x.name||'')+' '+(x.id||'')+' '+(x.placeholder||'')+' '+(x.autocomplete||'')).toLowerCase();var sc=0;" +
                " if(typ==='email')sc+=8;if(/email|e-mail|아이디|로그인|login|user|member/.test(key))sc+=12;if(/검색|search|추천/.test(key))sc-=30;" +
                " if(sc>bestScore){bestScore=sc;u=x;}}" +
                "if(!u)return 'NO_ID_FIELD';" +
                "function nativeSet(el,v){try{var d=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value');if(d&&d.set)d.set.call(el,v);else el.value=v;}catch(q){el.value=v;}}" +
                "function ev(el,name){try{el.dispatchEvent(new Event(name,{bubbles:true}));}catch(x){}}" +
                "function key(el,name,key){try{el.dispatchEvent(new KeyboardEvent(name,{key:key,code:key==='Enter'?'Enter':'',bubbles:true,cancelable:true}));}catch(x){}}" +
                "nativeSet(u," + id + ");u.focus();ev(u,'input');key(u,'keyup','a');ev(u,'change');" +
                "nativeSet(p," + pw + ");p.focus();ev(p,'input');key(p,'keyup','a');ev(p,'change');p.blur();" +
                "return 'FILLED';" +
                "}catch(e){return 'ERROR:'+e;}})()";

        try {
            webView.evaluateJavascript(js, result -> {
                String r = decode(result);
                if ("FILLED".equals(r)) {
                    long settle = offscreen ? 180L : 240L;
                    MAIN.postDelayed(() -> submitFilled(webView, c, callback, 0, offscreen), settle);
                    return;
                }
                int maxOpenAttempts = offscreen ? OFFSCREEN_MAX_OPEN_ATTEMPTS : MAX_OPEN_ATTEMPTS;
                if ("OPENED_LOGIN".equals(r) && attempt < maxOpenAttempts) {
                    long delay = offscreen ? 120L : 300L;
                    MAIN.postDelayed(() -> attempt(webView, c, callback, attempt + 1, offscreen), delay);
                    return;
                }
                if ("NO_LOGIN_UI".equals(r)) {
                    int maxNoUiAttempts = offscreen ? 4 : MAX_OPEN_ATTEMPTS;
                    if (attempt < maxNoUiAttempts) {
                        long delay = offscreen ? 140L : 260L;
                        MAIN.postDelayed(() -> attempt(webView, c, callback, attempt + 1, offscreen), delay);
                        return;
                    }
                }
                int fieldRetryMax = offscreen ? 4 : 5;
                if (("NO_ID_FIELD".equals(r) || "NO_SUBMIT".equals(r))
                        && attempt < fieldRetryMax) {
                    MAIN.postDelayed(() -> attempt(webView, c, callback, attempt + 1, offscreen),
                            offscreen ? 150L : 280L);
                    return;
                }
                if (callback != null) callback.onResult(false, r);
            });
        } catch (Throwable t) {
            if (callback != null) callback.onResult(false, "ERROR:" + t.getClass().getSimpleName());
        }
    }

    private static void submitFilled(WebView webView,
                                     SecureCredentialStore.Credentials c,
                                     Callback callback,
                                     int attempt,
                                     boolean offscreen) {
        if (webView == null) {
            if (callback != null) callback.onResult(false, "NO_WEBVIEW");
            return;
        }
        String id = JSONObject.quote(c.userId);
        String pw = JSONObject.quote(c.password);
        String off = offscreen ? "true" : "false";
        String js = "(function(){try{" +
                "var OFFSCREEN=" + off + ";" +
                "function cssok(e){if(!e)return false;try{var n=e;while(n&&n!==document){var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden'||s.opacity==='0')return false;n=n.parentElement;}return true;}catch(x){return true;}}" +
                "function vis(e){if(!cssok(e))return false;if(OFFSCREEN)return true;try{var r=e.getBoundingClientRect();return r.width>0&&r.height>0;}catch(x){return true;}}" +
                "function tx(e){return ((e&&((e.innerText||e.value||e.textContent)||''))+'').replace(/\\s+/g,' ').trim();}" +
                "function badPw(p){var z=((p.placeholder||'')+' '+(p.name||'')+' '+(p.id||'')+' '+tx(p.parentElement)).toLowerCase();return /신규|재확인|확인용|new\\s*password|confirm/.test(z);}" +
                "var ps=document.querySelectorAll('input[type=password]'),p=null;for(var i=0;i<ps.length;i++){if(vis(ps[i])&&!badPw(ps[i])){p=ps[i];break;}}" +
                "if(!p)return 'FORM_GONE';" +
                "var root=p.form||p.closest('form')||p.closest('[class*=login]')||p.parentElement||document;" +
                "var ins=root.querySelectorAll?root.querySelectorAll('input'):document.querySelectorAll('input');var u=null,bestScore=-999;" +
                "for(var k=0;k<ins.length;k++){var x=ins[k];if(x===p||!vis(x))continue;var typ=(x.type||'text').toLowerCase();if(typ==='hidden'||typ==='password'||typ==='submit'||typ==='button'||typ==='checkbox'||typ==='radio')continue;var key=((x.name||'')+' '+(x.id||'')+' '+(x.placeholder||'')+' '+(x.autocomplete||'')).toLowerCase();var sc=0;if(typ==='email')sc+=8;if(/email|e-mail|아이디|로그인|login|user|member/.test(key))sc+=12;if(/검색|search|추천/.test(key))sc-=30;if(sc>bestScore){bestScore=sc;u=x;}}" +
                "if(!u)return 'NO_ID_FIELD';" +
                "if((u.value||'')!==" + id + "||(p.value||'')!==" + pw + ")return 'VALUES_NOT_READY';" +
                "var scope=p.form||root;var bs=scope.querySelectorAll?scope.querySelectorAll('button,input[type=submit],a,[role=button]'):[];var b=null;" +
                "for(var m=0;m<bs.length;m++){if(!vis(bs[m]))continue;var q=tx(bs[m]).replace(/\\s/g,'');if(q==='로그인'||q==='로그인하기'){b=bs[m];break;}}" +
                "if(!b&&p.form)b=p.form.querySelector('button[type=submit],input[type=submit]');" +
                "if(b){if(b.disabled||b.getAttribute('aria-disabled')==='true')return 'SUBMIT_DISABLED';b.focus();try{b.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));b.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));}catch(x){}b.click();return 'SUBMITTED_BUTTON';}" +
                "if(p.form){if(p.form.requestSubmit)p.form.requestSubmit();else p.form.submit();return 'SUBMITTED_FORM';}" +
                "return 'NO_SUBMIT';" +
                "}catch(e){return 'ERROR:'+e;}})()";
        try {
            webView.evaluateJavascript(js, raw -> {
                String r = decode(raw);
                if (r.startsWith("SUBMITTED_")) {
                    if (callback != null) callback.onResult(true, r);
                    return;
                }
                if ("FORM_GONE".equals(r)) {
                    // The page moved between fill and submit. Treat that as a likely completed
                    // login transition; the caller still verifies authenticated usage before success.
                    if (callback != null) callback.onResult(true, "SUBMITTED_FORM_GONE");
                    return;
                }
                if (("SUBMIT_DISABLED".equals(r) || "VALUES_NOT_READY".equals(r)) && attempt < 10) {
                    MAIN.postDelayed(() -> submitFilled(webView, c, callback, attempt + 1, offscreen),
                            offscreen ? 140L : 180L);
                    return;
                }
                if (callback != null) callback.onResult(false, r);
            });
        } catch (Throwable t) {
            if (callback != null) callback.onResult(false, "ERROR:" + t.getClass().getSimpleName());
        }
    }

    private static String decode(String result) {
        if (result == null || "null".equals(result)) return "";
        String r = result;
        if (r.startsWith("\"") && r.endsWith("\"") && r.length() >= 2) {
            r = r.substring(1, r.length() - 1);
        }
        return r.replace("\\\"", "\"").replace("\\\\", "\\");
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.webkit.WebView;

import org.json.JSONObject;

/**
 * DOM based auto-login helper for EyesMobile.
 *
 * v6.6 deliberately targets the currently visible login UI instead of assuming the email field,
 * password field and submit button live under the same small parent node. EyesMobile keeps many
 * account/password dialogs in the page DOM at once, so narrow parent searches could select the
 * wrong control or miss the real login email field after a long-idle session.
 */
public final class AutoLoginHelper {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final int MAX_OPEN_ATTEMPTS = 10;
    private static final int OFFSCREEN_MAX_OPEN_ATTEMPTS = 6;

    private AutoLoginHelper() {}

    public interface Callback {
        void onResult(boolean submitted, String detail);
    }

    public static boolean hasCredentials(Context context) {
        return SecureCredentialStore.isEnabled(context);
    }

    public static void tryLogin(Context context, WebView webView, Callback callback) {
        tryLoginInternal(context, webView, false, callback);
    }

    /** Login entry point used by the home-screen widget's off-screen WebView. */
    public static void tryLoginOffscreen(Context context, WebView webView, Callback callback) {
        tryLoginInternal(context, webView, true, callback);
    }

    /**
     * Native Enter fallback used only when the site left the filled login UI on screen after a
     * programmatic button click. Android delivers this to WebView as a real key event, which also
     * covers frameworks that ignore synthetic JavaScript click events.
     */
    public static void tryNativeSubmit(Context context, WebView webView, Callback callback) {
        SecureCredentialStore.Credentials c = SecureCredentialStore.load(context);
        if (webView == null) {
            if (callback != null) callback.onResult(false, "NO_WEBVIEW");
            return;
        }
        if (c == null) {
            if (callback != null) callback.onResult(false,
                    SecureCredentialStore.isEnabled(context)
                            ? "CREDENTIAL_READ_ERROR:" + SecureCredentialStore.getLastLoadError()
                            : "NO_CREDENTIALS");
            return;
        }
        nativeSubmit(webView, c, callback);
    }

    private static void tryLoginInternal(Context context,
                                         WebView webView,
                                         boolean offscreen,
                                         Callback callback) {
        SecureCredentialStore.Credentials c = SecureCredentialStore.load(context);
        if (webView == null) {
            if (callback != null) callback.onResult(false, "NO_WEBVIEW");
            return;
        }
        if (c == null) {
            if (callback != null) {
                if (SecureCredentialStore.isEnabled(context)) {
                    String reason = SecureCredentialStore.getLastLoadError();
                    callback.onResult(false, "CREDENTIAL_READ_ERROR" +
                            (reason == null || reason.isEmpty() ? "" : ":" + reason));
                } else {
                    callback.onResult(false, "NO_CREDENTIALS");
                }
            }
            return;
        }
        attempt(webView, c, callback, 0, offscreen);
    }

    private static String helpers(boolean offscreen) {
        String off = offscreen ? "true" : "false";
        return "var OFFSCREEN=" + off + ";" +
                "function cssok(e){if(!e)return false;try{var n=e;while(n&&n!==document){var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden'||s.opacity==='0')return false;n=n.parentElement;}return true;}catch(x){return true;}}" +
                "function vis(e){if(!cssok(e))return false;if(OFFSCREEN)return true;try{var r=e.getBoundingClientRect();return r.width>0&&r.height>0;}catch(x){return true;}}" +
                "function tx(e){return ((e&&((e.innerText||e.value||e.textContent)||''))+'').replace(/\\s+/g,' ').trim();}" +
                "function meta(e){return (((e&&e.name)||'')+' '+((e&&e.id)||'')+' '+((e&&e.placeholder)||'')+' '+((e&&e.autocomplete)||'')+' '+((e&&e.className)||'')).toLowerCase();}" +
                "function badPw(e){var z=(meta(e)+' '+tx(e&&e.parentElement)).toLowerCase();return /신규|재확인|확인용|new\\s*password|confirm|비밀번호\\s*변경|회원가입/.test(z);}" +
                "function boxOf(e){try{return e.closest('[role=dialog],dialog,[class*=modal],[class*=popup],[class*=layer],[class*=login],[id*=login]')||e.form||document;}catch(x){return e.form||document;}}" +
                "function pickPw(){var a=document.querySelectorAll('input[type=password]'),best=null,bs=-9999;for(var i=0;i<a.length;i++){var e=a[i];if(!vis(e)||badPw(e))continue;var k=meta(e),s=0;if((e.autocomplete||'').toLowerCase()==='current-password')s+=120;if(/비밀번호|password/.test(k))s+=85;if(/passwd|pass|pw/.test(k))s+=35;var b=boxOf(e);if(b&&b!==document)s+=25;if(s>bs){bs=s;best=e;}}return best;}" +
                "function pickUser(p){var a=document.querySelectorAll('input'),best=null,bs=-9999,box=boxOf(p);for(var i=0;i<a.length;i++){var e=a[i];if(e===p||!vis(e))continue;var typ=(e.type||'text').toLowerCase();if(typ==='hidden'||typ==='password'||typ==='submit'||typ==='button'||typ==='checkbox'||typ==='radio'||typ==='tel'||typ==='number'||typ==='date')continue;var k=meta(e),ph=(e.placeholder||'').replace(/\\s/g,'').toLowerCase(),s=0;if(ph==='아이디(이메일)'||ph==='아이디/이메일')s+=180;if(/아이디|이메일|email|e-mail/.test(k))s+=90;if(typ==='email')s+=80;if(/username|user|member|login/.test(k))s+=45;if((e.autocomplete||'').toLowerCase()==='username')s+=100;if(p&&p.form&&e.form===p.form)s+=180;if(box&&box!==document&&box.contains(e))s+=100;if(/검색|search|추천|닉네임|생년월일|휴대폰|회원가입/.test(k+' '+tx(e.parentElement)))s-=160;if(s>bs){bs=s;best=e;}}return best;}" +
                "function pickSubmit(p){var box=boxOf(p),all=document.querySelectorAll('button,input[type=submit],input[type=button],a,[role=button]'),best=null,bs=-9999;for(var i=0;i<all.length;i++){var e=all[i];if(!vis(e))continue;var q=tx(e).replace(/\\s/g,''),k=meta(e),s=0;if(q==='로그인')s+=220;else if(q==='로그인하기')s+=210;else if(/login|signin|sign-in/.test(k))s+=80;else continue;if(p&&p.form&&e.form===p.form)s+=160;if(box&&box!==document&&box.contains(e))s+=100;if(/찾기|재설정|회원가입/.test(q+' '+tx(e.parentElement)))s-=180;if(s>bs){bs=s;best=e;}}return best;}" +
                "function nativeSet(el,v){try{var d=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value');if(d&&d.set)d.set.call(el,v);else el.value=v;}catch(q){el.value=v;}}" +
                "function emit(el,name){try{if(name==='input'&&window.InputEvent)el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:null}));else el.dispatchEvent(new Event(name,{bubbles:true,cancelable:true}));}catch(x){try{el.dispatchEvent(new Event(name,{bubbles:true}));}catch(y){}}}" +
                "function fill(el,v){try{el.focus();}catch(x){}nativeSet(el,v);emit(el,'beforeinput');emit(el,'input');emit(el,'keyup');emit(el,'change');try{el.blur();}catch(x){}}";
    }

    private static void attempt(WebView webView,
                                SecureCredentialStore.Credentials c,
                                Callback callback,
                                int attempt,
                                boolean offscreen) {
        if (webView == null) {
            if (callback != null) callback.onResult(false, "NO_WEBVIEW");
            return;
        }

        String id = JSONObject.quote(c.userId);
        String pw = JSONObject.quote(c.password);
        String js = "(function(){try{" + helpers(offscreen) +
                "var p=pickPw();" +
                "if(!p){var all=document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit]'),b=null,bs=-9999;for(var i=0;i<all.length;i++){var e=all[i];if(!vis(e))continue;var q=tx(e).replace(/\\s/g,''),k=meta(e),s=0;if(q==='로그인')s+=220;else if(q==='로그인하기')s+=210;else if(/login|signin|sign-in/.test(k))s+=60;else continue;if(/찾기|재설정|회원가입/.test(q+' '+tx(e.parentElement)))s-=180;if(s>bs){bs=s;b=e;}}if(b){try{b.focus();}catch(x){}b.click();return 'OPENED_LOGIN';}return 'NO_LOGIN_UI';}" +
                "var u=pickUser(p);if(!u)return 'NO_ID_FIELD';" +
                "fill(u," + id + ");fill(p," + pw + ");" +
                "try{p.focus();}catch(x){}" +
                "return 'FILLED';" +
                "}catch(e){return 'ERROR:'+e;}})()";

        try {
            webView.evaluateJavascript(js, result -> {
                String r = decode(result);
                if ("FILLED".equals(r)) {
                    long settle = offscreen ? 260L : 360L;
                    MAIN.postDelayed(() -> submitFilled(webView, c, callback, 0, offscreen), settle);
                    return;
                }
                int maxOpenAttempts = offscreen ? OFFSCREEN_MAX_OPEN_ATTEMPTS : MAX_OPEN_ATTEMPTS;
                if ("OPENED_LOGIN".equals(r) && attempt < maxOpenAttempts) {
                    long delay = offscreen ? 180L : 360L;
                    MAIN.postDelayed(() -> attempt(webView, c, callback, attempt + 1, offscreen), delay);
                    return;
                }
                if ("NO_LOGIN_UI".equals(r) && attempt < maxOpenAttempts) {
                    long delay = offscreen ? 180L : 320L;
                    MAIN.postDelayed(() -> attempt(webView, c, callback, attempt + 1, offscreen), delay);
                    return;
                }
                if ("NO_ID_FIELD".equals(r) && attempt < maxOpenAttempts) {
                    MAIN.postDelayed(() -> attempt(webView, c, callback, attempt + 1, offscreen),
                            offscreen ? 180L : 300L);
                    return;
                }
                if (callback != null) callback.onResult(false, r);
            });
        } catch (Throwable t) {
            if (callback != null) callback.onResult(false, "ERROR:" + t.getClass().getSimpleName());
        }
    }

    private static void submitFilled(WebView webView,
                                     SecureCredentialStore.Credentials c,
                                     Callback callback,
                                     int attempt,
                                     boolean offscreen) {
        if (webView == null) {
            if (callback != null) callback.onResult(false, "NO_WEBVIEW");
            return;
        }
        String id = JSONObject.quote(c.userId);
        String pw = JSONObject.quote(c.password);
        String js = "(function(){try{" + helpers(offscreen) +
                "var p=pickPw();if(!p)return 'FORM_GONE';var u=pickUser(p);if(!u)return 'NO_ID_FIELD';" +
                "if((u.value||'')!==" + id + "||(p.value||'')!==" + pw + "){fill(u," + id + ");fill(p," + pw + ");return 'VALUES_NOT_READY';}" +
                "var b=pickSubmit(p);" +
                "if(b){if(b.disabled||b.getAttribute('aria-disabled')==='true'){try{p.focus();}catch(x){}return 'SUBMIT_DISABLED';}" +
                "try{b.focus();if(window.PointerEvent){b.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true,pointerType:'touch'}));b.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,cancelable:true,pointerType:'touch'}));}b.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));b.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));}catch(x){}b.click();return 'SUBMITTED_BUTTON';}" +
                "if(p.form){try{if(p.form.requestSubmit)p.form.requestSubmit();else p.form.submit();return 'SUBMITTED_FORM';}catch(x){}}" +
                "try{p.focus();}catch(x){}return 'NO_SUBMIT';" +
                "}catch(e){return 'ERROR:'+e;}})()";
        try {
            webView.evaluateJavascript(js, raw -> {
                String r = decode(raw);
                if (r.startsWith("SUBMITTED_")) {
                    if (callback != null) callback.onResult(true, r);
                    return;
                }
                if ("FORM_GONE".equals(r)) {
                    if (callback != null) callback.onResult(true, "SUBMITTED_FORM_GONE");
                    return;
                }
                if (("SUBMIT_DISABLED".equals(r) || "VALUES_NOT_READY".equals(r)) && attempt < 12) {
                    MAIN.postDelayed(() -> submitFilled(webView, c, callback, attempt + 1, offscreen),
                            offscreen ? 180L : 220L);
                    return;
                }
                if (("SUBMIT_DISABLED".equals(r) || "NO_SUBMIT".equals(r)) && !offscreen) {
                    nativeSubmit(webView, c, callback);
                    return;
                }
                if (callback != null) callback.onResult(false, r);
            });
        } catch (Throwable t) {
            if (callback != null) callback.onResult(false, "ERROR:" + t.getClass().getSimpleName());
        }
    }

    private static void nativeSubmit(WebView webView,
                                     SecureCredentialStore.Credentials c,
                                     Callback callback) {
        if (webView == null) {
            if (callback != null) callback.onResult(false, "NO_WEBVIEW");
            return;
        }
        String id = JSONObject.quote(c.userId);
        String pw = JSONObject.quote(c.password);
        String js = "(function(){try{" + helpers(false) +
                "var p=pickPw();if(!p)return 'NATIVE_NO_PASSWORD';var u=pickUser(p);if(!u)return 'NATIVE_NO_ID';" +
                "if((u.value||'')!==" + id + "||(p.value||'')!==" + pw + "){fill(u," + id + ");fill(p," + pw + ");}" +
                "p.focus();return 'NATIVE_FOCUSED';" +
                "}catch(e){return 'ERROR:'+e;}})()";
        try {
            webView.evaluateJavascript(js, raw -> {
                String r = decode(raw);
                if (!"NATIVE_FOCUSED".equals(r)) {
                    if (callback != null) callback.onResult(false, r);
                    return;
                }
                MAIN.postDelayed(() -> {
                    try {
                        webView.requestFocus();
                        webView.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
                        webView.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
                        if (callback != null) callback.onResult(true, "SUBMITTED_NATIVE_ENTER");
                    } catch (Throwable t) {
                        if (callback != null) callback.onResult(false,
                                "NATIVE_ERROR:" + t.getClass().getSimpleName());
                    }
                }, 80L);
            });
        } catch (Throwable t) {
            if (callback != null) callback.onResult(false, "ERROR:" + t.getClass().getSimpleName());
        }
    }

    private static String decode(String result) {
        if (result == null || "null".equals(result)) return "";
        String r = result;
        if (r.startsWith("\"") && r.endsWith("\"") && r.length() >= 2) {
            r = r.substring(1, r.length() - 1);
        }
        return r.replace("\\\"", "\"").replace("\\\\", "\\");
    }
}

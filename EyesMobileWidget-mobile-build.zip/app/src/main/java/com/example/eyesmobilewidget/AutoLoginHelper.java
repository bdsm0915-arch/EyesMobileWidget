package com.example.eyesmobilewidget;

import android.content.Context;
import android.webkit.WebView;

import org.json.JSONObject;

/** Generic DOM based auto-login helper for the EyesMobile login page. */
public final class AutoLoginHelper {
    private AutoLoginHelper() {}

    public interface Callback {
        void onResult(boolean submitted, String detail);
    }

    public static boolean hasCredentials(Context context) {
        return SecureCredentialStore.isEnabled(context);
    }

    public static void tryLogin(Context context, WebView webView, Callback callback) {
        SecureCredentialStore.Credentials c = SecureCredentialStore.load(context);
        if (webView == null || c == null) {
            if (callback != null) callback.onResult(false, "NO_CREDENTIALS");
            return;
        }

        String id = JSONObject.quote(c.userId);
        String pw = JSONObject.quote(c.password);
        String js = "(function(){try{" +
                "var p=document.querySelector('input[type=password]');" +
                "if(!p)return 'NO_PASSWORD_FIELD';" +
                "var root=p.form||p.closest('form')||document;" +
                "var inputs=root.querySelectorAll('input');var u=null;" +
                "for(var i=0;i<inputs.length;i++){var x=inputs[i];var t=(x.type||'text').toLowerCase();" +
                "if(x===p||t==='hidden'||t==='password'||t==='submit'||t==='button'||t==='checkbox'||t==='radio')continue;" +
                "var key=((x.name||'')+' '+(x.id||'')+' '+(x.placeholder||'')).toLowerCase();" +
                "if(!u)u=x;if(/id|user|login|member|email|phone|mobile|hp|아이디|이메일|휴대폰/.test(key)){u=x;break;}}" +
                "if(!u)return 'NO_ID_FIELD';" +
                "function setv(el,v){var proto=Object.getPrototypeOf(el);var d=Object.getOwnPropertyDescriptor(proto,'value');" +
                "if(d&&d.set)d.set.call(el,v);else el.value=v;" +
                "el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}" +
                "setv(u," + id + ");setv(p," + pw + ");" +
                "var b=(p.form||root).querySelector('button[type=submit],input[type=submit]');" +
                "if(!b){var bs=(p.form||root).querySelectorAll('button,a');for(var j=0;j<bs.length;j++){" +
                "var tx=(bs[j].innerText||bs[j].value||'').replace(/\\s/g,'');if(tx.indexOf('로그인')>=0){b=bs[j];break;}}}" +
                "if(b){b.click();return 'SUBMITTED_BUTTON';}" +
                "if(p.form){if(p.form.requestSubmit)p.form.requestSubmit();else p.form.submit();return 'SUBMITTED_FORM';}" +
                "return 'NO_SUBMIT';" +
                "}catch(e){return 'ERROR:'+e;}})()";

        webView.evaluateJavascript(js, result -> {
            String r = result == null ? "" : result.replace("\"", "");
            boolean ok = r.contains("SUBMITTED_");
            if (callback != null) callback.onResult(ok, r);
        });
    }
}

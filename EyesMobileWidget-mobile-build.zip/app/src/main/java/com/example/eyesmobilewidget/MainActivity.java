package com.example.eyesmobilewidget;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int ACCENT = Color.rgb(126, 103, 248);
    private static final int LAVENDER = Color.rgb(246, 241, 255);
    private static final int INK = Color.rgb(27, 22, 52);

    private WebView webView;
    private TextView status;
    private TextView lavenderChoice;
    private TextView darkChoice;
    private TextView transparencyValue;
    private LinearLayout previewBody;
    private ImageView previewDataGauge;
    private ImageView previewVoiceGauge;
    private ImageView previewSmsGauge;
    private TextView previewDataCaption;
    private TextView previewVoiceCaption;
    private TextView previewSmsCaption;
    private LinearLayout settingsPanel;
    private TextView togglePanelButton;
    private boolean settingsCollapsed = true;
    private boolean recoveryAttempted = false;
    private boolean bootstrappingSession = false;
    private boolean confirmedLoggedIn = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LAVENDER);

        root.addView(buildTopBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        root.addView(buildQuickActionRow(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        settingsPanel = buildSettingsPanel();
        root.addView(settingsPanel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView loginTitle = new TextView(this);
        loginTitle.setText("아이즈모바일 로그인 / 사용량 조회");
        loginTitle.setTextColor(INK);
        loginTitle.setTextSize(13);
        loginTitle.setTypeface(null, Typeface.BOLD);
        loginTitle.setPadding(dp(14), dp(9), dp(14), dp(4));
        root.addView(loginTitle);

        status = new TextView(this);
        status.setText("로그인 세션 보호 모드 · 위젯 새로고침은 화면을 열지 않고 백그라운드에서 처리됩니다.");
        status.setTextColor(Color.rgb(105, 100, 128));
        status.setTextSize(11);
        status.setPadding(dp(14), dp(4), dp(14), dp(7));
        root.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        String webUa = settings.getUserAgentString();
        SessionCookieStore.saveUserAgent(getApplicationContext(), webUa);

        android.webkit.CookieManager.getInstance().setAcceptCookie(true);
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        SessionCookieStore.restoreIfMissing(getApplicationContext());

        webView.addJavascriptInterface(new PageBridge(), "EyesWidgetBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                SessionCookieStore.flush();

                if (bootstrappingSession && isEyesOrigin(url)) {
                    bootstrappingSession = false;
                    if (status != null) status.setText("저장된 로그인 세션 복원 중…");
                    WebSessionStateStore.restoreIntoWebView(getApplicationContext(), view, () -> {
                        SessionCookieStore.forceRestoreBackup(getApplicationContext());
                        SessionCookieStore.flush();
                        handler.postDelayed(() -> {
                            if (webView != null) webView.loadUrl(EyesMobileFetcher.MY_PAGE_URL);
                        }, 180L);
                    });
                    return;
                }

                status.setText("로그인된 웹 세션에서 사용량을 확인하는 중…");
                handler.postDelayed(MainActivity.this::capturePageText, 900);
            }
        });

        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);
        refreshPreview();
        setSettingsCollapsed(true);
        loadWithSessionBootstrap();
    }

    private View buildTopBar() {
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(18), 0, dp(12), 0);
        top.setBackgroundColor(Color.rgb(252, 251, 255));

        TextView title = new TextView(this);
        title.setText("위젯 설정");
        title.setGravity(Gravity.CENTER);
        title.setTextColor(INK);
        title.setTextSize(19);
        title.setTypeface(null, Typeface.BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

        TextView done = new TextView(this);
        done.setText("✓");
        done.setGravity(Gravity.CENTER);
        done.setTextColor(ACCENT);
        done.setTextSize(27);
        done.setTypeface(null, Typeface.BOLD);
        done.setOnClickListener(v -> {
            capturePageAndRefresh();
            Toast.makeText(this, "위젯 설정을 적용했습니다.", Toast.LENGTH_SHORT).show();
            setSettingsCollapsed(true);
        });
        top.addView(done, new LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.MATCH_PARENT));
        return top;
    }

    private View buildQuickActionRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(12), dp(8), dp(12), dp(4));
        row.setGravity(Gravity.CENTER_VERTICAL);

        togglePanelButton = actionButton("설정 펼치기");
        togglePanelButton.setOnClickListener(v -> setSettingsCollapsed(!settingsCollapsed));
        row.addView(togglePanelButton, new LinearLayout.LayoutParams(0, dp(40), 1));

        TextView focusLogin = actionButton("로그인 크게 보기");
        focusLogin.setOnClickListener(v -> {
            setSettingsCollapsed(true);
            if (status != null) status.setText("설정을 접었습니다. 아래 웹 화면에서 로그인하세요.");
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1);
        lp.setMargins(dp(8), 0, 0, 0);
        row.addView(focusLogin, lp);
        return row;
    }

    private LinearLayout buildSettingsPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(6), dp(12), dp(10));
        panel.setBackgroundColor(LAVENDER);

        panel.addView(buildPreviewCard(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(132)));

        TextView themeTitle = sectionTitle("위젯 테마");
        panel.addView(themeTitle);

        LinearLayout themeRow = new LinearLayout(this);
        themeRow.setGravity(Gravity.CENTER_VERTICAL);
        themeRow.setPadding(dp(4), dp(4), dp(4), dp(8));

        lavenderChoice = choiceButton("LAVENDER");
        lavenderChoice.setOnClickListener(v -> {
            WidgetAppearance.setDark(this, false);
            refreshAppearance();
        });
        themeRow.addView(lavenderChoice, new LinearLayout.LayoutParams(0, dp(42), 1));

        darkChoice = choiceButton("DARK");
        darkChoice.setOnClickListener(v -> {
            WidgetAppearance.setDark(this, true);
            refreshAppearance();
        });
        LinearLayout.LayoutParams darkLp = new LinearLayout.LayoutParams(0, dp(42), 1);
        darkLp.setMargins(dp(8), 0, 0, 0);
        themeRow.addView(darkChoice, darkLp);
        panel.addView(themeRow);

        TextView opacityTitle = sectionTitle("전체 투명도");
        panel.addView(opacityTitle);

        LinearLayout seekRow = new LinearLayout(this);
        seekRow.setGravity(Gravity.CENTER_VERTICAL);
        seekRow.setPadding(dp(6), 0, dp(4), dp(7));

        TextView min = new TextView(this);
        min.setText("0%");
        min.setTextColor(Color.rgb(105, 100, 128));
        min.setTextSize(10);
        seekRow.addView(min, new LinearLayout.LayoutParams(dp(34), dp(38)));

        SeekBar seek = new SeekBar(this);
        seek.setMax(60);
        seek.setProgress(WidgetAppearance.getTransparency(this));
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                WidgetAppearance.setTransparency(MainActivity.this, progress);
                if (transparencyValue != null) transparencyValue.setText(progress + "%");
                if (fromUser) refreshPreview();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                EyesMobileWidgetProvider.updateAll(getApplicationContext());
            }
        });
        seekRow.addView(seek, new LinearLayout.LayoutParams(0, dp(40), 1));

        transparencyValue = new TextView(this);
        transparencyValue.setGravity(Gravity.CENTER);
        transparencyValue.setTextColor(ACCENT);
        transparencyValue.setTextSize(11);
        transparencyValue.setTypeface(null, Typeface.BOLD);
        transparencyValue.setText(WidgetAppearance.getTransparency(this) + "%");
        seekRow.addView(transparencyValue, new LinearLayout.LayoutParams(dp(46), dp(38)));
        panel.addView(seekRow);

        TextView colorTitle = sectionTitle("글자 색상");
        panel.addView(colorTitle);

        LinearLayout colors = new LinearLayout(this);
        colors.setGravity(Gravity.CENTER);
        colors.setOrientation(LinearLayout.HORIZONTAL);
        int[] choices = WidgetAppearance.colorChoices();
        for (int color : choices) {
            TextView swatch = new TextView(this);
            swatch.setGravity(Gravity.CENTER);
            swatch.setText(color == WidgetAppearance.getTextColor(this) ? "✓" : "");
            swatch.setTextColor(contrast(color));
            swatch.setTextSize(18);
            swatch.setTypeface(null, Typeface.BOLD);
            swatch.setBackground(roundRect(color, 9, Color.rgb(217, 211, 240), 1));
            swatch.setOnClickListener(v -> {
                WidgetAppearance.setTextColor(MainActivity.this, color);
                refreshAppearance();
                rebuildSwatchChecks(colors);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1);
            lp.setMargins(dp(3), 0, dp(3), 0);
            colors.addView(swatch, lp);
        }
        panel.addView(colors, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        return panel;
    }

    private TextView sectionTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(INK);
        tv.setTextSize(12);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setPadding(dp(6), dp(8), dp(4), dp(3));
        return tv;
    }

    private View buildPreviewCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(8), dp(8), dp(8), dp(8));
        card.setBackground(roundRect(Color.rgb(252, 251, 255), 18, Color.rgb(221, 214, 255), 1));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), 0, dp(4), 0);

        TextView brand = new TextView(this);
        brand.setText("아이즈모바일\nMOVE, BETTER");
        brand.setTextColor(INK);
        brand.setTextSize(10);
        brand.setTypeface(null, Typeface.BOLD);
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(32), 1));

        TextView icons = new TextView(this);
        icons.setText("↻   ⚙");
        icons.setTextColor(ACCENT);
        icons.setTextSize(15);
        icons.setGravity(Gravity.CENTER);
        header.addView(icons, new LinearLayout.LayoutParams(dp(72), dp(32)));
        card.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(32)));

        previewBody = new LinearLayout(this);
        previewBody.setOrientation(LinearLayout.HORIZONTAL);
        previewBody.setGravity(Gravity.CENTER);
        previewBody.setPadding(dp(2), dp(3), dp(2), dp(2));

        PreviewColumn data = previewColumn("데이터");
        previewDataGauge = data.gauge;
        previewDataCaption = data.caption;
        previewBody.addView(data.root, previewLp(1));

        PreviewColumn voice = previewColumn("음성");
        previewVoiceGauge = voice.gauge;
        previewVoiceCaption = voice.caption;
        previewBody.addView(voice.root, previewLp(1));

        PreviewColumn sms = previewColumn("문자");
        previewSmsGauge = sms.gauge;
        previewSmsCaption = sms.caption;
        previewBody.addView(sms.root, previewLp(1));

        card.addView(previewBody, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return card;
    }

    private LinearLayout.LayoutParams previewLp(int weight) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private PreviewColumn previewColumn(String titleText) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(dp(3), dp(3), dp(3), dp(3));

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(9);
        title.setTypeface(null, Typeface.BOLD);
        col.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18)));

        ImageView gauge = new ImageView(this);
        gauge.setScaleType(ImageView.ScaleType.FIT_CENTER);
        col.addView(gauge, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        TextView caption = new TextView(this);
        caption.setGravity(Gravity.CENTER);
        caption.setTextSize(8);
        caption.setTypeface(null, Typeface.BOLD);
        col.addView(caption, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(18)));
        return new PreviewColumn(col, gauge, caption, title);
    }

    private void refreshAppearance() {
        refreshPreview();
        EyesMobileWidgetProvider.updateAll(getApplicationContext());
    }

    private void refreshPreview() {
        if (previewBody == null) return;
        boolean dark = WidgetAppearance.isDark(this);
        int textColor = WidgetAppearance.getTextColor(this);
        int trackColor = WidgetAppearance.getTrackColor(this);
        int cardColor = WidgetAppearance.getCardColor(this);
        UsageData d = WidgetStorage.load(this);

        previewBody.setAlpha(Math.max(0.40f, 1f - (WidgetAppearance.getTransparency(this) / 100f)));
        for (int i = 0; i < previewBody.getChildCount(); i++) {
            View child = previewBody.getChildAt(i);
            child.setBackground(roundRect(cardColor, 12, dark ? Color.rgb(53,57,76) : Color.rgb(233,229,251), 1));
            if (child instanceof LinearLayout) {
                LinearLayout col = (LinearLayout) child;
                if (col.getChildCount() > 0 && col.getChildAt(0) instanceof TextView) {
                    ((TextView) col.getChildAt(0)).setTextColor(textColor);
                }
            }
        }

        previewDataCaption.setText(GaugeRenderer.caption("데이터", d.dataUsed, d.dataTotal));
        previewVoiceCaption.setText(GaugeRenderer.caption("음성", d.voiceUsed, d.voiceTotal));
        previewSmsCaption.setText(GaugeRenderer.caption("문자", d.smsUsed, d.smsTotal));
        previewDataCaption.setTextColor(textColor);
        previewVoiceCaption.setTextColor(textColor);
        previewSmsCaption.setTextColor(textColor);

        previewDataGauge.setImageBitmap(GaugeRenderer.renderGauge(this, d.dataPercent,
                GaugeRenderer.topLabel(d.dataUsed, d.dataTotal, true),
                GaugeRenderer.mainDisplay("데이터", d.dataUsed, d.dataTotal), textColor, trackColor, true));
        previewVoiceGauge.setImageBitmap(GaugeRenderer.renderGauge(this, d.voicePercent,
                GaugeRenderer.topLabel(d.voiceUsed, d.voiceTotal, false),
                GaugeRenderer.mainDisplay("음성", d.voiceUsed, d.voiceTotal), textColor, trackColor, false));
        previewSmsGauge.setImageBitmap(GaugeRenderer.renderGauge(this, d.smsPercent,
                GaugeRenderer.topLabel(d.smsUsed, d.smsTotal, false),
                GaugeRenderer.mainDisplay("문자", d.smsUsed, d.smsTotal), textColor, trackColor, false));

        if (lavenderChoice != null) lavenderChoice.setText((!dark ? "✓ " : "") + "LAVENDER");
        if (darkChoice != null) darkChoice.setText((dark ? "✓ " : "") + "DARK");
    }

    private void setSettingsCollapsed(boolean collapsed) {
        settingsCollapsed = collapsed;
        if (settingsPanel != null) settingsPanel.setVisibility(collapsed ? View.GONE : View.VISIBLE);
        if (togglePanelButton != null) togglePanelButton.setText(collapsed ? "설정 펼치기" : "설정 접기");
    }

    private TextView choiceButton(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(11);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(INK);
        tv.setBackground(roundRect(Color.rgb(252, 251, 255), 10, Color.rgb(211, 203, 245), 1));
        return tv;
    }

    private TextView actionButton(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(11);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(INK);
        tv.setBackground(roundRect(Color.rgb(252, 251, 255), 12, Color.rgb(211, 203, 245), 1));
        return tv;
    }

    private void rebuildSwatchChecks(LinearLayout colors) {
        int selected = WidgetAppearance.getTextColor(this);
        int[] choices = WidgetAppearance.colorChoices();
        for (int i = 0; i < colors.getChildCount() && i < choices.length; i++) {
            TextView v = (TextView) colors.getChildAt(i);
            v.setText(choices[i] == selected ? "✓" : "");
        }
    }

    private void capturePageAndRefresh() {
        if (status != null) status.setText("현재 로그인된 웹 화면에서 사용량을 읽는 중…");
        capturePageText();
    }

    private void capturePageText() {
        if (webView == null) return;
        webView.evaluateJavascript(
                "(function(){try{return document.body ? document.body.innerText : '';}catch(e){return '';}})()",
                value -> {
                    String text = decodeJsString(value);
                    if (text != null && !text.isEmpty()) handlePageText(text);
                });
    }

    private void handlePageText(String text) {
        UsageData data = UsageParser.parse(text);
        if (data != null) {
            // Only a confirmed usage page is allowed to replace the good-session backup.
            confirmedLoggedIn = true;
            recoveryAttempted = false;
            SessionCookieStore.backup(getApplicationContext());
            WebSessionStateStore.backupFromWebView(getApplicationContext(), webView);
            SessionCookieStore.flush();
            SessionKeepAliveScheduler.schedule(getApplicationContext());
            WidgetStorage.save(getApplicationContext(), data);
            WidgetStorage.setStatus(getApplicationContext(), "최신 사용량");
            EyesMobileWidgetProvider.updateAll(getApplicationContext());
            refreshPreview();
            if (status != null) status.setText("사용량을 읽어 위젯에 반영했습니다. 로그인 세션도 정상입니다.");
            return;
        }

        if (!recoveryAttempted && looksLoggedOut(text)
                && (SessionCookieStore.hasBackup(getApplicationContext())
                || WebSessionStateStore.hasSnapshot(getApplicationContext()))) {
            recoveryAttempted = true;
            confirmedLoggedIn = false;
            if (status != null) status.setText("로그인 세션을 쿠키 + 웹 저장소에서 복원 중…");
            SessionCookieStore.forceRestoreBackup(getApplicationContext());
            SessionCookieStore.flush();
            loadWithSessionBootstrap();
        } else if (looksLoggedOut(text)) {
            confirmedLoggedIn = false;
            if (status != null) status.setText("서버가 저장된 세션을 거부했습니다. 다시 로그인해 주세요.");
            WidgetStorage.setStatus(getApplicationContext(), "로그인 세션 만료 · 다시 로그인 필요");
            EyesMobileWidgetProvider.updateAll(getApplicationContext());
        }
    }

    private void loadWithSessionBootstrap() {
        if (webView == null) return;
        SessionCookieStore.restoreIfMissing(getApplicationContext());
        SessionCookieStore.flush();
        if (SessionCookieStore.hasBackup(getApplicationContext())
                || WebSessionStateStore.hasSnapshot(getApplicationContext())) {
            bootstrappingSession = true;
            webView.loadUrl(SessionCookieStore.URL_WWW);
        } else {
            bootstrappingSession = false;
            webView.loadUrl(EyesMobileFetcher.MY_PAGE_URL);
        }
    }

    private boolean isEyesOrigin(String url) {
        if (url == null) return false;
        String u = url.toLowerCase(java.util.Locale.ROOT);
        return u.startsWith("https://www.eyes.co.kr/") || u.startsWith("https://eyes.co.kr/");
    }

    private boolean looksLoggedOut(String text) {
        if (text == null) return false;
        String t = text.toLowerCase(java.util.Locale.ROOT);
        return t.contains("로그인") && (t.contains("비밀번호") || t.contains("아이디") || t.contains("회원가입"));
    }

    private String decodeJsString(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            if (value.startsWith("\"") && value.endsWith("\"")) value = value.substring(1, value.length() - 1);
            return value.replace("\\n", "\n")
                    .replace("\\r", "\r")
                    .replace("\\t", "\t")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\u003C", "<")
                    .replace("\\u003E", ">");
        } catch (Exception e) {
            return value;
        }
    }

    @Override
    protected void onPause() {
        if (confirmedLoggedIn && webView != null) {
            SessionCookieStore.backup(getApplicationContext());
            WebSessionStateStore.backupFromWebView(getApplicationContext(), webView);
        }
        SessionCookieStore.flush();
        super.onPause();
    }

    @Override
    protected void onStop() {
        SessionCookieStore.flush();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        SessionCookieStore.flush();
        if (webView != null) {
            webView.removeJavascriptInterface("EyesWidgetBridge");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private GradientDrawable roundRect(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private int contrast(int color) {
        double lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color));
        return lum > 150 ? Color.BLACK : Color.WHITE;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private final class PageBridge {
        @JavascriptInterface
        public void onPageText(String text) {
            runOnUiThread(() -> handlePageText(text));
        }
    }

    private static final class PreviewColumn {
        final LinearLayout root;
        final ImageView gauge;
        final TextView caption;
        final TextView title;
        PreviewColumn(LinearLayout root, ImageView gauge, TextView caption, TextView title) {
            this.root = root;
            this.gauge = gauge;
            this.caption = caption;
            this.title = title;
        }
    }
}

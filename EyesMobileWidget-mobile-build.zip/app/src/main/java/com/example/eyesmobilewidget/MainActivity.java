package com.example.eyesmobilewidget;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int ACCENT = Color.rgb(126, 103, 248);
    private static final int LAVENDER = Color.rgb(246, 241, 255);
    private static final int INK = Color.rgb(27, 22, 52);

    private WebView webView;
    private TextView status;
    private TextView lavenderChoice;
    private TextView darkChoice;
    private TextView transparencyValue;
    private LinearLayout previewBody;
    private ImageView previewDataGauge;
    private ImageView previewVoiceGauge;
    private ImageView previewSmsGauge;
    private TextView previewDataCaption;
    private TextView previewVoiceCaption;
    private TextView previewSmsCaption;
    private LinearLayout settingsPanel;
    private TextView togglePanelButton;
    private TextView autoLoginButton;
    private TextView autoRefreshChoice;
    private TextView autoRefreshStatus;
    private boolean settingsCollapsed = true;
    private boolean confirmedLoggedIn = false;
    private boolean autoLoginAttempted = false;
    private boolean usageNavigationAttempted = false;
    private int pageParseAttempts = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LAVENDER);

        root.addView(buildTopBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        root.addView(buildQuickActionRow(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        settingsPanel = buildSettingsPanel();
        root.addView(settingsPanel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView loginTitle = new TextView(this);
        loginTitle.setText("아이즈모바일 로그인 / 사용량 조회");
        loginTitle.setTextColor(INK);
        loginTitle.setTextSize(13);
        loginTitle.setTypeface(null, Typeface.BOLD);
        loginTitle.setPadding(dp(14), dp(9), dp(14), dp(4));
        root.addView(loginTitle);

        status = new TextView(this);
        status.setText("검증 세션 + 자동 재로그인 모드 · 정상 사용량 조회에 성공한 세션만 안전하게 복원합니다.");
        status.setTextColor(Color.rgb(105, 100, 128));
        status.setTextSize(11);
        status.setPadding(dp(14), dp(4), dp(14), dp(7));
        root.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.clearCache(true);
        String webUa = settings.getUserAgentString();
        SessionCookieStore.saveUserAgent(getApplicationContext(), webUa);

        android.webkit.CookieManager.getInstance().setAcceptCookie(true);
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        SessionCookieStore.migrateToLiveCookiePolicy(getApplicationContext());
        WebSessionStateStore.clear(getApplicationContext());
        VerifiedSessionStore.restoreMissing(getApplicationContext());
        SessionCookieStore.flush();

        webView.addJavascriptInterface(new PageBridge(), "EyesWidgetBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                SessionCookieStore.flush();
                status.setText("현재 로그인 세션에서 사용량을 확인하는 중…");
                handler.postDelayed(MainActivity.this::capturePageText, 1200);
            }
        });

        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);
        refreshPreview();
        setSettingsCollapsed(true);
        loadWithSessionBootstrap();
    }

    private View buildTopBar() {
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(18), 0, dp(12), 0);
        top.setBackgroundColor(Color.rgb(252, 251, 255));

        TextView title = new TextView(this);
        title.setText("위젯 설정");
        title.setGravity(Gravity.CENTER);
        title.setTextColor(INK);
        title.setTextSize(19);
        title.setTypeface(null, Typeface.BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

        TextView done = new TextView(this);
        done.setText("✓");
        done.setGravity(Gravity.CENTER);
        done.setTextColor(ACCENT);
        done.setTextSize(27);
        done.setTypeface(null, Typeface.BOLD);
        done.setOnClickListener(v -> {
            capturePageAndRefresh();
            Toast.makeText(this, "위젯 설정을 적용했습니다.", Toast.LENGTH_SHORT).show();
            setSettingsCollapsed(true);
        });
        top.addView(done, new LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.MATCH_PARENT));
        return top;
    }

    private View buildQuickActionRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(12), dp(8), dp(12), dp(4));
        row.setGravity(Gravity.CENTER_VERTICAL);

        togglePanelButton = actionButton("설정 펼치기");
        togglePanelButton.setOnClickListener(v -> setSettingsCollapsed(!settingsCollapsed));
        row.addView(togglePanelButton, new LinearLayout.LayoutParams(0, dp(40), 1));

        TextView focusLogin = actionButton("로그인 크게 보기");
        focusLogin.setOnClickListener(v -> {
            setSettingsCollapsed(true);
            if (status != null) status.setText("설정을 접었습니다. 아래 웹 화면에서 로그인하세요.");
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1);
        lp.setMargins(dp(8), 0, 0, 0);
        row.addView(focusLogin, lp);

        autoLoginButton = actionButton(AutoLoginHelper.hasCredentials(getApplicationContext())
                ? "자동 로그인 ON" : "자동 로그인 설정");
        autoLoginButton.setOnClickListener(v -> showAutoLoginDialog());
        LinearLayout.LayoutParams autoLp = new LinearLayout.LayoutParams(0, dp(40), 1);
        autoLp.setMargins(dp(8), 0, 0, 0);
        row.addView(autoLoginButton, autoLp);
        return row;
    }

    private LinearLayout buildSettingsPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(6), dp(12), dp(10));
        panel.setBackgroundColor(LAVENDER);

        panel.addView(buildPreviewCard(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(132)));

        TextView autoRefreshTitle = sectionTitle("위젯 자동 갱신");
        panel.addView(autoRefreshTitle);

        autoRefreshChoice = choiceButton(AutoRefreshScheduler.labelFor(
                AutoRefreshScheduler.getIntervalMinutes(this)));
        autoRefreshChoice.setOnClickListener(v -> showAutoRefreshDialog());
        LinearLayout.LayoutParams refreshLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        refreshLp.setMargins(dp(4), dp(4), dp(4), dp(8));
        panel.addView(autoRefreshChoice, refreshLp);

        autoRefreshStatus = new TextView(this);
        autoRefreshStatus.setTextColor(Color.rgb(105, 100, 128));
        autoRefreshStatus.setTextSize(10);
        autoRefreshStatus.setPadding(dp(8), 0, dp(8), dp(6));
        refreshAutoRefreshStatus();
        panel.addView(autoRefreshStatus, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView themeTitle = sectionTitle("위젯 테마");
        panel.addView(themeTitle);

        LinearLayout themeRow = new LinearLayout(this);
        themeRow.setGravity(Gravity.CENTER_VERTICAL);
        themeRow.setPadding(dp(4), dp(4), dp(4), dp(8));

        lavenderChoice = choiceButton("LAVENDER");
        lavenderChoice.setOnClickListener(v -> {
            WidgetAppearance.setDark(this, false);
            refreshAppearance();
        });
        themeRow.addView(lavenderChoice, new LinearLayout.LayoutParams(0, dp(42), 1));

        darkChoice = choiceButton("DARK");
        darkChoice.setOnClickListener(v -> {
            WidgetAppearance.setDark(this, true);
            refreshAppearance();
        });
        LinearLayout.LayoutParams darkLp = new LinearLayout.LayoutParams(0, dp(42), 1);
        darkLp.setMargins(dp(8), 0, 0, 0);
        themeRow.addView(darkChoice, darkLp);
        panel.addView(themeRow);

        TextView opacityTitle = sectionTitle("전체 투명도");
        panel.addView(opacityTitle);

        LinearLayout seekRow = new LinearLayout(this);
        seekRow.setGravity(Gravity.CENTER_VERTICAL);
        seekRow.setPadding(dp(6), 0, dp(4), dp(7));

        TextView min = new TextView(this);
        min.setText("0%");
        min.setTextColor(Color.rgb(105, 100, 128));
        min.setTextSize(10);
        seekRow.addView(min, new LinearLayout.LayoutParams(dp(34), dp(38)));

        SeekBar seek = new SeekBar(this);
        seek.setMax(60);
        seek.setProgress(WidgetAppearance.getTransparency(this));
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                WidgetAppearance.setTransparency(MainActivity.this, progress);
                if (transparencyValue != null) transparencyValue.setText(progress + "%");
                if (fromUser) refreshPreview();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                EyesMobileWidgetProvider.updateAll(getApplicationContext());
            }
        });
        seekRow.addView(seek, new LinearLayout.LayoutParams(0, dp(40), 1));

        transparencyValue = new TextView(this);
        transparencyValue.setGravity(Gravity.CENTER);
        transparencyValue.setTextColor(ACCENT);
        transparencyValue.setTextSize(11);
        transparencyValue.setTypeface(null, Typeface.BOLD);
        transparencyValue.setText(WidgetAppearance.getTransparency(this) + "%");
        seekRow.addView(transparencyValue, new LinearLayout.LayoutParams(dp(46), dp(38)));
        panel.addView(seekRow);

        TextView colorTitle = sectionTitle("글자 색상");
        panel.addView(colorTitle);

        LinearLayout colors = new LinearLayout(this);
        colors.setGravity(Gravity.CENTER);
        colors.setOrientation(LinearLayout.HORIZONTAL);
        int[] choices = WidgetAppearance.colorChoices();
        for (int color : choices) {
            TextView swatch = new TextView(this);
            swatch.setGravity(Gravity.CENTER);
            swatch.setText(color == WidgetAppearance.getTextColor(this) ? "✓" : "");
            swatch.setTextColor(contrast(color));
            swatch.setTextSize(18);
            swatch.setTypeface(null, Typeface.BOLD);
            swatch.setBackground(roundRect(color, 9, Color.rgb(217, 211, 240), 1));
            swatch.setOnClickListener(v -> {
                WidgetAppearance.setTextColor(MainActivity.this, color);
                refreshAppearance();
                rebuildSwatchChecks(colors);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1);
            lp.setMargins(dp(3), 0, dp(3), 0);
            colors.addView(swatch, lp);
        }
        panel.addView(colors, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        return panel;
    }

    @Override
    protected void onResume() {
        super.onResume();
        AutoRefreshScheduler.ensureScheduled(getApplicationContext());
        refreshAutoRefreshStatus();
        if (autoLoginButton != null) {
            autoLoginButton.setText(SecureCredentialStore.isEnabled(getApplicationContext())
                    ? "자동 로그인 ON" : "자동 로그인 설정");
        }
    }

    private void refreshAutoRefreshStatus() {
        if (autoRefreshStatus != null) {
            autoRefreshStatus.setText(AutoRefreshScheduler.statusSummary(getApplicationContext()));
        }
    }

    private void showAutoRefreshDialog() {
        final int[] values = AutoRefreshScheduler.choices();
        final String[] labels = new String[values.length];
        int current = AutoRefreshScheduler.getIntervalMinutes(this);
        int checked = 0;
        for (int i = 0; i < values.length; i++) {
            labels[i] = AutoRefreshScheduler.labelFor(values[i]);
            if (values[i] == current) checked = i;
        }

        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setTitle("위젯 자동 갱신")
                .setSingleChoiceItems(labels, checked, null)
                .setNegativeButton("취소", null)
                .create();

        dialog.setOnShowListener(ignored -> {
            android.widget.ListView list = dialog.getListView();
            list.setOnItemClickListener((parent, view, position, id) -> {
                int minutes = values[position];
                AutoRefreshScheduler.setIntervalMinutes(getApplicationContext(), minutes);
                if (autoRefreshChoice != null) {
                    autoRefreshChoice.setText(AutoRefreshScheduler.labelFor(minutes));
                }
                refreshAutoRefreshStatus();
                Toast.makeText(this, minutes == 0
                                ? "자동 갱신을 껐습니다."
                                : "자동 갱신: " + AutoRefreshScheduler.labelFor(minutes),
                        Toast.LENGTH_SHORT).show();
                dialog.dismiss();

                if (minutes > 0 && Build.VERSION.SDK_INT >= 31
                        && !AutoRefreshScheduler.canScheduleExact(getApplicationContext())) {
                    new android.app.AlertDialog.Builder(this)
                            .setTitle("자동 갱신 권한")
                            .setMessage("선택한 시간에 가깝게 자동 갱신하려면 ‘알람 및 리마인더’ 권한을 허용해주세요. 허용하지 않아도 자동 갱신은 동작하지만 절전 상태에서는 늦어질 수 있습니다.")
                            .setPositiveButton("허용", (d, w) -> {
                                try {
                                    Intent permissionIntent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                                    permissionIntent.setData(Uri.parse("package:" + getPackageName()));
                                    startActivity(permissionIntent);
                                } catch (Throwable ignored2) {
                                }
                            })
                            .setNegativeButton("나중에", null)
                            .show();
                }
            });
        });
        dialog.show();
    }

    private void showAutoLoginDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        boolean configured = SecureCredentialStore.isEnabled(getApplicationContext());
        SecureCredentialStore.Credentials existing = SecureCredentialStore.load(getApplicationContext());

        EditText id = new EditText(this);
        id.setSingleLine(true);
        id.setHint("아이디 / 로그인 계정");
        id.setText(existing == null ? "" : existing.userId);
        box.addView(id, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        EditText password = new EditText(this);
        password.setSingleLine(true);
        password.setHint(existing == null ? "비밀번호" : "비밀번호 · 저장되어 있음 (변경할 때만 입력)");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams pwLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        pwLp.setMargins(0, dp(6), 0, 0);
        box.addView(password, pwLp);

        TextView note = new TextView(this);
        note.setText("세션이 만료되면 저장된 계정으로 자동 재로그인합니다. 비밀번호는 Android Keystore로 암호화되어 이 휴대폰에만 저장됩니다.");
        note.setTextColor(Color.rgb(105, 100, 128));
        note.setTextSize(10);
        note.setPadding(0, dp(8), 0, 0);
        box.addView(note);

        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setTitle(configured ? "자동 로그인 ON" : "자동 로그인 설정")
                .setView(box)
                .setPositiveButton("암호화 저장", null)
                .setNeutralButton(configured ? "저장정보 삭제" : "", null)
                .setNegativeButton("취소", null)
                .create();

        dialog.setOnShowListener(ignored -> {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String userId = id.getText().toString().trim();
                String pw = password.getText().toString();
                SecureCredentialStore.Credentials saved = SecureCredentialStore.load(getApplicationContext());
                if (pw.isEmpty() && saved != null && userId.equals(saved.userId)) pw = saved.password;
                try {
                    SecureCredentialStore.save(getApplicationContext(), userId, pw);
                    autoLoginAttempted = false;
                    Toast.makeText(this, "자동 로그인을 암호화 저장했습니다.", Toast.LENGTH_SHORT).show();
                    if (status != null) status.setText("자동 로그인 ON · 세션이 풀려도 자동으로 다시 로그인합니다.");
                    if (autoLoginButton != null) autoLoginButton.setText("자동 로그인 ON");
                    dialog.dismiss();
                    if (webView != null) {
                        AutoLoginHelper.tryLogin(getApplicationContext(), webView, (submitted, detail) -> {
                            if (submitted) handler.postDelayed(() -> {
                                if (webView != null) UsageDomSnapshot.loadFresh(webView);
                            }, 1400L);
                        });
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "저장 실패: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });

            if (configured) {
                dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                    SecureCredentialStore.clear(getApplicationContext());
                    Toast.makeText(this, "저장된 자동 로그인 정보를 삭제했습니다.", Toast.LENGTH_SHORT).show();
                    if (autoLoginButton != null) autoLoginButton.setText("자동 로그인 설정");
                    dialog.dismiss();
                });
            } else {
                dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setVisibility(View.GONE);
            }
        });
        dialog.show();
    }

    private TextView sectionTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(INK);
        tv.setTextSize(12);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setPadding(dp(6), dp(8), dp(4), dp(3));
        return tv;
    }

    private View buildPreviewCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(8), dp(8), dp(8), dp(8));
        card.setBackground(roundRect(Color.rgb(252, 251, 255), 18, Color.rgb(221, 214, 255), 1));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), 0, dp(4), 0);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);

        ImageView symbol = new ImageView(this);
        symbol.setImageResource(R.drawable.eyes_symbol);
        symbol.setScaleType(ImageView.ScaleType.FIT_CENTER);
        brand.addView(symbol, new LinearLayout.LayoutParams(dp(28), dp(26)));

        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);

        ImageView wordmark = new ImageView(this);
        wordmark.setImageResource(R.drawable.eyes_wordmark);
        wordmark.setColorFilter(INK);
        wordmark.setScaleType(ImageView.ScaleType.FIT_START);
        brandText.addView(wordmark, new LinearLayout.LayoutParams(dp(101), dp(18)));

        ImageView tagline = new ImageView(this);
        tagline.setImageResource(R.drawable.eyes_tagline);
        tagline.setScaleType(ImageView.ScaleType.FIT_START);
        LinearLayout.LayoutParams taglineLp = new LinearLayout.LayoutParams(dp(78), dp(9));
        taglineLp.setMargins(0, dp(4), 0, 0);
        brandText.addView(tagline, taglineLp);

        LinearLayout.LayoutParams brandTextLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        brandTextLp.setMargins(dp(4), 0, 0, 0);
        brand.addView(brandText, brandTextLp);

        header.addView(brand, new LinearLayout.LayoutParams(0, dp(36), 1));

        TextView icons = new TextView(this);
        icons.setText("↻   ⚙");
        icons.setTextColor(ACCENT);
        icons.setTextSize(15);
        icons.setGravity(Gravity.CENTER);
        header.addView(icons, new LinearLayout.LayoutParams(dp(72), dp(32)));
        card.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));

        previewBody = new LinearLayout(this);
        previewBody.setOrientation(LinearLayout.HORIZONTAL);
        previewBody.setGravity(Gravity.CENTER);
        previewBody.setPadding(dp(2), dp(3), dp(2), dp(2));

        PreviewColumn data = previewColumn("데이터");
        previewDataGauge = data.gauge;
        previewDataCaption = data.caption;
        previewBody.addView(data.root, previewLp(1));

        PreviewColumn voice = previewColumn("음성");
        previewVoiceGauge = voice.gauge;
        previewVoiceCaption = voice.caption;
        previewBody.addView(voice.root, previewLp(1));

        PreviewColumn sms = previewColumn("문자");
        previewSmsGauge = sms.gauge;
        previewSmsCaption = sms.caption;
        previewBody.addView(sms.root, previewLp(1));

        card.addView(previewBody, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return card;
    }

    private LinearLayout.LayoutParams previewLp(int weight) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private PreviewColumn previewColumn(String titleText) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(dp(3), dp(3), dp(3), dp(3));

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(9);
        title.setTypeface(null, Typeface.BOLD);
        col.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18)));

        ImageView gauge = new ImageView(this);
        gauge.setScaleType(ImageView.ScaleType.FIT_CENTER);
        col.addView(gauge, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        TextView caption = new TextView(this);
        caption.setGravity(Gravity.CENTER);
        caption.setTextSize(8);
        caption.setTypeface(null, Typeface.BOLD);
        col.addView(caption, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(18)));
        return new PreviewColumn(col, gauge, caption, title);
    }

    private void refreshAppearance() {
        refreshPreview();
        EyesMobileWidgetProvider.updateAll(getApplicationContext());
    }

    private void refreshPreview() {
        if (previewBody == null) return;
        boolean dark = WidgetAppearance.isDark(this);
        int textColor = WidgetAppearance.getTextColor(this);
        int trackColor = WidgetAppearance.getTrackColor(this);
        int cardColor = WidgetAppearance.getCardColor(this);
        UsageData d = WidgetStorage.load(this);

        previewBody.setAlpha(Math.max(0.40f, 1f - (WidgetAppearance.getTransparency(this) / 100f)));
        for (int i = 0; i < previewBody.getChildCount(); i++) {
            View child = previewBody.getChildAt(i);
            child.setBackground(roundRect(cardColor, 12, dark ? Color.rgb(53,57,76) : Color.rgb(233,229,251), 1));
            if (child instanceof LinearLayout) {
                LinearLayout col = (LinearLayout) child;
                if (col.getChildCount() > 0 && col.getChildAt(0) instanceof TextView) {
                    ((TextView) col.getChildAt(0)).setTextColor(textColor);
                }
            }
        }

        previewDataCaption.setText(GaugeRenderer.caption("데이터", d.dataUsed, d.dataTotal));
        previewVoiceCaption.setText(GaugeRenderer.caption("음성", d.voiceUsed, d.voiceTotal));
        previewSmsCaption.setText(GaugeRenderer.caption("문자", d.smsUsed, d.smsTotal));
        previewDataCaption.setTextColor(textColor);
        previewVoiceCaption.setTextColor(textColor);
        previewSmsCaption.setTextColor(textColor);

        previewDataGauge.setImageBitmap(GaugeRenderer.renderGauge(this, d.dataPercent,
                GaugeRenderer.topLabel(d.dataUsed, d.dataTotal, true),
                GaugeRenderer.mainDisplay("데이터", d.dataUsed, d.dataTotal), textColor, trackColor, true));
        previewVoiceGauge.setImageBitmap(GaugeRenderer.renderGauge(this, d.voicePercent,
                GaugeRenderer.topLabel(d.voiceUsed, d.voiceTotal, false),
                GaugeRenderer.mainDisplay("음성", d.voiceUsed, d.voiceTotal), textColor, trackColor, false));
        previewSmsGauge.setImageBitmap(GaugeRenderer.renderGauge(this, d.smsPercent,
                GaugeRenderer.topLabel(d.smsUsed, d.smsTotal, false),
                GaugeRenderer.mainDisplay("문자", d.smsUsed, d.smsTotal), textColor, trackColor, false));

        if (lavenderChoice != null) lavenderChoice.setText((!dark ? "✓ " : "") + "LAVENDER");
        if (darkChoice != null) darkChoice.setText((dark ? "✓ " : "") + "DARK");
    }

    private void setSettingsCollapsed(boolean collapsed) {
        settingsCollapsed = collapsed;
        if (settingsPanel != null) settingsPanel.setVisibility(collapsed ? View.GONE : View.VISIBLE);
        if (togglePanelButton != null) togglePanelButton.setText(collapsed ? "설정 펼치기" : "설정 접기");
    }

    private TextView choiceButton(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(11);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(INK);
        tv.setBackground(roundRect(Color.rgb(252, 251, 255), 10, Color.rgb(211, 203, 245), 1));
        return tv;
    }

    private TextView actionButton(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(11);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(INK);
        tv.setBackground(roundRect(Color.rgb(252, 251, 255), 12, Color.rgb(211, 203, 245), 1));
        return tv;
    }

    private void rebuildSwatchChecks(LinearLayout colors) {
        int selected = WidgetAppearance.getTextColor(this);
        int[] choices = WidgetAppearance.colorChoices();
        for (int i = 0; i < colors.getChildCount() && i < choices.length; i++) {
            TextView v = (TextView) colors.getChildAt(i);
            v.setText(choices[i] == selected ? "✓" : "");
        }
    }

    private void capturePageAndRefresh() {
        if (webView == null) return;
        if (status != null) status.setText("캐시를 사용하지 않고 최신 사용량 페이지를 다시 조회하는 중…");
        webView.clearCache(true);
        usageNavigationAttempted = false;
        pageParseAttempts = 0;
        UsageDomSnapshot.loadFresh(webView);
    }

    private void capturePageText() {
        if (webView == null) return;
        UsageDomSnapshot.capture(webView, text -> {
            if (text != null && !text.isEmpty()) handlePageText(text);
        });
    }

    private void handlePageText(String text) {
        UsageData data = UsageParser.parse(text);
        if (data != null) {
            // Only a confirmed usage page is allowed to replace the good-session backup.
            confirmedLoggedIn = true;
            autoLoginAttempted = false;
            usageNavigationAttempted = true;
            pageParseAttempts = 0;
            SessionCookieStore.flush();
            VerifiedSessionStore.captureVerified(getApplicationContext());
            WidgetStorage.save(getApplicationContext(), data);
            EyesMobileWidgetProvider.updateAll(getApplicationContext());
            refreshPreview();
            if (status != null) status.setText("최신 페이지에서 사용량을 다시 읽어 위젯에 반영했습니다.");
            return;
        }

        boolean loggedOut = looksLoggedOut(text);

        if (loggedOut && !autoLoginAttempted
                && AutoLoginHelper.hasCredentials(getApplicationContext())) {
            VerifiedSessionStore.invalidate(getApplicationContext());
            startAutoLoginRecovery();
            return;
        }

        if (!loggedOut && !usageNavigationAttempted && webView != null) {
            usageNavigationAttempted = true;
            if (status != null) status.setText("실제 사용량조회 화면으로 이동하는 중…");
            UsagePageNavigator.tryOpen(webView, (navigated, detail) -> {
                if (!navigated) {
                    // A logged-out header can exist without exposing the password fields in body text.
                    // Let the auto-login helper open the site's login layer itself.
                    if (!autoLoginAttempted
                            && AutoLoginHelper.hasCredentials(getApplicationContext())) {
                        startAutoLoginRecovery();
                    } else if (status != null) {
                        status.setText("사용량조회 메뉴를 찾지 못했습니다. 페이지 로딩 후 다시 시도해 주세요.");
                    }
                } else {
                    handler.postDelayed(MainActivity.this::capturePageText, 1700L);
                }
            });
            return;
        }

        if (!loggedOut && usageNavigationAttempted && pageParseAttempts < 12) {
            pageParseAttempts++;
            if (status != null && (pageParseAttempts == 4 || pageParseAttempts == 8)) {
                status.setText("사용량 응답을 기다리는 중… " + pageParseAttempts + "/12");
            }
            handler.postDelayed(MainActivity.this::capturePageText, 900L);
            return;
        }

        if (!autoLoginAttempted && AutoLoginHelper.hasCredentials(getApplicationContext())) {
            startAutoLoginRecovery();
            return;
        }

        if (loggedOut) {
            confirmedLoggedIn = false;
            if (status != null) {
                status.setText(AutoLoginHelper.hasCredentials(getApplicationContext())
                        ? "자동 로그인에 실패했습니다. 계정 정보를 확인해 주세요."
                        : "세션이 만료되었습니다. 자동 로그인에 계정을 한 번 저장해 주세요.");
            }
            WidgetStorage.setStatus(getApplicationContext(),
                    AutoLoginHelper.hasCredentials(getApplicationContext())
                            ? "자동 로그인 실패 · 계정 확인 필요"
                            : "로그인 만료 · 자동로그인 설정 필요");
            EyesMobileWidgetProvider.updateAll(getApplicationContext());
        } else if (status != null) {
            status.setText("사용량 화면을 아직 읽지 못했습니다. 잠시 후 다시 시도해 주세요.");
        }
    }

    private void startAutoLoginRecovery() {
        if (webView == null || autoLoginAttempted) return;
        autoLoginAttempted = true;
        confirmedLoggedIn = false;
        if (status != null) status.setText("세션 만료 감지 · 로그인 창을 열어 자동 재로그인 중…");
        AutoLoginHelper.tryLogin(getApplicationContext(), webView, (submitted, detail) -> {
            if (submitted) {
                usageNavigationAttempted = false;
                pageParseAttempts = 0;
                if (status != null) status.setText("자동 로그인 전송 완료 · 새 세션 확인 중…");
                handler.postDelayed(() -> {
                    if (webView != null) UsageDomSnapshot.loadFresh(webView);
                }, 3000L);
            } else {
                if (status != null) {
                    if (detail != null && detail.startsWith("NO_LOGIN_UI")) {
                        status.setText("로그인 화면을 찾지 못했습니다. 아래 로그인 버튼을 한 번 눌러 주세요.");
                    } else {
                        status.setText("자동 로그인 실패(" + detail + ") · 저장된 계정을 확인해 주세요.");
                    }
                }
                WidgetStorage.setStatus(getApplicationContext(), "자동 로그인 확인 필요");
                EyesMobileWidgetProvider.updateAll(getApplicationContext());
            }
        });
    }

    private void loadWithSessionBootstrap() {
        if (webView == null) return;
        usageNavigationAttempted = false;
        pageParseAttempts = 0;
        autoLoginAttempted = false;
        SessionCookieStore.migrateToLiveCookiePolicy(getApplicationContext());
        WebSessionStateStore.clear(getApplicationContext());
        VerifiedSessionStore.restoreMissing(getApplicationContext());
        SessionCookieStore.flush();
        UsageDomSnapshot.loadFresh(webView);
    }

    private boolean isEyesOrigin(String url) {
        if (url == null) return false;
        String u = url.toLowerCase(java.util.Locale.ROOT);
        return u.startsWith("https://www.eyes.co.kr/") || u.startsWith("https://eyes.co.kr/");
    }

    private boolean looksLoggedOut(String text) {
        if (text == null) return false;
        int marker = text.indexOf("[[EYES_LOGGED_OUT_UI]]");
        if (marker >= 0) {
            int start = marker + "[[EYES_LOGGED_OUT_UI]]".length();
            String tail = text.substring(start).trim();
            if (tail.startsWith("1")) return true;
            if (tail.startsWith("0")) {
                String lower = text.toLowerCase(java.util.Locale.ROOT);
                return lower.contains("로그인을 해주세요");
            }
        }
        String t = text.toLowerCase(java.util.Locale.ROOT);
        return t.contains("로그인을 해주세요");
    }

    private String decodeJsString(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            if (value.startsWith("\"") && value.endsWith("\"")) value = value.substring(1, value.length() - 1);
            return value.replace("\\n", "\n")
                    .replace("\\r", "\r")
                    .replace("\\t", "\t")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\u003C", "<")
                    .replace("\\u003E", ">");
        } catch (Exception e) {
            return value;
        }
    }

    @Override
    protected void onPause() {
        SessionCookieStore.flush();
        super.onPause();
    }

    @Override
    protected void onStop() {
        SessionCookieStore.flush();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        SessionCookieStore.flush();
        if (webView != null) {
            webView.removeJavascriptInterface("EyesWidgetBridge");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private GradientDrawable roundRect(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private int contrast(int color) {
        double lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color));
        return lum > 150 ? Color.BLACK : Color.WHITE;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private final class PageBridge {
        @JavascriptInterface
        public void onPageText(String text) {
            runOnUiThread(() -> handlePageText(text));
        }
    }

    private static final class PreviewColumn {
        final LinearLayout root;
        final ImageView gauge;
        final TextView caption;
        final TextView title;
        PreviewColumn(LinearLayout root, ImageView gauge, TextView caption, TextView title) {
            this.root = root;
            this.gauge = gauge;
            this.caption = caption;
            this.title = title;
        }
    }
}

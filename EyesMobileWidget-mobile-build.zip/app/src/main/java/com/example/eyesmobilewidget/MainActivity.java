package com.example.eyesmobilewidget;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PINK = Color.rgb(245, 0, 115);
    private static final int NAVY = Color.rgb(13, 22, 35);

    private WebView webView;
    private TextView status;
    private TextView blackChoice;
    private TextView whiteChoice;
    private TextView transparencyValue;
    private LinearLayout previewBody;
    private ImageView previewDataGauge;
    private ImageView previewVoiceGauge;
    private ImageView previewSmsGauge;
    private TextView previewDataCaption;
    private TextView previewVoiceCaption;
    private TextView previewSmsCaption;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        root.addView(buildTopBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        root.addView(buildSettingsPanel(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView loginTitle = new TextView(this);
        loginTitle.setText("아이즈모바일 로그인 / 사용량 조회");
        loginTitle.setTextColor(Color.rgb(40, 40, 40));
        loginTitle.setTextSize(13);
        loginTitle.setTypeface(null, Typeface.BOLD);
        loginTitle.setPadding(dp(14), dp(9), dp(14), dp(4));
        root.addView(loginTitle);

        status = new TextView(this);
        status.setText("로그인 후 사용량조회 화면을 열어 주세요. 로그인 정보는 앱이 따로 저장하지 않습니다.");
        status.setTextColor(Color.DKGRAY);
        status.setTextSize(11);
        status.setPadding(dp(14), dp(4), dp(14), dp(7));
        root.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setUserAgentString(settings.getUserAgentString() + " EyesMobileWidget/1.0");

        android.webkit.CookieManager.getInstance().setAcceptCookie(true);
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new PageBridge(), "EyesWidgetBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                status.setText("페이지 로드 완료 · 로그인 후 '사용량조회' 화면에서 우측 ✓ 또는 위젯 새로고침을 누르세요.");
                handler.postDelayed(MainActivity.this::capturePageText, 1200);
            }
        });

        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);
        refreshPreview();
        webView.loadUrl(EyesMobileFetcher.MY_PAGE_URL);
    }

    private View buildTopBar() {
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(18), 0, dp(12), 0);
        top.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("위젯 화면 설정");
        title.setGravity(Gravity.CENTER);
        title.setTextColor(Color.BLACK);
        title.setTextSize(19);
        title.setTypeface(null, Typeface.BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

        TextView done = new TextView(this);
        done.setText("✓");
        done.setGravity(Gravity.CENTER);
        done.setTextColor(Color.rgb(30, 30, 30));
        done.setTextSize(27);
        done.setTypeface(null, Typeface.BOLD);
        done.setOnClickListener(v -> {
            capturePageAndRefresh();
            Toast.makeText(this, "위젯 설정을 적용했습니다.", Toast.LENGTH_SHORT).show();
        });
        top.addView(done, new LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.MATCH_PARENT));
        return top;
    }

    private View buildSettingsPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(12));
        panel.setBackgroundColor(NAVY);

        panel.addView(buildPreviewCard(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(132)));

        LinearLayout bgRow = new LinearLayout(this);
        bgRow.setGravity(Gravity.CENTER_VERTICAL);
        bgRow.setPadding(dp(6), dp(8), dp(4), dp(6));

        TextView label = new TextView(this);
        label.setText("●  배경 색상 및 투명도 설정");
        label.setTextColor(Color.WHITE);
        label.setTextSize(12);
        label.setTypeface(null, Typeface.BOLD);
        bgRow.addView(label, new LinearLayout.LayoutParams(0, dp(42), 1));

        blackChoice = choiceButton("BLACK");
        blackChoice.setOnClickListener(v -> {
            WidgetAppearance.setDark(this, true);
            refreshAppearance();
        });
        bgRow.addView(blackChoice, new LinearLayout.LayoutParams(dp(82), dp(38)));

        whiteChoice = choiceButton("WHITE");
        whiteChoice.setOnClickListener(v -> {
            WidgetAppearance.setDark(this, false);
            refreshAppearance();
        });
        LinearLayout.LayoutParams whiteLp = new LinearLayout.LayoutParams(dp(82), dp(38));
        whiteLp.setMargins(dp(8), 0, 0, 0);
        bgRow.addView(whiteChoice, whiteLp);
        panel.addView(bgRow);

        LinearLayout seekRow = new LinearLayout(this);
        seekRow.setGravity(Gravity.CENTER_VERTICAL);
        seekRow.setPadding(dp(8), 0, dp(4), dp(5));

        TextView min = new TextView(this);
        min.setText("투명");
        min.setTextColor(Color.WHITE);
        min.setTextSize(11);
        seekRow.addView(min, new LinearLayout.LayoutParams(dp(46), dp(38)));

        SeekBar seek = new SeekBar(this);
        seek.setMax(80);
        seek.setProgress(WidgetAppearance.getTransparency(this));
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(PINK));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(PINK));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                WidgetAppearance.setTransparency(MainActivity.this, progress);
                if (transparencyValue != null) transparencyValue.setText(progress + "%");
                if (fromUser) refreshPreview();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                EyesMobileWidgetProvider.updateAll(getApplicationContext());
            }
        });
        seekRow.addView(seek, new LinearLayout.LayoutParams(0, dp(40), 1));

        transparencyValue = new TextView(this);
        transparencyValue.setGravity(Gravity.CENTER);
        transparencyValue.setTextColor(Color.WHITE);
        transparencyValue.setTextSize(11);
        transparencyValue.setText(WidgetAppearance.getTransparency(this) + "%");
        seekRow.addView(transparencyValue, new LinearLayout.LayoutParams(dp(46), dp(38)));
        panel.addView(seekRow);

        TextView colorTitle = new TextView(this);
        colorTitle.setText("●  글자 색상 설정");
        colorTitle.setTextColor(Color.WHITE);
        colorTitle.setTextSize(12);
        colorTitle.setTypeface(null, Typeface.BOLD);
        colorTitle.setPadding(dp(6), dp(5), dp(4), dp(5));
        panel.addView(colorTitle);

        LinearLayout colors = new LinearLayout(this);
        colors.setGravity(Gravity.CENTER);
        colors.setOrientation(LinearLayout.HORIZONTAL);
        int[] choices = WidgetAppearance.colorChoices();
        for (int color : choices) {
            TextView swatch = new TextView(this);
            swatch.setGravity(Gravity.CENTER);
            swatch.setText(color == WidgetAppearance.getTextColor(this) ? "✓" : "");
            swatch.setTextColor(contrast(color));
            swatch.setTextSize(18);
            swatch.setTypeface(null, Typeface.BOLD);
            swatch.setBackground(roundRect(color, 6, Color.argb(80,255,255,255), 1));
            swatch.setOnClickListener(v -> {
                WidgetAppearance.setTextColor(MainActivity.this, color);
                refreshAppearance();
                rebuildSwatchChecks(colors);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1);
            lp.setMargins(dp(3), 0, dp(3), 0);
            colors.addView(swatch, lp);
        }
        panel.addView(colors, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        return panel;
    }

    private View buildPreviewCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(2), dp(2), dp(2), dp(2));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12), 0, dp(8), 0);
        header.setBackground(roundTopRect(PINK, 16));

        TextView brand = new TextView(this);
        brand.setText("아이즈모바일");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(14);
        brand.setTypeface(null, Typeface.BOLD);
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(34), 1));

        TextView icons = new TextView(this);
        icons.setText("▥   ⚙   ↻");
        icons.setTextColor(Color.WHITE);
        icons.setTextSize(17);
        icons.setGravity(Gravity.CENTER);
        header.addView(icons, new LinearLayout.LayoutParams(dp(112), dp(34)));
        card.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));

        previewBody = new LinearLayout(this);
        previewBody.setOrientation(LinearLayout.HORIZONTAL);
        previewBody.setGravity(Gravity.CENTER);
        previewBody.setPadding(dp(4), dp(2), dp(4), dp(4));

        PreviewColumn data = previewColumn();
        previewDataGauge = data.gauge;
        previewDataCaption = data.caption;
        previewBody.addView(data.root, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

        PreviewColumn voice = previewColumn();
        previewVoiceGauge = voice.gauge;
        previewVoiceCaption = voice.caption;
        previewBody.addView(voice.root, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

        PreviewColumn sms = previewColumn();
        previewSmsGauge = sms.gauge;
        previewSmsCaption = sms.caption;
        previewBody.addView(sms.root, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

        card.addView(previewBody, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return card;
    }

    private PreviewColumn previewColumn() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);

        ImageView gauge = new ImageView(this);
        gauge.setScaleType(ImageView.ScaleType.FIT_CENTER);
        col.addView(gauge, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        TextView caption = new TextView(this);
        caption.setGravity(Gravity.CENTER);
        caption.setTextSize(10);
        caption.setTypeface(null, Typeface.BOLD);
        col.addView(caption, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(22)));
        return new PreviewColumn(col, gauge, caption);
    }

    private void refreshAppearance() {
        refreshPreview();
        EyesMobileWidgetProvider.updateAll(getApplicationContext());
    }

    private void refreshPreview() {
        if (previewBody == null) return;
        boolean dark = WidgetAppearance.isDark(this);
        int textColor = WidgetAppearance.getTextColor(this);
        int bodyColor = WidgetAppearance.getBodyColor(this);
        int trackColor = WidgetAppearance.getTrackColor(this);
        UsageData d = WidgetStorage.load(this);

        previewBody.setBackground(roundBottomRect(bodyColor, 16));
        previewDataCaption.setText(GaugeRenderer.caption("데이터", d.dataTotal));
        previewVoiceCaption.setText(GaugeRenderer.caption("음성", d.voiceTotal));
        previewSmsCaption.setText(GaugeRenderer.caption("문자", d.smsTotal));
        previewDataCaption.setTextColor(textColor);
        previewVoiceCaption.setTextColor(textColor);
        previewSmsCaption.setTextColor(textColor);

        previewDataGauge.setImageBitmap(GaugeRenderer.renderGauge(this, d.dataPercent,
                GaugeRenderer.remaining(d.dataUsed, d.dataTotal, true), textColor, trackColor));
        previewVoiceGauge.setImageBitmap(GaugeRenderer.renderGauge(this, d.voicePercent,
                GaugeRenderer.remaining(d.voiceUsed, d.voiceTotal, false), textColor, trackColor));
        previewSmsGauge.setImageBitmap(GaugeRenderer.renderGauge(this, d.smsPercent,
                GaugeRenderer.remaining(d.smsUsed, d.smsTotal, false), textColor, trackColor));

        if (blackChoice != null) blackChoice.setText((dark ? "✓ " : "") + "BLACK");
        if (whiteChoice != null) whiteChoice.setText((!dark ? "✓ " : "") + "WHITE");
    }

    private TextView choiceButton(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(11);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(Color.WHITE);
        tv.setBackground(roundRect(Color.rgb(28, 34, 43), 7, Color.rgb(75, 84, 97), 1));
        return tv;
    }

    private void rebuildSwatchChecks(LinearLayout colors) {
        int selected = WidgetAppearance.getTextColor(this);
        int[] choices = WidgetAppearance.colorChoices();
        for (int i = 0; i < colors.getChildCount() && i < choices.length; i++) {
            TextView v = (TextView) colors.getChildAt(i);
            v.setText(choices[i] == selected ? "✓" : "");
        }
    }

    private void capturePageAndRefresh() {
        if (status != null) status.setText("현재 페이지에서 사용량을 읽는 중…");
        capturePageText();
        new Thread(() -> {
            boolean ok = EyesMobileFetcher.refresh(getApplicationContext());
            EyesMobileWidgetProvider.updateAll(getApplicationContext());
            runOnUiThread(() -> {
                refreshPreview();
                if (status != null) {
                    if (ok) status.setText("위젯을 최신 사용량으로 갱신했습니다.");
                    else status.setText("웹 세션 자동 조회가 안 되면 사용량조회 화면을 띄운 상태에서 우측 ✓를 다시 눌러 주세요.");
                }
            });
        }, "ManualRefresh").start();
    }

    private void capturePageText() {
        if (webView == null) return;
        webView.evaluateJavascript(
                "(function(){try{return document.body ? document.body.innerText : '';}catch(e){return '';}})()",
                value -> {
                    String text = decodeJsString(value);
                    if (text != null && !text.isEmpty()) handlePageText(text);
                });
    }

    private void handlePageText(String text) {
        UsageData data = UsageParser.parse(text);
        if (data != null) {
            WidgetStorage.save(getApplicationContext(), data);
            EyesMobileWidgetProvider.updateAll(getApplicationContext());
            refreshPreview();
            if (status != null) status.setText("사용량을 읽어 위젯에 반영했습니다.");
        }
    }

    private String decodeJsString(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            if (value.startsWith("\"") && value.endsWith("\"")) value = value.substring(1, value.length() - 1);
            return value.replace("\\n", "\n")
                    .replace("\\r", "\r")
                    .replace("\\t", "\t")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\u003C", "<")
                    .replace("\\u003E", ">");
        } catch (Exception e) {
            return value;
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("EyesWidgetBridge");
            webView.destroy();
        }
        super.onDestroy();
    }

    private GradientDrawable roundRect(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private GradientDrawable roundTopRect(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        float r = dp(radiusDp);
        g.setCornerRadii(new float[]{r,r,r,r,0,0,0,0});
        return g;
    }

    private GradientDrawable roundBottomRect(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        float r = dp(radiusDp);
        g.setCornerRadii(new float[]{0,0,0,0,r,r,r,r});
        return g;
    }

    private int contrast(int color) {
        double lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color));
        return lum > 150 ? Color.BLACK : Color.WHITE;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private final class PageBridge {
        @JavascriptInterface
        public void onPageText(String text) {
            runOnUiThread(() -> handlePageText(text));
        }
    }

    private static final class PreviewColumn {
        final LinearLayout root;
        final ImageView gauge;
        final TextView caption;
        PreviewColumn(LinearLayout root, ImageView gauge, TextView caption) {
            this.root = root;
            this.gauge = gauge;
            this.caption = caption;
        }
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.SystemClock;

import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

/** Small refresh timer so speed tuning is based on measured device time, not guesses. */
public final class RefreshMetrics {
    private static final AtomicLong STARTED = new AtomicLong(0L);

    private RefreshMetrics() {}

    public static void begin() {
        STARTED.set(SystemClock.elapsedRealtime());
    }

    public static long elapsedMillis() {
        long start = STARTED.get();
        if (start <= 0L) return -1L;
        return Math.max(0L, SystemClock.elapsedRealtime() - start);
    }

    public static void decorateSuccess(Context context, String pathLabel) {
        try {
            String base = WidgetStorage.getStatus(context);
            if (base == null || base.trim().isEmpty()) base = "사용량 조회 완료";
            long ms = elapsedMillis();
            String duration = ms >= 0L
                    ? String.format(Locale.KOREA, "%.1f초", ms / 1000d)
                    : "시간 미측정";
            WidgetStorage.setStatus(context, base + " · " + duration + " · " + pathLabel);
        } catch (Throwable ignored) {
        }
    }
}

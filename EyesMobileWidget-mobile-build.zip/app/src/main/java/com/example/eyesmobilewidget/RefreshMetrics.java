package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.SystemClock;

import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

/** Small refresh timer so speed tuning is based on measured device time, not guesses. */
public final class RefreshMetrics {
    private static final AtomicLong STARTED = new AtomicLong(0L);

    private RefreshMetrics() {}

    public static void begin() {
        STARTED.set(SystemClock.elapsedRealtime());
    }

    public static long elapsedMillis() {
        long start = STARTED.get();
        if (start <= 0L) return -1L;
        return Math.max(0L, SystemClock.elapsedRealtime() - start);
    }

    public static void decorateSuccess(Context context, String pathLabel) {
        try {
            WidgetStorage.setStatus(context, "업데이트 완료");
        } catch (Throwable ignored) {
        }
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * v3.6 low-latency path.
 *
 * Unlike v3.5, this no longer downloads /mypage/main hoping the asynchronously injected usage
 * values are already in server-rendered HTML. It only runs when UsageEndpointStore has learned and
 * verified the real GET endpoint that itself returns parseable usage data.
 */
public final class FastUsageRefresher {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    private static final long MAX_SESSION_HINT_MS = 7L * 24L * 60L * 60L * 1000L;

    private FastUsageRefresher() {}

    public interface Callback {
        void onComplete(boolean success, String detail);
    }

    public static boolean isRunning() {
        return RUNNING.get();
    }

    public static boolean shouldTry(Context context) {
        try {
            long age = VerifiedSessionStore.ageMillis(context);
            if (age < 0L || age >= MAX_SESSION_HINT_MS) return false;
            if (!UsageEndpointStore.hasConfirmed(context)) return false;
            String cookies = SessionCookieStore.currentCookieHeader(context, EyesMobileFetcher.MY_PAGE_URL);
            return cookies != null && !cookies.trim().isEmpty();
        } catch (Throwable t) {
            return false;
        }
    }

    public static void refreshAsync(Context context, Callback callback) {
        final Context app = context.getApplicationContext();
        if (!shouldTry(app)) {
            if (callback != null) MAIN.post(() -> callback.onComplete(false, "NO_LEARNED_ENDPOINT"));
            return;
        }
        if (!RUNNING.compareAndSet(false, true)) {
            if (callback != null) MAIN.post(() -> callback.onComplete(false, "BUSY"));
            return;
        }

        final String endpoint = UsageEndpointStore.getConfirmed(app);
        final String cookieHeader = SessionCookieStore.currentCookieHeader(app, EyesMobileFetcher.MY_PAGE_URL);
        final String userAgent = SessionCookieStore.getUserAgent(app);

        EXEC.execute(() -> {
            FastResult result;
            try {
                result = fetch(endpoint, cookieHeader, userAgent);
            } catch (Throwable t) {
                result = FastResult.fail("ERROR");
            }

            final FastResult done = result;
            MAIN.post(() -> {
                try {
                    if (done.data != null) {
                        commitCookies(done.pendingCookies);
                        SessionCookieStore.flush();
                        WidgetStorage.save(app, done.data);
                        VerifiedSessionStore.captureVerified(app);
                        UsageEndpointStore.noteFastSuccess(app, endpoint);
                        RefreshMetrics.decorateSuccess(app, "빠른조회");
                        EyesMobileWidgetProvider.updateAll(app);
                    } else {
                        UsageEndpointStore.noteFastFailure(app, done.detail);
                    }
                } catch (Throwable ignored) {
                } finally {
                    RUNNING.set(false);
                    if (callback != null) callback.onComplete(done.data != null, done.detail);
                }
            });
        });
    }

    private static FastResult fetch(String endpoint, String cookies, String userAgent) {
        if (endpoint == null || endpoint.trim().isEmpty()) return FastResult.fail("NO_ENDPOINT");
        if (cookies == null || cookies.trim().isEmpty()) return FastResult.fail("NO_COOKIE");

        HttpURLConnection conn = null;
        try {
            URL url = new URL(endpoint);
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(850);
            conn.setReadTimeout(1400);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Cookie", cookies);
            if (userAgent != null && !userAgent.trim().isEmpty()) conn.setRequestProperty("User-Agent", userAgent);
            conn.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en;q=0.7");
            conn.setRequestProperty("Accept", "application/json,text/plain,text/html,*/*");
            conn.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
            conn.setRequestProperty("Pragma", "no-cache");
            conn.setRequestProperty("Referer", EyesMobileFetcher.MY_PAGE_URL);

            int code = conn.getResponseCode();
            List<PendingCookie> pending = collectSetCookies(conn, endpoint);
            if (code >= 300 && code < 400) {
                String location = conn.getHeaderField("Location");
                if (looksLikeLoginUrl(location)) return FastResult.fail("LOGIN_REDIRECT");
                return FastResult.fail("REDIRECT");
            }
            if (code < 200 || code >= 400) return FastResult.fail("HTTP_" + code);

            String body = readLimited(conn.getInputStream(), 700_000);
            UsageData data = UsageEndpointStore.parseAny(body);
            if (data == null) {
                String lower = body == null ? "" : body.toLowerCase(Locale.ROOT);
                if (lower.contains("로그인을 해주세요") || lower.contains("login")) {
                    return FastResult.fail("LOGGED_OUT");
                }
                return FastResult.fail("NO_USAGE");
            }
            return FastResult.success(data, pending);
        } catch (java.net.SocketTimeoutException e) {
            return FastResult.fail("TIMEOUT");
        } catch (Throwable t) {
            return FastResult.fail("NETWORK");
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static List<PendingCookie> collectSetCookies(HttpURLConnection conn, String requestUrl) {
        List<PendingCookie> out = new ArrayList<>();
        try {
            Map<String, List<String>> headers = conn.getHeaderFields();
            if (headers == null) return out;
            for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
                String key = entry.getKey();
                if (key == null || !"set-cookie".equalsIgnoreCase(key)) continue;
                List<String> values = entry.getValue();
                if (values == null) continue;
                for (String value : values) {
                    if (value != null && !value.trim().isEmpty()) out.add(new PendingCookie(requestUrl, value));
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    private static void commitCookies(List<PendingCookie> pending) {
        if (pending == null || pending.isEmpty()) return;
        try {
            CookieManager cm = CookieManager.getInstance();
            for (PendingCookie cookie : pending) cm.setCookie(cookie.url, cookie.setCookie);
            cm.flush();
        } catch (Throwable ignored) {
        }
    }

    private static String readLimited(InputStream in, int maxChars) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[8192];
            int n;
            while ((n = br.read(buf)) >= 0) {
                int remaining = maxChars - sb.length();
                if (remaining <= 0) break;
                sb.append(buf, 0, Math.min(n, remaining));
                if (sb.length() >= maxChars) break;
            }
        }
        return sb.toString();
    }

    private static boolean looksLikeLoginUrl(String url) {
        if (url == null) return false;
        String u = url.toLowerCase(Locale.ROOT);
        return u.contains("/login") || u.contains("login?") || u.contains("signin") || u.contains("sign-in");
    }

    private static final class PendingCookie {
        final String url;
        final String setCookie;
        PendingCookie(String url, String setCookie) {
            this.url = url;
            this.setCookie = setCookie;
        }
    }

    private static final class FastResult {
        final UsageData data;
        final List<PendingCookie> pendingCookies;
        final String detail;

        private FastResult(UsageData data, List<PendingCookie> pendingCookies, String detail) {
            this.data = data;
            this.pendingCookies = pendingCookies;
            this.detail = detail;
        }

        static FastResult success(UsageData data, List<PendingCookie> pending) {
            return new FastResult(data, pending == null ? new ArrayList<>() : new ArrayList<>(pending), "FAST_API_OK");
        }

        static FastResult fail(String detail) {
            return new FastResult(null, new ArrayList<>(), detail);
        }
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.webkit.CookieManager;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * v3.5 optimistic low-latency refresh path.
 *
 * It reuses the live WebView CookieManager session and asks MyPage directly over HTTP in parallel
 * with the existing hidden-WebView refresh. If the authenticated HTML already contains the live
 * usage block, the widget can update without waiting for WebView startup/page rendering. If the
 * site requires its JavaScript/XHR path, this class quietly gives up and the WebView path that was
 * already started continues unchanged.
 */
public final class FastUsageRefresher {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);

    private static final int CONNECT_TIMEOUT_MS = 900;
    private static final int READ_TIMEOUT_MS = 1300;
    private static final int MAX_REDIRECTS = 2;
    private static final int MAX_BODY_CHARS = 1_200_000;
    private static final long RECENT_VERIFIED_MS = 20L * 60L * 1000L;

    private FastUsageRefresher() {}

    public interface Callback {
        void onComplete(boolean success, String detail);
    }

    public static boolean isRunning() {
        return RUNNING.get();
    }

    /**
     * The fast path is useful mainly while a recently verified session is likely still alive.
     * Long-idle sessions immediately rely on the existing WebView/auto-login path instead.
     */
    public static boolean shouldTry(Context context) {
        try {
            long age = VerifiedSessionStore.ageMillis(context);
            if (age < 0L || age >= RECENT_VERIFIED_MS) return false;
            String cookies = SessionCookieStore.currentCookieHeader(context, EyesMobileFetcher.MY_PAGE_URL);
            return cookies != null && !cookies.trim().isEmpty();
        } catch (Throwable t) {
            return false;
        }
    }

    public static void refreshAsync(Context context, Callback callback) {
        final Context app = context.getApplicationContext();
        if (!shouldTry(app)) {
            if (callback != null) MAIN.post(() -> callback.onComplete(false, "SKIP"));
            return;
        }
        if (!RUNNING.compareAndSet(false, true)) {
            if (callback != null) MAIN.post(() -> callback.onComplete(false, "BUSY"));
            return;
        }

        // Read WebView-owned session state on the caller/main thread before entering the executor.
        final String cookieHeader = SessionCookieStore.currentCookieHeader(app, EyesMobileFetcher.MY_PAGE_URL);
        final String userAgent = SessionCookieStore.getUserAgent(app);

        EXEC.execute(() -> {
            FastResult result;
            try {
                result = fetch(cookieHeader, userAgent);
            } catch (Throwable t) {
                result = FastResult.fail("ERROR");
            }

            final FastResult done = result;
            MAIN.post(() -> {
                try {
                    if (done.data != null) {
                        // Only a successfully parsed authenticated response is allowed to feed
                        // response cookies back into CookieManager.
                        commitCookies(done.pendingCookies);
                        SessionCookieStore.flush();
                        WidgetStorage.save(app, done.data);
                        VerifiedSessionStore.captureVerified(app);
                        EyesMobileWidgetProvider.updateAll(app);
                    }
                } catch (Throwable ignored) {
                } finally {
                    RUNNING.set(false);
                    if (callback != null) {
                        callback.onComplete(done.data != null, done.detail);
                    }
                }
            });
        });
    }

    private static FastResult fetch(String initialCookies, String userAgent) {
        if (initialCookies == null || initialCookies.trim().isEmpty()) {
            return FastResult.fail("NO_COOKIE");
        }

        Map<String, String> cookieJar = parseCookieHeader(initialCookies);
        List<PendingCookie> pending = new ArrayList<>();
        String currentUrl = EyesMobileFetcher.MY_PAGE_URL + "?_eyes_fast_ts=" + System.currentTimeMillis();

        for (int redirect = 0; redirect <= MAX_REDIRECTS; redirect++) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(currentUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setInstanceFollowRedirects(false);
                conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
                conn.setReadTimeout(READ_TIMEOUT_MS);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Cookie", buildCookieHeader(cookieJar));
                conn.setRequestProperty("User-Agent", userAgent);
                conn.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en;q=0.7");
                conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
                conn.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
                conn.setRequestProperty("Pragma", "no-cache");
                conn.setRequestProperty("Referer", EyesMobileFetcher.MY_PAGE_URL);

                int code = conn.getResponseCode();
                collectSetCookies(conn, currentUrl, cookieJar, pending);

                if (code >= 300 && code < 400) {
                    String location = conn.getHeaderField("Location");
                    if (location == null || location.trim().isEmpty()) return FastResult.fail("REDIRECT");
                    currentUrl = new URL(url, location).toString();
                    if (looksLikeLoginUrl(currentUrl)) return FastResult.fail("LOGIN_REDIRECT");
                    continue;
                }

                if (code < 200 || code >= 400) return FastResult.fail("HTTP_" + code);

                String html = readLimited(conn.getInputStream());
                String text = htmlToText(html);

                // Parse first: EyesMobile keeps a hidden login modal in the common page HTML,
                // so raw HTML can contain login/password labels even for an authenticated user.
                UsageData data = UsageParser.parse(text);
                if (data == null) {
                    // Some server-rendered fragments keep useful labels separated by tags. This
                    // conservative second pass keeps text but removes markup; UsageParser's usage
                    // confidence checks still reject recommendation/plan cards.
                    data = UsageParser.parse(stripTagsPreserveText(html));
                }
                if (data == null) {
                    if (text != null && text.contains("로그인을 해주세요")) {
                        return FastResult.fail("LOGGED_OUT");
                    }
                    return FastResult.fail("NO_USAGE_IN_HTTP");
                }

                return FastResult.success(data, pending);
            } catch (java.net.SocketTimeoutException e) {
                return FastResult.fail("TIMEOUT");
            } catch (Throwable e) {
                return FastResult.fail("NETWORK");
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        return FastResult.fail("REDIRECT_LIMIT");
    }

    private static String htmlToText(String html) {
        if (html == null) return "";
        try {
            if (android.os.Build.VERSION.SDK_INT >= 24) {
                return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString();
            }
            return Html.fromHtml(html).toString();
        } catch (Throwable t) {
            return stripTagsPreserveText(html);
        }
    }

    private static String stripTagsPreserveText(String html) {
        if (html == null) return "";
        try {
            return html
                    .replaceAll("(?is)<style[^>]*>.*?</style>", " ")
                    .replaceAll("(?is)<script[^>]*>.*?</script>", " ")
                    .replaceAll("(?is)<[^>]+>", " ")
                    .replace("&nbsp;", " ")
                    .replace("&amp;", "&")
                    .replaceAll("\\s+", " ")
                    .trim();
        } catch (Throwable t) {
            return html;
        }
    }

    private static String readLimited(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[8192];
            int n;
            while ((n = br.read(buf)) >= 0) {
                int remaining = MAX_BODY_CHARS - sb.length();
                if (remaining <= 0) break;
                sb.append(buf, 0, Math.min(n, remaining));
                if (sb.length() >= MAX_BODY_CHARS) break;
            }
        }
        return sb.toString();
    }

    private static void collectSetCookies(HttpURLConnection conn,
                                          String requestUrl,
                                          Map<String, String> cookieJar,
                                          List<PendingCookie> pendingCookies) {
        Map<String, List<String>> headers = conn.getHeaderFields();
        if (headers == null) return;
        for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
            String key = entry.getKey();
            if (key == null || !"set-cookie".equals(key.toLowerCase(Locale.ROOT))) continue;
            List<String> values = entry.getValue();
            if (values == null) continue;
            for (String setCookie : values) {
                if (setCookie == null || setCookie.trim().isEmpty()) continue;
                pendingCookies.add(new PendingCookie(requestUrl, setCookie));
                mergeSetCookie(cookieJar, setCookie);
            }
        }
    }

    private static void mergeSetCookie(Map<String, String> jar, String setCookie) {
        String first = setCookie.split(";", 2)[0].trim();
        int eq = first.indexOf('=');
        if (eq <= 0) return;
        String name = first.substring(0, eq).trim();
        String value = first.substring(eq + 1).trim();
        String lower = setCookie.toLowerCase(Locale.ROOT);
        boolean delete = value.isEmpty() || lower.contains("max-age=0");
        if (delete) jar.remove(name); else jar.put(name, value);
    }

    private static Map<String, String> parseCookieHeader(String header) {
        Map<String, String> jar = new LinkedHashMap<>();
        if (header == null) return jar;
        for (String pair : header.split(";")) {
            String p = pair.trim();
            int eq = p.indexOf('=');
            if (eq <= 0) continue;
            String name = p.substring(0, eq).trim();
            String value = p.substring(eq + 1).trim();
            if (!name.isEmpty()) jar.put(name, value);
        }
        return jar;
    }

    private static String buildCookieHeader(Map<String, String> jar) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : jar.entrySet()) {
            if (sb.length() > 0) sb.append("; ");
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        return sb.toString();
    }

    private static boolean looksLikeLoginUrl(String url) {
        if (url == null) return false;
        String u = url.toLowerCase(Locale.ROOT);
        return u.contains("/login") || u.contains("login?") || u.contains("signin") || u.contains("sign-in");
    }

    private static boolean looksLoggedOut(String text) {
        if (text == null) return false;
        String t = text.toLowerCase(Locale.ROOT);
        return t.contains("로그인을 해주세요")
                || (t.contains("로그인") && (t.contains("비밀번호") || t.contains("아이디(이메일)")));
    }

    private static void commitCookies(List<PendingCookie> pending) {
        if (pending == null || pending.isEmpty()) return;
        try {
            CookieManager cm = CookieManager.getInstance();
            for (PendingCookie cookie : pending) {
                cm.setCookie(cookie.url, cookie.setCookie);
            }
            cm.flush();
        } catch (Throwable ignored) {
        }
    }

    private static final class PendingCookie {
        final String url;
        final String setCookie;
        PendingCookie(String url, String setCookie) {
            this.url = url;
            this.setCookie = setCookie;
        }
    }

    private static final class FastResult {
        final UsageData data;
        final List<PendingCookie> pendingCookies;
        final String detail;

        private FastResult(UsageData data, List<PendingCookie> pendingCookies, String detail) {
            this.data = data;
            this.pendingCookies = pendingCookies;
            this.detail = detail;
        }

        static FastResult success(UsageData data, List<PendingCookie> pending) {
            return new FastResult(data, pending == null ? new ArrayList<>() : new ArrayList<>(pending), "FAST_OK");
        }

        static FastResult fail(String detail) {
            return new FastResult(null, new ArrayList<>(), detail);
        }
    }
}

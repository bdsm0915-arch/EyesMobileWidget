package com.example.eyesmobilewidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.SystemClock;

/** User-selectable widget auto refresh scheduler. */
public final class AutoRefreshScheduler {
    public static final String ACTION_AUTO_REFRESH =
            "com.example.eyesmobilewidget.ACTION_AUTO_REFRESH";

    private static final String PREF = "widget_auto_refresh";
    private static final String KEY_MINUTES = "interval_minutes";
    private static final int REQUEST_CODE = 5401;

    private AutoRefreshScheduler() {}

    public static int getIntervalMinutes(Context context) {
        return prefs(context).getInt(KEY_MINUTES, 0);
    }

    public static void setIntervalMinutes(Context context, int minutes) {
        int normalized = normalize(minutes);
        prefs(context).edit().putInt(KEY_MINUTES, normalized).apply();
        if (normalized <= 0) cancel(context);
        else scheduleNext(context);
    }

    public static void ensureScheduled(Context context) {
        if (getIntervalMinutes(context) > 0) scheduleNext(context);
    }

    public static boolean canScheduleExact(Context context) {
        if (Build.VERSION.SDK_INT < 31) return true;
        try {
            AlarmManager alarm = (AlarmManager) context.getApplicationContext()
                    .getSystemService(Context.ALARM_SERVICE);
            return alarm != null && alarm.canScheduleExactAlarms();
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static void scheduleNext(Context context) {
        Context app = context.getApplicationContext();
        int minutes = getIntervalMinutes(app);
        if (minutes <= 0) {
            cancel(app);
            return;
        }

        try {
            AlarmManager alarm = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
            if (alarm == null) return;

            PendingIntent pi = pendingIntent(app,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            long triggerAt = SystemClock.elapsedRealtime() + minutes * 60_000L;

            // v5.5: use an exact idle-safe alarm whenever Android grants exact-alarm access.
            // Fall back to an inexact idle-safe alarm rather than disabling auto refresh.
            if (Build.VERSION.SDK_INT >= 31) {
                if (alarm.canScheduleExactAlarms()) {
                    alarm.setExactAndAllowWhileIdle(
                            AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
                } else {
                    alarm.setAndAllowWhileIdle(
                            AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
                }
            } else if (Build.VERSION.SDK_INT >= 23) {
                alarm.setExactAndAllowWhileIdle(
                        AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
            } else {
                alarm.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
            }
        } catch (Throwable ignored) {
        }
    }

    public static void cancel(Context context) {
        try {
            Context app = context.getApplicationContext();
            AlarmManager alarm = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
            if (alarm == null) return;
            PendingIntent pi = pendingIntent(app,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) alarm.cancel(pi);
        } catch (Throwable ignored) {
        }
    }

    public static String labelFor(int minutes) {
        switch (normalize(minutes)) {
            case 10: return "10분";
            case 30: return "30분";
            case 60: return "1시간";
            case 120: return "2시간";
            case 720: return "12시간";
            case 1440: return "24시간";
            default: return "수동";
        }
    }

    public static int[] choices() {
        return new int[]{0, 10, 30, 60, 120, 720, 1440};
    }

    private static int normalize(int minutes) {
        switch (minutes) {
            case 10:
            case 30:
            case 60:
            case 120:
            case 720:
            case 1440:
                return minutes;
            default:
                return 0;
        }
    }

    private static PendingIntent pendingIntent(Context context, int flags) {
        Intent intent = new Intent(context, AutoRefreshReceiver.class)
                .setAction(ACTION_AUTO_REFRESH);
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext()
                .getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
}

package com.example.eyesmobilewidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.SystemClock;

/** User-selectable widget auto refresh scheduler. */
public final class AutoRefreshScheduler {
    public static final String ACTION_AUTO_REFRESH =
            "com.example.eyesmobilewidget.ACTION_AUTO_REFRESH";

    private static final String PREF = "widget_auto_refresh";
    private static final String KEY_MINUTES = "interval_minutes";
    private static final String KEY_LAST_CLAIM_WALL = "last_claim_wall";
    private static final String KEY_LAST_ATTEMPT_WALL = "last_attempt_wall";
    private static final String KEY_LAST_SUCCESS_WALL = "last_success_wall";
    private static final String KEY_LAST_DETAIL = "last_detail";
    private static final int REQUEST_CODE = 5401;
    private static final int BACKUP_JOB_ID = 5402;

    private AutoRefreshScheduler() {}

    public static int getIntervalMinutes(Context context) {
        return prefs(context).getInt(KEY_MINUTES, 0);
    }

    public static void setIntervalMinutes(Context context, int minutes) {
        int normalized = normalize(minutes);
        prefs(context).edit()
                .putInt(KEY_MINUTES, normalized)
                .putLong(KEY_LAST_CLAIM_WALL, 0L)
                .apply();
        if (normalized <= 0) cancel(context);
        else scheduleNext(context);
    }

    public static void ensureScheduled(Context context) {
        if (getIntervalMinutes(context) > 0) scheduleNext(context);
    }

    public static boolean canScheduleExact(Context context) {
        if (Build.VERSION.SDK_INT < 31) return true;
        try {
            AlarmManager alarm = (AlarmManager) context.getApplicationContext()
                    .getSystemService(Context.ALARM_SERVICE);
            return alarm != null && alarm.canScheduleExactAlarms();
        } catch (Throwable ignored) {
            return false;
        }
    }

    /**
     * v5.6 dual scheduler: AlarmManager is the fast path, while a persisted one-shot JobScheduler
     * job is always armed as a backup. Samsung/Android may defer either mechanism independently;
     * whichever arrives first claims the interval and the other becomes a harmless duplicate.
     */
    public static void scheduleNext(Context context) {
        Context app = context.getApplicationContext();
        int minutes = getIntervalMinutes(app);
        if (minutes <= 0) {
            cancel(app);
            return;
        }

        long delayMs = minutes * 60_000L;
        scheduleAlarm(app, delayMs);
        scheduleBackupJob(app, delayMs);
    }

    private static void scheduleAlarm(Context app, long delayMs) {
        try {
            AlarmManager alarm = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
            if (alarm == null) return;

            PendingIntent pi = pendingIntent(app,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            long triggerAt = SystemClock.elapsedRealtime() + delayMs;

            if (Build.VERSION.SDK_INT >= 31) {
                if (alarm.canScheduleExactAlarms()) {
                    alarm.setExactAndAllowWhileIdle(
                            AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
                } else {
                    alarm.setAndAllowWhileIdle(
                            AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
                }
            } else if (Build.VERSION.SDK_INT >= 23) {
                alarm.setExactAndAllowWhileIdle(
                        AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
            } else {
                alarm.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void scheduleBackupJob(Context app, long delayMs) {
        try {
            JobScheduler scheduler = (JobScheduler) app.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (scheduler == null) return;

            // With exact-alarm access, let AlarmManager have a small head start. Without it,
            // JobScheduler becomes the primary fallback immediately at the selected interval.
            boolean exact = canScheduleExact(app);
            long minLatency = exact ? delayMs + 90_000L : delayMs;
            long deadline = exact ? delayMs + 4L * 60_000L : delayMs + 5L * 60_000L;

            JobInfo job = new JobInfo.Builder(
                    BACKUP_JOB_ID,
                    new ComponentName(app, AutoRefreshJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true)
                    .setMinimumLatency(minLatency)
                    .setOverrideDeadline(deadline)
                    .build();
            scheduler.schedule(job);
        } catch (Throwable ignored) {
        }
    }

    /** Prevent the alarm and backup job from both refreshing the widget for one interval. */
    public static synchronized boolean claimRun(Context context) {
        Context app = context.getApplicationContext();
        int minutes = getIntervalMinutes(app);
        if (minutes <= 0) return false;

        long now = System.currentTimeMillis();
        long last = prefs(app).getLong(KEY_LAST_CLAIM_WALL, 0L);
        long guardMs = Math.min(5L * 60_000L,
                Math.max(90_000L, minutes * 60_000L / 3L));
        if (last > 0L && now - last >= 0L && now - last < guardMs) return false;

        prefs(app).edit().putLong(KEY_LAST_CLAIM_WALL, now).commit();
        return true;
    }

    public static void noteAttempt(Context context, boolean success, String detail) {
        long now = System.currentTimeMillis();
        SharedPreferences.Editor edit = prefs(context).edit()
                .putLong(KEY_LAST_ATTEMPT_WALL, now)
                .putString(KEY_LAST_DETAIL, detail == null ? "" : detail);
        if (success) edit.putLong(KEY_LAST_SUCCESS_WALL, now);
        edit.apply();
    }


    public static void cancelAlarm(Context context) {
        Context app = context.getApplicationContext();
        try {
            AlarmManager alarm = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
            if (alarm == null) return;
            PendingIntent pi = pendingIntent(app,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) alarm.cancel(pi);
        } catch (Throwable ignored) {
        }
    }

    public static void cancelBackupJob(Context context) {
        try {
            Context app = context.getApplicationContext();
            JobScheduler scheduler = (JobScheduler) app.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (scheduler != null) scheduler.cancel(BACKUP_JOB_ID);
        } catch (Throwable ignored) {
        }
    }

    public static void cancel(Context context) {
        Context app = context.getApplicationContext();
        try {
            AlarmManager alarm = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
            if (alarm != null) {
                PendingIntent pi = pendingIntent(app,
                        PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                if (pi != null) alarm.cancel(pi);
            }
        } catch (Throwable ignored) {
        }
        try {
            JobScheduler scheduler = (JobScheduler) app.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (scheduler != null) scheduler.cancel(BACKUP_JOB_ID);
        } catch (Throwable ignored) {
        }
    }

    public static String labelFor(int minutes) {
        switch (normalize(minutes)) {
            case 10: return "10분";
            case 30: return "30분";
            case 60: return "1시간";
            case 120: return "2시간";
            case 720: return "12시간";
            case 1440: return "24시간";
            default: return "수동";
        }
    }

    public static int[] choices() {
        return new int[]{0, 10, 30, 60, 120, 720, 1440};
    }

    private static int normalize(int minutes) {
        switch (minutes) {
            case 10:
            case 30:
            case 60:
            case 120:
            case 720:
            case 1440:
                return minutes;
            default:
                return 0;
        }
    }

    private static PendingIntent pendingIntent(Context context, int flags) {
        Intent intent = new Intent(context, AutoRefreshReceiver.class)
                .setAction(ACTION_AUTO_REFRESH);
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext()
                .getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
}

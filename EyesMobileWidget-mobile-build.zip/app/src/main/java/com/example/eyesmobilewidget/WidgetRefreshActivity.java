package com.example.eyesmobilewidget;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.FrameLayout;

/**
 * v5.2 user-triggered refresh host.
 *
 * EyesMobile's login flow can behave differently in a WebView that is never attached to a real
 * window. The widget therefore opens this fully transparent, no-animation Activity for manual
 * refreshes. The WebView is genuinely attached and laid out like a browser, but is visually
 * transparent. Healthy sessions still use the existing fast HTTP race and close this Activity
 * immediately when that path wins.
 */
public final class WidgetRefreshActivity extends Activity {
    private WebView webView;
    private boolean refreshStarted;
    private boolean completed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(0, 0);

        Window window = getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setDimAmount(0f);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.TRANSPARENT);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        // Keep the browser surface attached and rendered while making it effectively invisible.
        webView.setAlpha(0.01f);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);
        root.post(this::startRefreshOnce);
    }

    private void startRefreshOnce() {
        if (refreshStarted || isFinishing() || isDestroyed()) return;
        refreshStarted = true;
        EyesMobileWidgetProvider.startAttachedUserRefresh(
                getApplicationContext(), webView, this::finishQuietly);
    }

    private void finishQuietly() {
        runOnUiThread(() -> {
            if (completed) return;
            completed = true;
            try {
                if (webView != null) {
                    webView.stopLoading();
                    webView.setWebViewClient(null);
                    webView.destroy();
                    webView = null;
                }
            } catch (Throwable ignored) {
            }
            finish();
            overridePendingTransition(0, 0);
        });
    }

    @Override
    public void onBackPressed() {
        // A manual refresh host should never become a visible navigation destination.
        finishQuietly();
    }
}

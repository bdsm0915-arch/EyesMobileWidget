package com.example.eyesmobilewidget;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.FrameLayout;

/**
 * v5.2 user-triggered refresh host.
 *
 * EyesMobile's login flow can behave differently in a WebView that is never attached to a real
 * window. The widget therefore opens this fully transparent, no-animation Activity for manual
 * refreshes. The WebView is genuinely attached and laid out like a browser, but is visually
 * transparent. Healthy sessions still use the existing fast HTTP race and close this Activity
 * immediately when that path wins.
 */
public final class WidgetRefreshActivity extends Activity {
    private WebView webView;
    private boolean refreshStarted;
    private boolean completed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(0, 0);

        Window window = getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            window.setDimAmount(0f);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.setNavigationBarContrastEnforced(false);
                window.setStatusBarContrastEnforced(false);
            }
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.TRANSPARENT);
        root.setClipChildren(false);
        root.setClipToPadding(false);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        // Keep the browser surface attached and rendered while making it effectively invisible.
        webView.setAlpha(0.01f);
        // Give the page a real phone-sized layout even though the host window itself occupies
        // only one pixel. EyesMobile still runs its normal attached WebView/XHR path, while the
        // launcher is not covered by a full-screen translucent window.
        root.addView(webView, new FrameLayout.LayoutParams(1080, 2400));

        setContentView(root);
        if (window != null) {
            WindowManager.LayoutParams attrs = window.getAttributes();
            attrs.width = 1;
            attrs.height = 1;
            attrs.gravity = Gravity.TOP | Gravity.START;
            attrs.x = 0;
            attrs.y = 0;
            window.setAttributes(attrs);
        }
        root.post(this::startRefreshOnce);
    }

    private void startRefreshOnce() {
        if (refreshStarted || isFinishing() || isDestroyed()) return;
        refreshStarted = true;
        EyesMobileWidgetProvider.startAttachedUserRefresh(
                getApplicationContext(), webView, this::finishQuietly);
    }

    private void finishQuietly() {
        runOnUiThread(() -> {
            if (completed) return;
            completed = true;
            try {
                if (webView != null) {
                    webView.stopLoading();
                    webView.setWebViewClient(null);
                    webView.destroy();
                    webView = null;
                }
            } catch (Throwable ignored) {
            }
            finish();
            overridePendingTransition(0, 0);
        });
    }

    @Override
    public void onBackPressed() {
        // A manual refresh host should never become a visible navigation destination.
        finishQuietly();
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;

public final class WidgetStorage {
    private static final String PREFS = "eyes_mobile_widget";

    private WidgetStorage() {}

    public static void save(Context context, UsageData d) {
        UsageData old = load(context);
        boolean hadOld = old.updatedAt > 0;
        boolean changed = !same(old.dataUsed, d.dataUsed)
                || !same(old.dataTotal, d.dataTotal)
                || !same(old.voiceUsed, d.voiceUsed)
                || !same(old.voiceTotal, d.voiceTotal)
                || !same(old.smsUsed, d.smsUsed)
                || !same(old.smsTotal, d.smsTotal)
                || !same(old.addonVoiceUsed, d.addonVoiceUsed)
                || !same(old.addonVoiceTotal, d.addonVoiceTotal);

        String status = "업데이트 완료";

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("data_used", d.dataUsed)
                .putString("data_total", d.dataTotal)
                .putInt("data_percent", d.dataPercent)
                .putString("voice_used", d.voiceUsed)
                .putString("voice_total", d.voiceTotal)
                .putInt("voice_percent", d.voicePercent)
                .putString("sms_used", d.smsUsed)
                .putString("sms_total", d.smsTotal)
                .putInt("sms_percent", d.smsPercent)
                .putString("addon_voice_used", d.addonVoiceUsed)
                .putString("addon_voice_total", d.addonVoiceTotal)
                .putInt("addon_voice_percent", d.addonVoicePercent)
                .putLong("updated_at", d.updatedAt)
                .putString("status", status)
                .apply();
    }

    public static UsageData load(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long updated = p.getLong("updated_at", 0L);
        return new UsageData(
                p.getString("data_used", "--"), p.getString("data_total", "--"), p.getInt("data_percent", 0),
                p.getString("voice_used", "--"), p.getString("voice_total", "--"), p.getInt("voice_percent", 0),
                p.getString("sms_used", "--"), p.getString("sms_total", "--"), p.getInt("sms_percent", 0),
                p.getString("addon_voice_used", "--"), p.getString("addon_voice_total", "--"), p.getInt("addon_voice_percent", 0),
                updated
        );
    }

    public static void setStatus(Context context, String status) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("status", status).apply();
    }

    public static String getStatus(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("status", "앱을 열어 아이즈모바일에 로그인하세요");
    }

    private static boolean same(String a, String b) {
        if (a == null) return b == null;
        return a.equals(b);
    }
}

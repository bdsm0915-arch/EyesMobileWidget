package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class WidgetStorage {
    private static final String PREFS = "eyes_mobile_widget";
    private static final String ADDON_TOTAL = "300분";

    private WidgetStorage() {}

    public static void save(Context context, UsageData d) {
        if (d == null) return;

        UsageData old = load(context);

        // A partial portal response can contain data plus only one of voice/SMS. Keep the last
        // valid counter for the missing category instead of replacing it with "--". Valid zero
        // values (0초, 0건) still replace the old value after the monthly reset.
        String voiceUsed = d.voiceUsed;
        String voiceTotal = d.voiceTotal;
        int voicePercent = d.voicePercent;
        if (!hasDuration(voiceUsed) && old != null && old.updatedAt > 0L && hasDuration(old.voiceUsed)) {
            voiceUsed = old.voiceUsed;
            voiceTotal = old.voiceTotal;
            voicePercent = old.voicePercent;
        }

        String smsUsed = d.smsUsed;
        String smsTotal = d.smsTotal;
        int smsPercent = d.smsPercent;
        if (!hasSmsCount(smsUsed) && old != null && old.updatedAt > 0L && hasSmsCount(old.smsUsed)) {
            smsUsed = old.smsUsed;
            smsTotal = old.smsTotal;
            smsPercent = old.smsPercent;
        }

        // Supplementary-call inference was removed from the widget. Store the carrier's normal
        // voice and SMS counters exactly as parsed; never subtract an inferred addon duration.
        d = new UsageData(
                d.dataUsed, d.dataTotal, d.dataPercent,
                voiceUsed, voiceTotal, voicePercent,
                smsUsed, smsTotal, smsPercent,
                "0초", ADDON_TOTAL, 0,
                d.updatedAt);

        d = normalizeForWidget(d);

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("data_used", d.dataUsed)
                .putString("data_total", d.dataTotal)
                .putInt("data_percent", d.dataPercent)
                .putString("voice_used", d.voiceUsed)
                .putString("voice_total", d.voiceTotal)
                .putInt("voice_percent", d.voicePercent)
                .putString("sms_used", d.smsUsed)
                .putString("sms_total", d.smsTotal)
                .putInt("sms_percent", d.smsPercent)
                .putString("addon_voice_used", d.addonVoiceUsed)
                .putString("addon_voice_total", ADDON_TOTAL)
                .putInt("addon_voice_percent", d.addonVoicePercent)
                .putLong("updated_at", d.updatedAt)
                .putString("status", "업데이트 완료")
                .putBoolean("v76_addon_cache_valid", true)
                .apply();
    }

    /**
     * v8.7 fallback for EyesMobile responses where "음성" is a combined counter and the
     * supplementary 300-minute field remains at 0. For unlimited/basic-provided voice plans:
     * - a real non-zero addon counter wins and is subtracted from the combined voice value;
     * - if addon is explicitly 0 but raw voice increased since the previous refresh, accumulate
     *   only that new raw delta in the addon bucket and subtract the accumulated addon amount from
     *   the displayed normal-voice value.
     *
     * This is intentionally limited to 기본제공/무제한 voice plans so finite-minute plans keep the
     * carrier's original accounting untouched.
     */
    private static UsageData splitCombinedVoiceAddon(UsageData old, String previousRawVoice, UsageData incoming) {
        if (incoming == null || !isBasicVoice(incoming.voiceTotal)) return incoming;

        double rawVoiceSeconds = durationSecondsOrInvalid(incoming.voiceUsed);
        if (rawVoiceSeconds < 0d) return incoming;

        double reportedAddonSeconds = durationSecondsOrInvalid(incoming.addonVoiceUsed);
        if (reportedAddonSeconds < 0d) reportedAddonSeconds = 0d;

        double addonSeconds = reportedAddonSeconds;
        if (reportedAddonSeconds <= 0.5d && old != null && old.updatedAt > 0L) {
            double oldAddonSeconds = Math.max(0d, durationSeconds(old.addonVoiceUsed));
            double previousRawSeconds = durationSecondsOrInvalid(previousRawVoice);
            if (previousRawSeconds >= 0d && rawVoiceSeconds > previousRawSeconds + 0.5d) {
                addonSeconds = Math.min(300d * 60d,
                        oldAddonSeconds + (rawVoiceSeconds - previousRawSeconds));
            } else {
                // No new combined-voice movement: keep the already inferred addon amount instead
                // of falling back to the portal's persistent 0-minute field.
                addonSeconds = oldAddonSeconds;
            }
        }

        if (addonSeconds <= 0.5d) return incoming;

        double normalVoiceSeconds = Math.max(0d, rawVoiceSeconds - addonSeconds);
        String addonUsed = formatDuration(addonSeconds);
        String normalVoiceUsed = formatDuration(normalVoiceSeconds);

        return new UsageData(
                incoming.dataUsed, incoming.dataTotal, incoming.dataPercent,
                normalVoiceUsed, incoming.voiceTotal, incoming.voicePercent,
                incoming.smsUsed, incoming.smsTotal, incoming.smsPercent,
                addonUsed, ADDON_TOTAL, addonPercent(addonUsed),
                incoming.updatedAt);
    }

    public static UsageData load(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long updated = p.getLong("updated_at", 0L);
        String addonUsed = p.getString("addon_voice_used", "--");
        int addonPercent = p.getInt("addon_voice_percent", 0);

        // v7.0-v7.5 could cache the 300-minute allowance as if it were used time.
        // On first v7.6 launch, discard only that unreliable supplementary-call cache.
        if (!p.getBoolean("v76_addon_cache_valid", false)) {
            addonUsed = "0초";
            addonPercent = 0;
        }

        UsageData raw = new UsageData(
                p.getString("data_used", "--"), p.getString("data_total", "--"), p.getInt("data_percent", 0),
                p.getString("voice_used", "--"), p.getString("voice_total", "--"), p.getInt("voice_percent", 0),
                p.getString("sms_used", "--"), p.getString("sms_total", "--"), p.getInt("sms_percent", 0),
                addonUsed, ADDON_TOTAL, addonPercent,
                updated
        );
        return normalizeForWidget(raw);
    }

    private static UsageData normalizeForWidget(UsageData d) {
        if (d == null) return null;
        String addonUsed = normalizeAddonUsed(d.addonVoiceUsed);
        int addonPercent = addonPercent(addonUsed);
        return new UsageData(
                d.dataUsed, d.dataTotal, d.dataPercent,
                d.voiceUsed, d.voiceTotal, d.voicePercent,
                d.smsUsed, d.smsTotal, d.smsPercent,
                addonUsed, ADDON_TOTAL, addonPercent,
                d.updatedAt
        );
    }

    private static boolean isBasicVoice(String total) {
        if (total == null) return false;
        String t = total.replaceAll("\\s+", "");
        return t.contains("기본제공") || t.contains("무제한");
    }

    private static boolean hasDuration(String value) {
        return durationSecondsOrInvalid(value) >= 0d;
    }

    private static boolean hasSmsCount(String value) {
        if (value == null) return false;
        return Pattern.compile("[0-9][0-9,]*\\s*(?:건|회|개)").matcher(value.trim()).find();
    }

    private static String normalizeAddonUsed(String value) {
        if (value == null) return "0초";
        String v = value.trim();
        if (v.isEmpty() || v.equals("--") || v.equals("-") || v.equals("0") || v.equals("0분")) return "0초";
        return v;
    }

    private static int addonPercent(String value) {
        double seconds = durationSeconds(value);
        if (seconds <= 0d) return 0;
        double raw = seconds * 100d / (300d * 60d);
        int p = (int) Math.round(raw);
        if (p == 0) p = 1;
        return Math.max(0, Math.min(100, p));
    }

    private static double durationSeconds(String value) {
        double parsed = durationSecondsOrInvalid(value);
        return parsed < 0d ? 0d : parsed;
    }

    private static double durationSecondsOrInvalid(String value) {
        if (value == null) return -1d;
        String v = value.replace(",", "").trim().toUpperCase(Locale.ROOT);
        if (v.isEmpty() || "--".equals(v) || "-".equals(v)) return -1d;

        Matcher clock = Pattern.compile("(?<![0-9])([0-9]{1,3}):([0-9]{2})(?::([0-9]{2}))?(?![0-9])").matcher(v);
        if (clock.find()) {
            try {
                double a = Double.parseDouble(clock.group(1));
                double b = Double.parseDouble(clock.group(2));
                String third = clock.group(3);
                return third == null ? a * 60d + b : a * 3600d + b * 60d + Double.parseDouble(third);
            } catch (Exception ignored) {}
        }
        Matcher m = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)\\s*(시간|분|초|MINUTE|MIN)", Pattern.CASE_INSENSITIVE).matcher(v);
        double seconds = 0d;
        boolean found = false;
        while (m.find()) {
            double n;
            try { n = Double.parseDouble(m.group(1)); } catch (Exception e) { continue; }
            String unit = m.group(2).toUpperCase(Locale.ROOT);
            if ("시간".equals(unit)) seconds += n * 3600d;
            else if ("초".equals(unit)) seconds += n;
            else seconds += n * 60d;
            found = true;
        }
        return found ? Math.max(0d, seconds) : -1d;
    }

    private static String formatDuration(double rawSeconds) {
        long seconds = Math.max(0L, Math.round(rawSeconds));
        if (seconds == 0L) return "0초";
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long remainSeconds = seconds % 60L;
        StringBuilder out = new StringBuilder();
        if (hours > 0L) out.append(hours).append("시간");
        if (minutes > 0L) out.append(minutes).append("분");
        if (remainSeconds > 0L) out.append(remainSeconds).append("초");
        return out.length() == 0 ? "0초" : out.toString();
    }

    public static void setStatus(Context context, String status) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("status", status).apply();
    }

    public static String getStatus(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("status", "앱을 열어 아이즈모바일에 로그인하세요");
    }

    private static boolean same(String a, String b) {
        if (a == null) return b == null;
        return a.equals(b);
    }
}

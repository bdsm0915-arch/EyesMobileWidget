package com.example.eyesmobilewidget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Receives the user-selected auto-refresh alarm and hands the work to the durable JobService. */
public final class AutoRefreshReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !AutoRefreshScheduler.ACTION_AUTO_REFRESH.equals(intent.getAction())) return;

        Context app = context.getApplicationContext();
        if (AutoRefreshScheduler.getIntervalMinutes(app) <= 0) {
            AutoRefreshScheduler.cancel(app);
            return;
        }

        // Arm the next run first so a process kill during this refresh does not break the cadence.
        AutoRefreshScheduler.scheduleNext(app);

        // Do not stack an automatic refresh on top of an active user refresh/login recovery.
        if (HiddenWebViewRefresher.isRunning()
                || FastUsageRefresher.isRunning()
                || FastAutoLogin.isRunning()) {
            return;
        }

        WidgetRefreshJobService.schedule(app);
    }
}

package com.example.eyesmobilewidget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** AlarmManager entry point for user-selected automatic widget refresh. */
public final class AutoRefreshReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !AutoRefreshScheduler.ACTION_AUTO_REFRESH.equals(intent.getAction())) return;

        Context app = context.getApplicationContext();
        if (AutoRefreshScheduler.getIntervalMinutes(app) <= 0) {
            AutoRefreshScheduler.cancel(app);
            return;
        }

        // Alarm and JobScheduler are intentionally both armed. Only the first one for a given
        // interval is allowed to do work; the winner immediately re-arms both for the next cycle.
        if (!AutoRefreshScheduler.claimRun(app)) {
            AutoRefreshScheduler.ensureScheduled(app);
            return;
        }

        final PendingResult pending = goAsync();
        // This alarm won the race, so remove the backup for this cycle before arming the next one.
        AutoRefreshScheduler.cancelBackupJob(app);
        AutoRefreshScheduler.scheduleNext(app);
        AutoRefreshWorker.run(app, () -> {
            try {
                pending.finish();
            } catch (Throwable ignored) {
            }
        });
    }
}

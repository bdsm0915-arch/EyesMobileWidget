package com.example.eyesmobilewidget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * v5.5 background-only automatic refresh path.
 *
 * Automatic refresh no longer starts the manual JobService/hidden-WebView race. That path can be
 * heavily deferred while the app is backgrounded on modern Samsung/Android builds. Instead the
 * alarm performs the already-learned lightweight usage request directly and, only when the server
 * clearly reports an expired session, gives the direct HTTP auto-login one chance to recover it.
 */
public final class AutoRefreshReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !AutoRefreshScheduler.ACTION_AUTO_REFRESH.equals(intent.getAction())) return;

        Context app = context.getApplicationContext();
        if (AutoRefreshScheduler.getIntervalMinutes(app) <= 0) {
            AutoRefreshScheduler.cancel(app);
            return;
        }

        // Arm the next run before doing network work so a process kill cannot break the cadence.
        AutoRefreshScheduler.scheduleNext(app);

        if (HiddenWebViewRefresher.isRunning()
                || FastUsageRefresher.isRunning()
                || FastAutoLogin.isRunning()) {
            return;
        }

        final PendingResult pending = goAsync();
        final PowerManager.WakeLock wakeLock = acquireWakeLock(app);
        final AtomicBoolean finished = new AtomicBoolean(false);

        final Runnable finish = () -> {
            if (!finished.compareAndSet(false, true)) return;
            try {
                if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            } catch (Throwable ignored) {
            }
            try {
                pending.finish();
            } catch (Throwable ignored) {
            }
        };

        // A manual successful refresh learns the tiny usage endpoint. Until that exists there is
        // no safe background-only request to make; leave cached widget data untouched.
        if (!FastUsageRefresher.shouldTry(app)) {
            finish.run();
            return;
        }

        FastUsageRefresher.refreshAsync(app, (success, detail) -> {
            if (success) {
                finish.run();
                return;
            }

            // Never start a WebView from an automatic/background refresh. If the lightweight
            // request proves the session expired, direct HTTP auto-login gets one silent attempt.
            if (FastAutoLogin.shouldAttempt(app, detail)) {
                FastAutoLogin.refreshAsync(app, detail, (loginSuccess, loginDetail) -> finish.run());
            } else {
                finish.run();
            }
        });
    }

    private static PowerManager.WakeLock acquireWakeLock(Context context) {
        try {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm == null) return null;
            PowerManager.WakeLock lock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "EyesMobileWidget:AutoRefresh");
            lock.setReferenceCounted(false);
            lock.acquire(15_000L);
            return lock;
        } catch (Throwable ignored) {
            return null;
        }
    }
}

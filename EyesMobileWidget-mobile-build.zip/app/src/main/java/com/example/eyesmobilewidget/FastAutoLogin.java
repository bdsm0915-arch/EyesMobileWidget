package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v4.4 fast session recovery.
 *
 * When the learned usage endpoint proves that the server session has expired, try to create a
 * fresh EyesMobile session with a tiny HTTP form-login sequence before paying the cost of an
 * off-screen WebView. The login page itself is fetched fresh every time, so hidden CSRF values
 * are never persisted. If the site changes to a JS-only/OTP/CAPTCHA flow this class simply gives
 * up and the existing HiddenWebViewRefresher remains the fallback.
 */
public final class FastAutoLogin {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);

    private static final Pattern FORM_PATTERN = Pattern.compile("(?is)<form\\b([^>]*)>(.*?)</form>");
    private static final Pattern INPUT_PATTERN = Pattern.compile("(?is)<input\\b([^>]*)>");
    private static final Pattern BUTTON_PATTERN = Pattern.compile("(?is)<button\\b([^>]*)>(.*?)</button>");
    private static final Pattern ATTR_PATTERN = Pattern.compile(
            "([A-Za-z_:][-A-Za-z0-9_:.]*)\\s*(?:=\\s*(?:\\\"([^\\\"]*)\\\"|'([^']*)'|([^\\s\\\"'=<>`]+)))?");

    private FastAutoLogin() {}

    public interface Callback {
        void onComplete(boolean success, String detail);
    }

    public static boolean isRunning() {
        return RUNNING.get();
    }

    public static boolean shouldAttempt(Context context, String detail) {
        if (!AutoLoginHelper.hasCredentials(context)) return false;
        if (UsageEndpointStore.getConfirmed(context) == null) return false;
        if (detail == null) return false;
        return detail.startsWith("LOGIN_REDIRECT")
                || detail.startsWith("LOGGED_OUT")
                || detail.startsWith("NO_COOKIE")
                // Some EyesMobile expired sessions return a guest/empty payload with HTTP 200
                // instead of a clear login redirect. A previously verified endpoint returning no
                // usage is worth one cheap direct-login attempt before starting WebView.
                || detail.startsWith("NO_USAGE");
    }

    public static void refreshAsync(Context context, String failureDetail, Callback callback) {
        final Context app = context.getApplicationContext();
        if (!shouldAttempt(app, failureDetail)) {
            if (callback != null) MAIN.post(() -> callback.onComplete(false, "NOT_APPLICABLE"));
            return;
        }
        if (!RUNNING.compareAndSet(false, true)) {
            if (callback != null) MAIN.post(() -> callback.onComplete(false, "BUSY"));
            return;
        }

        final SecureCredentialStore.Credentials credentials = SecureCredentialStore.load(app);
        final String usageEndpoint = UsageEndpointStore.getConfirmed(app);
        final String userAgent = SessionCookieStore.getUserAgent(app);
        final Map<String, String> usageHeaders = UsageEndpointStore.getConfirmedHeaders(app);
        final String initialCookies = SessionCookieStore.currentCookieHeader(app,
                usageEndpoint == null ? EyesMobileFetcher.MY_PAGE_URL : usageEndpoint);
        final String loginHint = extractLoginHint(failureDetail);

        EXEC.execute(() -> {
            LoginResult result;
            try {
                result = loginAndFetch(credentials, usageEndpoint, userAgent, usageHeaders,
                        initialCookies, loginHint);
            } catch (Throwable t) {
                result = LoginResult.fail("ERROR");
            }

            final LoginResult done = result;
            MAIN.post(() -> {
                try {
                    // Even if the final usage parse failed, freshly rotated cookies can make the
                    // WebView fallback much faster and more reliable.
                    commitCookies(done.pendingCookies);
                    SessionCookieStore.flush();

                    if (done.data != null) {
                        WidgetStorage.save(app, done.data);
                        VerifiedSessionStore.captureVerified(app);
                        UsageEndpointStore.noteFastSuccess(app, usageEndpoint,
                                usageHeaders.get("X-Requested-With"),
                                usageHeaders.get("Accept"),
                                usageHeaders.get("Referer"));
                        RefreshMetrics.decorateSuccess(app, "고속자동로그인");
                        EyesMobileWidgetProvider.updateAll(app);
                    }
                } catch (Throwable ignored) {
                } finally {
                    RUNNING.set(false);
                    if (callback != null) callback.onComplete(done.data != null, done.detail);
                }
            });
        });
    }

    private static LoginResult loginAndFetch(SecureCredentialStore.Credentials credentials,
                                             String usageEndpoint,
                                             String userAgent,
                                             Map<String, String> usageHeaders,
                                             String initialCookies,
                                             String loginHint) {
        if (credentials == null) return LoginResult.fail("NO_CREDENTIALS");
        if (usageEndpoint == null || usageEndpoint.trim().isEmpty()) return LoginResult.fail("NO_USAGE_ENDPOINT");

        CookieJar jar = new CookieJar(initialCookies);
        List<PendingCookie> pending = new ArrayList<>();

        LoginPage loginPage = discoverLoginPage(loginHint, userAgent, jar, pending);
        if (loginPage == null) return LoginResult.fail("NO_LOGIN_PAGE", pending);

        LoginForm form = parseLoginForm(loginPage.url, loginPage.body);
        if (form == null) return LoginResult.fail("NO_HTML_LOGIN_FORM", pending);
        // Never put the stored password in a URL. EyesMobile's normal credential form is
        // expected to POST; anything else falls back to the browser path.
        if (!"POST".equals(form.method)) {
            return LoginResult.fail("UNSUPPORTED_LOGIN_METHOD", pending);
        }
        if (form.enctype != null && !form.enctype.isEmpty()
                && !form.enctype.toLowerCase(Locale.ROOT).contains("application/x-www-form-urlencoded")) {
            return LoginResult.fail("UNSUPPORTED_LOGIN_ENCTYPE", pending);
        }

        LinkedHashMap<String, String> params = new LinkedHashMap<>(form.hiddenFields);
        params.put(form.userField, credentials.userId);
        params.put(form.passwordField, credentials.password);
        if (form.submitField != null && !form.submitField.isEmpty() && !params.containsKey(form.submitField)) {
            params.put(form.submitField, form.submitValue == null ? "" : form.submitValue);
        }
        String encoded = encodeForm(params);

        HttpResponse loginResponse = request("POST", form.action, encoded, userAgent, jar, pending,
                loginPage.url, "application/x-www-form-urlencoded; charset=UTF-8");
        if (loginResponse == null) return LoginResult.fail("LOGIN_NETWORK", pending);

        // Follow the small post-login redirect chain manually so every Set-Cookie is added to the
        // in-memory jar before the usage endpoint is called.
        HttpResponse settled = followRedirects(loginResponse, userAgent, jar, pending, 5);
        if (settled == null) return LoginResult.fail("LOGIN_REDIRECT_FAILED", pending);

        UsageData data = fetchUsage(usageEndpoint, userAgent, usageHeaders, jar, pending);
        if (data != null) return LoginResult.success(data, pending);

        return LoginResult.fail("LOGIN_DID_NOT_CREATE_SESSION", pending);
    }

    private static LoginPage discoverLoginPage(String loginHint,
                                               String userAgent,
                                               CookieJar jar,
                                               List<PendingCookie> pending) {
        String start = notEmpty(loginHint) ? loginHint : EyesMobileFetcher.MY_PAGE_URL;
        HttpResponse response = request("GET", start, null, userAgent, jar, pending,
                EyesMobileFetcher.MY_PAGE_URL, null);
        if (response == null) return null;

        response = followRedirects(response, userAgent, jar, pending, 6);
        if (response == null) return null;

        if (response.code >= 200 && response.code < 300 && notEmpty(response.body)) {
            if (parseLoginForm(response.url, response.body) != null || looksLikeLoginPage(response.url, response.body)) {
                return new LoginPage(response.url, response.body);
            }
        }

        // A redirect hint can occasionally point to an intermediate route. Retry MyPage once to
        // obtain the server's current canonical login location/cookies.
        if (notEmpty(loginHint) && !sameUrl(start, EyesMobileFetcher.MY_PAGE_URL)) {
            response = request("GET", EyesMobileFetcher.MY_PAGE_URL, null, userAgent, jar, pending,
                    EyesMobileFetcher.MY_PAGE_URL, null);
            if (response == null) return null;
            response = followRedirects(response, userAgent, jar, pending, 6);
            if (response != null && response.code >= 200 && response.code < 300 && notEmpty(response.body)
                    && (parseLoginForm(response.url, response.body) != null
                    || looksLikeLoginPage(response.url, response.body))) {
                return new LoginPage(response.url, response.body);
            }
        }
        return null;
    }

    private static HttpResponse followRedirects(HttpResponse first,
                                                String userAgent,
                                                CookieJar jar,
                                                List<PendingCookie> pending,
                                                int max) {
        HttpResponse response = first;
        for (int i = 0; i < max && response != null && isRedirect(response.code); i++) {
            String next = response.location;
            if (!notEmpty(next)) return response;
            response = request("GET", next, null, userAgent, jar, pending,
                    response.url, null);
        }
        return response;
    }

    private static UsageData fetchUsage(String endpoint,
                                        String userAgent,
                                        Map<String, String> learnedHeaders,
                                        CookieJar jar,
                                        List<PendingCookie> pending) {
        String accept = learnedHeaders == null ? null : learnedHeaders.get("Accept");
        String xrw = learnedHeaders == null ? null : learnedHeaders.get("X-Requested-With");
        String referer = learnedHeaders == null ? null : learnedHeaders.get("Referer");

        HttpResponse response = request("GET", endpoint, null, userAgent, jar, pending,
                notEmpty(referer) ? referer : EyesMobileFetcher.MY_PAGE_URL,
                null, new HeaderPair("X-Requested-With", xrw), new HeaderPair("Accept", accept));
        if (response == null || response.code < 200 || response.code >= 300 || !notEmpty(response.body)) return null;
        return UsageEndpointStore.parseAny(response.body);
    }

    private static HttpResponse request(String method,
                                        String rawUrl,
                                        String body,
                                        String userAgent,
                                        CookieJar jar,
                                        List<PendingCookie> pending,
                                        String referer,
                                        String contentType,
                                        HeaderPair... extraHeaders) {
        HttpURLConnection conn = null;
        try {
            // Never forward session cookies or credentials outside EyesMobile. If the login flow
            // moves to an external SSO/OTP host, let the WebView fallback handle it instead.
            if (!isEyesUrl(rawUrl)) return null;
            URL url = new URL(rawUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(800);
            conn.setReadTimeout(1200);
            conn.setRequestMethod(method);
            conn.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en;q=0.7");
            conn.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
            conn.setRequestProperty("Pragma", "no-cache");
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json,text/plain,*/*");
            if (notEmpty(userAgent)) conn.setRequestProperty("User-Agent", userAgent);
            if (notEmpty(referer)) conn.setRequestProperty("Referer", referer);
            if (jar != null && notEmpty(jar.header())) conn.setRequestProperty("Cookie", jar.header());
            if (extraHeaders != null) {
                for (HeaderPair h : extraHeaders) {
                    if (h != null && notEmpty(h.name) && notEmpty(h.value)) conn.setRequestProperty(h.name, h.value);
                }
            }

            if ("POST".equalsIgnoreCase(method)) {
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", notEmpty(contentType)
                        ? contentType : "application/x-www-form-urlencoded; charset=UTF-8");
                try {
                    String origin = url.getProtocol() + "://" + url.getHost()
                            + (url.getPort() > 0 ? ":" + url.getPort() : "");
                    conn.setRequestProperty("Origin", origin);
                } catch (Throwable ignored) {
                }
                byte[] bytes = body == null ? new byte[0] : body.getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = conn.getOutputStream()) {
                    out.write(bytes);
                }
            }

            int code = conn.getResponseCode();
            absorbSetCookies(conn, rawUrl, jar, pending);
            String location = resolve(rawUrl, conn.getHeaderField("Location"));
            String responseBody = "";
            if (!isRedirect(code)) {
                InputStream in = null;
                try {
                    in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
                    if (in != null) responseBody = readLimited(in, 700_000);
                } catch (Throwable ignored) {
                }
            }
            return new HttpResponse(rawUrl, code, location, responseBody);
        } catch (java.net.SocketTimeoutException e) {
            return null;
        } catch (Throwable t) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static LoginForm parseLoginForm(String pageUrl, String html) {
        if (!notEmpty(html)) return null;
        Matcher fm = FORM_PATTERN.matcher(html);
        while (fm.find()) {
            String formAttrsRaw = fm.group(1);
            String inner = fm.group(2);
            Map<String, String> formAttrs = parseAttrs(formAttrsRaw);

            List<Map<String, String>> inputs = new ArrayList<>();
            Matcher im = INPUT_PATTERN.matcher(inner);
            while (im.find()) inputs.add(parseAttrs(im.group(1)));

            Map<String, String> password = null;
            for (Map<String, String> attrs : inputs) {
                String type = lower(attrs.get("type"));
                if ("password".equals(type) && notEmpty(attrs.get("name"))) {
                    password = attrs;
                    break;
                }
            }
            if (password == null) continue;

            Map<String, String> user = null;
            int bestScore = Integer.MIN_VALUE;
            for (Map<String, String> attrs : inputs) {
                String name = attrs.get("name");
                if (!notEmpty(name) || attrs == password) continue;
                String type = lower(attrs.get("type"));
                if (type.isEmpty()) type = "text";
                if ("hidden".equals(type) || "password".equals(type) || "submit".equals(type)
                        || "button".equals(type) || "checkbox".equals(type) || "radio".equals(type)
                        || "file".equals(type)) continue;

                String key = lower(name + " " + value(attrs, "id") + " " + value(attrs, "placeholder")
                        + " " + value(attrs, "autocomplete"));
                int score = 0;
                if ("email".equals(type)) score += 12;
                if ("text".equals(type)) score += 3;
                if (containsAny(key, "user", "userid", "user_id", "login", "email", "e-mail", "member",
                        "account", "아이디", "이메일")) score += 24;
                if (containsAny(key, "search", "검색", "phone", "tel", "name", "이름")) score -= 18;
                if (score > bestScore) {
                    bestScore = score;
                    user = attrs;
                }
            }
            if (user == null || !notEmpty(user.get("name"))) continue;

            LinkedHashMap<String, String> hidden = new LinkedHashMap<>();
            String submitField = null;
            String submitValue = null;
            for (Map<String, String> attrs : inputs) {
                String name = attrs.get("name");
                if (!notEmpty(name)) continue;
                String type = lower(attrs.get("type"));
                if ("hidden".equals(type)) hidden.put(name, value(attrs, "value"));
                if (submitField == null && ("submit".equals(type) || "image".equals(type))) {
                    submitField = name;
                    submitValue = value(attrs, "value");
                }
            }

            if (submitField == null) {
                Matcher bm = BUTTON_PATTERN.matcher(inner);
                while (bm.find()) {
                    Map<String, String> attrs = parseAttrs(bm.group(1));
                    String type = lower(attrs.get("type"));
                    if (!type.isEmpty() && !"submit".equals(type)) continue;
                    if (notEmpty(attrs.get("name"))) {
                        submitField = attrs.get("name");
                        submitValue = notEmpty(attrs.get("value")) ? attrs.get("value") : stripTags(bm.group(2)).trim();
                        break;
                    }
                }
            }

            String action = value(formAttrs, "action");
            if (!notEmpty(action)) action = pageUrl;
            action = resolve(pageUrl, htmlDecode(action));
            if (!notEmpty(action) || !isEyesUrl(action)) continue;

            String method = lower(value(formAttrs, "method"));
            if (method.isEmpty()) method = "get";
            method = method.toUpperCase(Locale.ROOT);
            String enctype = htmlDecode(value(formAttrs, "enctype"));

            return new LoginForm(action, method, enctype,
                    user.get("name"), password.get("name"), hidden, submitField, submitValue);
        }
        return null;
    }

    private static Map<String, String> parseAttrs(String raw) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        if (raw == null) return out;
        Matcher m = ATTR_PATTERN.matcher(raw);
        while (m.find()) {
            String key = lower(m.group(1));
            String val = m.group(2);
            if (val == null) val = m.group(3);
            if (val == null) val = m.group(4);
            if (val == null) val = "";
            out.put(key, htmlDecode(val));
        }
        return out;
    }

    private static String encodeForm(Map<String, String> params) {
        StringBuilder out = new StringBuilder();
        for (Map.Entry<String, String> e : params.entrySet()) {
            if (!notEmpty(e.getKey())) continue;
            if (out.length() > 0) out.append('&');
            out.append(urlEncode(e.getKey())).append('=').append(urlEncode(e.getValue() == null ? "" : e.getValue()));
        }
        return out.toString();
    }

    private static String urlEncode(String value) {
        try {
            return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8.name());
        } catch (Throwable t) {
            return "";
        }
    }

    private static void absorbSetCookies(HttpURLConnection conn,
                                         String requestUrl,
                                         CookieJar jar,
                                         List<PendingCookie> pending) {
        try {
            Map<String, List<String>> headers = conn.getHeaderFields();
            if (headers == null) return;
            for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
                if (entry.getKey() == null || !"set-cookie".equalsIgnoreCase(entry.getKey())) continue;
                if (entry.getValue() == null) continue;
                for (String raw : entry.getValue()) {
                    if (!notEmpty(raw)) continue;
                    if (jar != null) jar.absorb(raw);
                    if (pending != null) pending.add(new PendingCookie(requestUrl, raw));
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static void commitCookies(List<PendingCookie> pending) {
        if (pending == null || pending.isEmpty()) return;
        try {
            CookieManager cm = CookieManager.getInstance();
            for (PendingCookie cookie : pending) {
                if (cookie != null && notEmpty(cookie.url) && notEmpty(cookie.setCookie)) {
                    cm.setCookie(cookie.url, cookie.setCookie);
                }
            }
            cm.flush();
        } catch (Throwable ignored) {
        }
    }

    private static String readLimited(InputStream in, int maxChars) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[8192];
            int n;
            while ((n = br.read(buf)) >= 0) {
                int remaining = maxChars - sb.length();
                if (remaining <= 0) break;
                sb.append(buf, 0, Math.min(n, remaining));
                if (sb.length() >= maxChars) break;
            }
        }
        return sb.toString();
    }

    private static String extractLoginHint(String detail) {
        if (detail == null) return null;
        String prefix = "LOGIN_REDIRECT|";
        if (detail.startsWith(prefix) && detail.length() > prefix.length()) {
            String value = detail.substring(prefix.length()).trim();
            return isEyesUrl(value) ? value : null;
        }
        return null;
    }

    private static boolean looksLikeLoginPage(String url, String body) {
        String u = lower(url);
        String b = lower(body);
        return u.contains("login") || u.contains("signin") || u.contains("sign-in")
                || (b.contains("password") && (b.contains("login") || b.contains("로그인")))
                || b.contains("비밀번호");
    }

    private static boolean isEyesUrl(String raw) {
        try {
            URL u = new URL(raw);
            if (!"https".equalsIgnoreCase(u.getProtocol())) return false;
            String host = lower(u.getHost());
            return "eyes.co.kr".equals(host) || host.endsWith(".eyes.co.kr");
        } catch (Throwable t) {
            return false;
        }
    }

    private static String resolve(String base, String location) {
        if (!notEmpty(location)) return null;
        try {
            return new URL(new URL(base), location).toString();
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean isRedirect(int code) {
        return code == 301 || code == 302 || code == 303 || code == 307 || code == 308;
    }

    private static boolean sameUrl(String a, String b) {
        if (a == null || b == null) return false;
        return a.equalsIgnoreCase(b);
    }

    private static boolean containsAny(String value, String... terms) {
        if (value == null) return false;
        for (String term : terms) if (value.contains(term)) return true;
        return false;
    }

    private static String stripTags(String value) {
        return value == null ? "" : value.replaceAll("(?is)<[^>]+>", " ");
    }

    private static String htmlDecode(String value) {
        if (value == null) return "";
        return value.replace("&amp;", "&")
                .replace("&quot;", "\"")
                .replace("&#39;", "'")
                .replace("&#x27;", "'")
                .replace("&lt;", "<")
                .replace("&gt;", ">");
    }

    private static String value(Map<String, String> attrs, String key) {
        if (attrs == null || key == null) return "";
        String value = attrs.get(key.toLowerCase(Locale.ROOT));
        return value == null ? "" : value;
    }

    private static String lower(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT);
    }

    private static boolean notEmpty(String value) {
        return value != null && !value.trim().isEmpty();
    }

    private static final class CookieJar {
        final LinkedHashMap<String, String> values = new LinkedHashMap<>();

        CookieJar(String header) {
            if (!notEmpty(header)) return;
            for (String part : header.split(";")) {
                String p = part.trim();
                int eq = p.indexOf('=');
                if (eq <= 0) continue;
                String name = p.substring(0, eq).trim();
                String value = p.substring(eq + 1).trim();
                if (!name.isEmpty()) values.put(name, value);
            }
        }

        void absorb(String setCookie) {
            if (!notEmpty(setCookie)) return;
            String first = setCookie.split(";", 2)[0].trim();
            int eq = first.indexOf('=');
            if (eq <= 0) return;
            String name = first.substring(0, eq).trim();
            String value = first.substring(eq + 1).trim();
            if (!name.isEmpty()) values.put(name, value);
        }

        String header() {
            StringBuilder out = new StringBuilder();
            for (Map.Entry<String, String> e : values.entrySet()) {
                if (out.length() > 0) out.append("; ");
                out.append(e.getKey()).append('=').append(e.getValue());
            }
            return out.toString();
        }
    }

    private static final class PendingCookie {
        final String url;
        final String setCookie;
        PendingCookie(String url, String setCookie) {
            this.url = url;
            this.setCookie = setCookie;
        }
    }

    private static final class HttpResponse {
        final String url;
        final int code;
        final String location;
        final String body;
        HttpResponse(String url, int code, String location, String body) {
            this.url = url;
            this.code = code;
            this.location = location;
            this.body = body == null ? "" : body;
        }
    }

    private static final class LoginPage {
        final String url;
        final String body;
        LoginPage(String url, String body) {
            this.url = url;
            this.body = body;
        }
    }

    private static final class LoginForm {
        final String action;
        final String method;
        final String enctype;
        final String userField;
        final String passwordField;
        final LinkedHashMap<String, String> hiddenFields;
        final String submitField;
        final String submitValue;

        LoginForm(String action, String method, String enctype,
                  String userField, String passwordField,
                  LinkedHashMap<String, String> hiddenFields,
                  String submitField, String submitValue) {
            this.action = action;
            this.method = method;
            this.enctype = enctype;
            this.userField = userField;
            this.passwordField = passwordField;
            this.hiddenFields = hiddenFields;
            this.submitField = submitField;
            this.submitValue = submitValue;
        }
    }

    private static final class HeaderPair {
        final String name;
        final String value;
        HeaderPair(String name, String value) {
            this.name = name;
            this.value = value;
        }
    }

    private static final class LoginResult {
        final UsageData data;
        final List<PendingCookie> pendingCookies;
        final String detail;

        private LoginResult(UsageData data, List<PendingCookie> pendingCookies, String detail) {
            this.data = data;
            this.pendingCookies = pendingCookies == null ? new ArrayList<>() : new ArrayList<>(pendingCookies);
            this.detail = detail;
        }

        static LoginResult success(UsageData data, List<PendingCookie> pending) {
            return new LoginResult(data, pending, "FAST_LOGIN_OK");
        }

        static LoginResult fail(String detail) {
            return new LoginResult(null, new ArrayList<>(), detail);
        }

        static LoginResult fail(String detail, List<PendingCookie> pending) {
            return new LoginResult(null, pending, detail);
        }
    }
}

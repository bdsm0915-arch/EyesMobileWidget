package com.example.eyesmobilewidget;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses the logged-in usage cards. v2.5 prefers a DOM-focused snapshot and rejects
 * recommendation/plan-card numbers that previously could be mistaken for live usage.
 */
public final class UsageParser {
    private UsageParser() {}

    private static final String DATA_CORE = "[0-9][0-9.,]*\\s*(?:TB|GB|MB|KB|G|M)";
    // Prefer the longest Korean duration so values such as "0분 35초" are kept as one token.
    private static final String VOICE_NUMBER = "[0-9][0-9.,]*";
    private static final String VOICE_CORE =
            "(?:" + VOICE_NUMBER + "\\s*시간\\s*(?:" + VOICE_NUMBER + "\\s*분\\s*)?(?:" + VOICE_NUMBER + "\\s*초)?"
            + "|" + VOICE_NUMBER + "\\s*분\\s*(?:" + VOICE_NUMBER + "\\s*초)?"
            + "|" + VOICE_NUMBER + "\\s*초"
            + "|" + VOICE_NUMBER + "\\s*(?:minute|min))";
    private static final String SMS_CORE = "[0-9][0-9.,]*\\s*(?:건|회|개)";

    private static final Pattern PERCENT = Pattern.compile("(\\d{1,3})\\s*%");
    private static final Pattern DATA_TOKEN = Pattern.compile("(" + DATA_CORE + ")", Pattern.CASE_INSENSITIVE);
    private static final Pattern VOICE_TOKEN = Pattern.compile("(" + VOICE_CORE + ")", Pattern.CASE_INSENSITIVE);
    private static final Pattern SMS_TOKEN = Pattern.compile("(" + SMS_CORE + ")", Pattern.CASE_INSENSITIVE);

    public static UsageData parse(String source) {
        if (source == null) return null;
        String normalized = normalize(source);
        if (normalized.length() < 20) return null;

        List<String> focused = extractFocusedBlocks(normalized);
        Part data = bestPart(focused, Kind.DATA);
        Part voice = bestPart(focused, Kind.VOICE);
        Part sms = bestPart(focused, Kind.SMS);
        // v7.6: supplementary-call usage is parsed independently so its fixed 300-minute
        // allowance can never leak into the normal voice/data parser.
        Part addonVoice = parseAddonVoice(normalized, focused);

        int found = countFound(data, voice, sms);
        if (found == 0) {
            // Legacy/plain-text fallback, but only when the page contains explicit usage context.
            String body = extractBody(normalized);
            if (!looksLikeUsageArea(body)) return null;
            List<String> single = new ArrayList<>();
            single.add(body);
            data = bestPart(single, Kind.DATA);
            voice = bestPart(single, Kind.VOICE);
            sms = bestPart(single, Kind.SMS);
            addonVoice = parseAddonVoice(normalized, single);
            found = countFound(data, voice, sms);
        }

        // A recommendation card can also mention data/voice/SMS allowances. A successful usage
        // read must contain at least two independently parsed usage categories.
        if (found < 2) return null;

        if (data == null) data = Part.empty();
        if (voice == null) voice = Part.empty();
        if (sms == null) sms = Part.empty();
        if (addonVoice == null) addonVoice = new Part("0초", "300분", 0, 100);

        return new UsageData(
                data.used, data.total, data.percent,
                voice.used, voice.total, voice.percent,
                sms.used, sms.total, sms.percent,
                addonVoice.used, "300분", addonVoice.percent,
                System.currentTimeMillis());
    }

    private static Part bestPart(List<String> blocks, Kind kind) {
        Part best = null;
        for (String block : blocks) {
            // v8.4: never let supplementary-call text participate in normal voice parsing.
            // EyesMobile can place the normal voice and supplementary-call cards inside the
            // same DOM container, so a generic "통화/사용량" scan could otherwise assign the
            // supplementary duration to voice as well.
            String candidate = kind == Kind.VOICE ? stripAddonVoiceSections(block) : block;
            Part p = findPart(candidate, kind);
            if (p != null && (best == null || p.confidence > best.confidence)) best = p;
        }
        return best;
    }

    private static Part findPart(String text, Kind kind) {
        String[] labels = labels(kind);
        Pattern tokenPattern = tokenPattern(kind);
        Part best = null;

        for (String label : labels) {
            int from = 0;
            while (from < text.length()) {
                int idx = indexOfIgnoreCase(text, label, from);
                if (idx < 0) break;
                if (kind == Kind.VOICE && overlapsAddonVoiceLabel(text, idx)) {
                    from = idx + label.length();
                    continue;
                }

                int start = idx;
                int end = Math.min(text.length(), idx + 520);
                int next = nextOtherCategory(text, kind, idx + label.length());
                if (kind == Kind.VOICE) {
                    int addon = nextAddonVoiceLabel(text, idx + label.length());
                    if (addon > idx && (next < 0 || addon < next)) next = addon;
                }
                if (next > idx && next < end) end = next;
                String window = text.substring(start, end);

                Part p = parseWindow(window, kind, tokenPattern);
                if (p != null && (best == null || p.confidence > best.confidence)) best = p;
                from = idx + label.length();
            }
        }
        return best;
    }

    private static Part parseWindow(String window, Kind kind, Pattern tokenPattern) {
        String lower = window.toLowerCase(Locale.ROOT);
        int bad = countMatches(lower, "요금제추천", "가입신청", "특별할인", "추천상품", "통신상품");
        int strongUsageSignals = countMatches(lower, "사용량", "잔여", "남은", "잔량", "소진", "제공량", "이용량");
        boolean basicProvided = lower.contains("기본제공") || lower.contains("무제한");
        int usageSignals = strongUsageSignals + (basicProvided ? 1 : 0);
        if (bad > 0 && strongUsageSignals == 0) return null;

        String core = core(kind);
        String used = findAssociated(window, core,
                "(?:실사용량|사용량(?!조회)|소진량|소진|이용량)");
        String remain = findAssociated(window, core,
                "(?:잔여량|잔여|남은량|남은|잔량)");
        String total = findAssociated(window, core,
                "(?:기본제공량|총제공량|제공량|전체량|전체|총량|총|기준|한도)");

        List<String> values = collectValues(window, tokenPattern);
        int confidence = usageSignals * 5 - bad * 15;
        if (used != null) confidence += 18;
        if (remain != null) confidence += 18;
        if (total != null) confidence += 14;

        // If the site gives remaining + total, derive actual used amount so the existing widget
        // can continue to display "잔여 = total - used" correctly.
        if (used == null && remain != null && total != null) {
            used = subtract(total, remain, kind);
            if (used != null) confidence += 10;
        }
        if (total == null && used != null && remain != null) {
            total = add(used, remain, kind);
            if (total != null) confidence += 8;
        }

        // Fallback only inside a block that has explicit usage wording. This is intentionally
        // stricter than v2.3's "first number / second number" rule.
        if (used == null && strongUsageSignals > 0 && !values.isEmpty()) {
            used = values.get(0);
            confidence += 4;
        }
        if (total == null && strongUsageSignals > 0 && values.size() >= 2) {
            for (String v : values) {
                if (used == null || !compact(v).equals(compact(used))) {
                    total = v;
                    confidence += 3;
                    break;
                }
            }
        }

        if (kind != Kind.DATA && total == null && (lower.contains("기본제공") || lower.contains("무제한"))) {
            total = "기본제공";
            confidence += 8;
        }

        if (used == null && total == null && remain == null) return null;
        if (used == null) used = "--";
        if (total == null) total = inferTotal(window);

        int percent = findPercent(window);
        if (percent < 0) percent = calculatePercent(used, total, kind);
        if (percent < 0 && kind == Kind.DATA && remain != null && !"--".equals(total)) {
            double r = numericToBase(remain, kind);
            double t = numericToBase(total, kind);
            if (r >= 0 && t > 0) percent = clampPercent((t - r) * 100d / t);
        }
        if (percent < 0) percent = 0;

        if (confidence < 4) return null;
        return new Part(compact(used), compact(total), percent, confidence);
    }

    private static String findAssociated(String window, String tokenCore, String keywordCore) {
        Pattern after = Pattern.compile(keywordCore + "[^0-9]{0,34}(" + tokenCore + ")",
                Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        Matcher a = after.matcher(window);
        if (a.find()) return compact(a.group(1));

        Pattern before = Pattern.compile("(" + tokenCore + ")[^\\n0-9]{0,28}" + keywordCore,
                Pattern.CASE_INSENSITIVE);
        Matcher b = before.matcher(window);
        if (b.find()) return compact(b.group(1));
        return null;
    }

    private static List<String> collectValues(String window, Pattern tokenPattern) {
        List<String> out = new ArrayList<>();
        Matcher m = tokenPattern.matcher(window);
        while (m.find() && out.size() < 8) {
            String value = compact(m.group(1));
            if (!out.contains(value)) out.add(value);
        }
        return out;
    }

    private static int findPercent(String window) {
        Matcher pm = PERCENT.matcher(window);
        if (pm.find()) {
            try { return Math.min(100, Integer.parseInt(pm.group(1))); } catch (Exception ignored) {}
        }
        return -1;
    }

    private static String inferTotal(String window) {
        String lower = window.toLowerCase(Locale.ROOT);
        if (lower.contains("기본제공") || lower.contains("무제한")) return "기본제공";
        return "--";
    }

    private static int calculatePercent(String used, String total, Kind kind) {
        double u = numericToBase(used, kind);
        double t = numericToBase(total, kind);
        if (u < 0 || t <= 0) return -1;
        return clampPercent(u * 100d / t);
    }

    private static int clampPercent(double p) {
        return (int) Math.round(Math.max(0d, Math.min(100d, p)));
    }

    private static String subtract(String total, String remaining, Kind kind) {
        double t = numericToBase(total, kind);
        double r = numericToBase(remaining, kind);
        if (t < 0 || r < 0 || r > t) return null;
        return formatBase(t - r, kind);
    }

    private static String add(String used, String remaining, Kind kind) {
        double u = numericToBase(used, kind);
        double r = numericToBase(remaining, kind);
        if (u < 0 || r < 0) return null;
        return formatBase(u + r, kind);
    }

    private static double numericToBase(String value, Kind kind) {
        if (value == null || value.contains("기본제공") || value.equals("--")) return -1;
        String v = value.replace(",", "").replace(" ", "").toUpperCase(Locale.ROOT);
        Matcher m = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)(TB|GB|MB|KB|G|M|시간|분|초|MINUTE|MIN|건|회|개)?").matcher(v);
        if (!m.find()) return -1;
        double n;
        try { n = Double.parseDouble(m.group(1)); } catch (Exception e) { return -1; }
        String unit = m.group(2) == null ? "" : m.group(2);
        if (kind == Kind.DATA) {
            if (unit.equals("TB")) n *= 1024d * 1024d;
            else if (unit.equals("GB") || unit.equals("G")) n *= 1024d;
            else if (unit.equals("KB")) n /= 1024d;
        } else if (kind == Kind.VOICE) {
            return voiceMinutes(value);
        }
        return n;
    }

    /** Returns the complete voice duration in minutes, including seconds. */
    private static double voiceMinutes(String value) {
        if (value == null) return -1;
        String v = value.replace(",", "").toUpperCase(Locale.ROOT);
        Matcher parts = Pattern.compile(
                "([0-9]+(?:\\.[0-9]+)?)\\s*(시간|분|초|MINUTE|MIN)",
                Pattern.CASE_INSENSITIVE).matcher(v);
        double minutes = 0d;
        boolean found = false;
        while (parts.find()) {
            double n;
            try { n = Double.parseDouble(parts.group(1)); } catch (Exception e) { continue; }
            String u = parts.group(2).toUpperCase(Locale.ROOT);
            if ("시간".equals(u)) minutes += n * 60d;
            else if ("초".equals(u)) minutes += n / 60d;
            else minutes += n;
            found = true;
        }
        if (found) return minutes;

        Matcher plain = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)").matcher(v);
        if (!plain.find()) return -1;
        try { return Double.parseDouble(plain.group(1)); } catch (Exception e) { return -1; }
    }

    private static String formatBase(double value, Kind kind) {
        if (kind == Kind.DATA) {
            if (value >= 1024d) return trim(value / 1024d, 2) + "GB";
            return trim(value, 1) + "MB";
        }
        if (kind == Kind.VOICE) return trim(value, 1) + "분";
        return trim(value, 0) + "건";
    }

    private static String trim(double n, int decimals) {
        String f;
        if (decimals <= 0) f = String.format(Locale.KOREA, "%.0f", n);
        else if (decimals == 1) f = String.format(Locale.KOREA, "%.1f", n);
        else f = String.format(Locale.KOREA, "%.2f", n);
        if (f.contains(".")) f = f.replaceAll("0+$", "").replaceAll("\\.$", "");
        return f;
    }

    private static List<String> extractFocusedBlocks(String text) {
        List<String> blocks = new ArrayList<>();
        Pattern marker = Pattern.compile("\\[\\[EYES_USAGE_BLOCK_\\d+]]");
        Matcher m = marker.matcher(text);
        List<Integer> starts = new ArrayList<>();
        while (m.find()) starts.add(m.end());
        for (int i = 0; i < starts.size(); i++) {
            int start = starts.get(i);
            int end = text.length();
            if (i + 1 < starts.size()) {
                int nextMarker = text.lastIndexOf("[[EYES_USAGE_BLOCK_", starts.get(i + 1));
                if (nextMarker > start) end = nextMarker;
            } else {
                int body = text.indexOf("[[EYES_BODY]]", start);
                if (body > start) end = body;
            }
            String block = text.substring(start, end).trim();
            if (!block.isEmpty()) blocks.add(block);
        }
        return blocks;
    }

    private static String extractBody(String text) {
        int idx = text.indexOf("[[EYES_BODY]]");
        return idx >= 0 ? text.substring(idx + "[[EYES_BODY]]".length()).trim() : text;
    }

    private static boolean looksLikeUsageArea(String text) {
        if (text == null) return false;
        String l = text.toLowerCase(Locale.ROOT);
        boolean explicit = l.contains("사용량조회") || l.contains("사용량 조회")
                || l.contains("데이터 사용량") || l.contains("통화 사용량")
                || l.contains("음성 사용량") || l.contains("문자 사용량");
        boolean category = (l.contains("데이터") && (l.contains("통화") || l.contains("음성")) && (l.contains("문자") || l.contains("sms")));
        return explicit && category;
    }

    private static boolean hasStrongUsageSignal(String text) {
        String l = text.toLowerCase(Locale.ROOT);
        return l.contains("데이터 사용량") || l.contains("사용량조회") || l.contains("사용량 조회")
                || (l.contains("잔여") && l.contains("데이터"));
    }

    private static int countFound(Part... parts) {
        int n = 0;
        for (Part p : parts) if (p != null) n++;
        return n;
    }

    private static int nextOtherCategory(String text, Kind current, int from) {
        int best = -1;
        for (Kind k : Kind.values()) {
            if (k == current) continue;
            for (String label : labels(k)) {
                int i = indexOfIgnoreCase(text, label, from);
                if (i >= 0 && (best < 0 || i < best)) best = i;
            }
        }
        return best;
    }

    private static String[] labels(Kind kind) {
        if (kind == Kind.DATA) return new String[]{"데이터 사용량", "데이터 잔여량", "데이터"};
        if (kind == Kind.VOICE) return new String[]{"음성 사용량", "통화 사용량", "음성", "통화"};
        return new String[]{"문자 사용량", "SMS 사용량", "문자", "SMS"};
    }

    private static Pattern tokenPattern(Kind kind) {
        if (kind == Kind.DATA) return DATA_TOKEN;
        if (kind == Kind.VOICE) return VOICE_TOKEN;
        return SMS_TOKEN;
    }

    private static String core(Kind kind) {
        if (kind == Kind.DATA) return DATA_CORE;
        if (kind == Kind.VOICE) return VOICE_CORE;
        return SMS_CORE;
    }


    /**
     * Parses only the supplementary-call card. The EyesMobile plan text may contain
     * "부가통화 300분" even when nothing has been used. That 300 is an allowance,
     * never a used value. Missing usage therefore means exactly 0 seconds.
     */
    private static Part parseAddonVoice(String normalized, List<String> preferredBlocks) {
        Part best = null;
        if (preferredBlocks != null) {
            for (String block : preferredBlocks) {
                Part p = findAddonVoicePart(block, true);
                if (p != null && (best == null || p.confidence > best.confidence)) best = p;
            }
        }
        Part whole = findAddonVoicePart(extractBody(normalized), false);
        if (whole != null && (best == null || whole.confidence > best.confidence)) best = whole;
        if (best == null) return new Part("0초", "300분", 0, 100);
        return best;
    }

    private static Part findAddonVoicePart(String text, boolean focusedBlock) {
        if (text == null || text.isEmpty()) return null;
        Part best = null;
        for (String label : ADDON_VOICE_LABELS) {
            int from = 0;
            while (from < text.length()) {
                int idx = indexOfIgnoreCase(text, label, from);
                if (idx < 0) break;

                int end = Math.min(text.length(), idx + 260);
                int next = nextBaseCategoryLabel(text, idx + label.length());
                if (next > idx && next < end) end = next;
                String window = text.substring(idx, end);
                String lower = window.toLowerCase(Locale.ROOT);
                List<String> values = collectValues(window, VOICE_TOKEN);

                String used = null;
                int confidence = 25;

                // Strongest form: an explicit usage keyword immediately owns a duration.
                Matcher explicit = Pattern.compile(
                        "(?:실사용량|사용량(?!조회)|소진량|소진|이용량)[^0-9]{0,20}(" + VOICE_CORE + ")",
                        Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(window);
                if (explicit.find()) {
                    String candidateUsed = compact(explicit.group(1));
                    double mins = voiceMinutes(candidateUsed);
                    // 300 minutes is this plan's allowance, never the consumed amount.
                    if (!(mins >= 299.99d && mins <= 300.01d)) {
                        used = candidateUsed;
                        confidence = 95;
                    }
                }

                // Some cards render the number first and the word '사용량' after it.
                if (used == null) {
                    Matcher beforeKeyword = Pattern.compile(
                            "(" + VOICE_CORE + ")[^0-9]{0,18}(?:실사용량|사용량(?!조회)|소진량|소진|이용량)",
                            Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(window);
                    if (beforeKeyword.find()) {
                        String candidateUsed = compact(beforeKeyword.group(1));
                        double mins = voiceMinutes(candidateUsed);
                        if (!(mins >= 299.99d && mins <= 300.01d)) {
                            used = candidateUsed;
                            confidence = 90;
                        }
                    }
                }

                // A bare "부가통화 300분" is the allowance, not usage. In a focused
                // usage card, accept the first other duration as actual use.
                if (used == null) {
                    boolean usageContext = lower.contains("사용량") || lower.contains("소진")
                            || lower.contains("이용량") || lower.contains("잔여");
                    for (String v : values) {
                        double mins = voiceMinutes(v);
                        if (mins >= 299.99d && mins <= 300.01d) continue;
                        if (usageContext || focusedBlock) {
                            used = v;
                            confidence = usageContext ? 70 : 50;
                            break;
                        }
                    }
                }

                if (used == null || used.equals("--")) used = "0초";
                int percent = percentOf300Minutes(used);
                Part candidate = new Part(compact(used), "300분", percent, confidence);
                if (best == null || candidate.confidence > best.confidence) best = candidate;
                from = idx + label.length();
            }
        }
        return best;
    }

    private static int nextBaseCategoryLabel(String text, int from) {
        int best = -1;
        String[] labels = new String[]{
                "데이터 사용량", "데이터 잔여량", "데이터",
                "음성 사용량", "통화 사용량", "일반통화", "국내통화", "음성",
                "문자 사용량", "SMS 사용량", "문자", "SMS"
        };
        for (String label : labels) {
            int i = indexOfIgnoreCase(text, label, from);
            if (i >= 0 && (best < 0 || i < best)) best = i;
        }
        return best;
    }

    private static int percentOf300Minutes(String used) {
        double minutes = voiceMinutes(used);
        if (minutes <= 0d) return 0;
        double raw = minutes * 100d / 300d;
        int p = (int) Math.round(raw);
        if (p == 0) p = 1; // non-zero use should have a visible, but minimal, arc
        return Math.max(0, Math.min(100, p));
    }

    private static final String[] ADDON_VOICE_LABELS = new String[]{
            "음성/영상/부가통화", "음성·영상·부가통화",
            "영상통화/부가통화", "영상/부가통화", "영상통화 및 부가통화",
            "영상통화·부가통화", "영상통화 + 부가통화",
            "부가통화 사용량", "부가 통화 사용량", "부가통화", "부가 통화"
    };

    private static int nextAddonVoiceLabel(String text, int from) {
        int best = -1;
        for (String label : ADDON_VOICE_LABELS) {
            int i = indexOfIgnoreCase(text, label, from);
            if (i >= 0 && (best < 0 || i < best)) best = i;
        }
        return best;
    }

    private static int addonLabelLengthAt(String text, int idx) {
        if (text == null || idx < 0 || idx >= text.length()) return 0;
        for (String label : ADDON_VOICE_LABELS) {
            if (idx + label.length() <= text.length()
                    && text.regionMatches(true, idx, label, 0, label.length())) {
                return label.length();
            }
        }
        return 0;
    }

    /**
     * Removes only supplementary-call card sections before the normal voice parser runs.
     * This is deliberately done before looking for generic words such as "통화" or "사용량".
     */
    private static String stripAddonVoiceSections(String text) {
        if (text == null || text.isEmpty()) return text;
        StringBuilder out = new StringBuilder(text);
        int from = 0;
        while (from < text.length()) {
            int start = nextAddonVoiceLabel(text, from);
            if (start < 0) break;
            int labelLength = Math.max(1, addonLabelLengthAt(text, start));
            int end = nextBaseCategoryLabel(text, start + labelLength);
            if (end <= start) end = text.length();

            for (int i = start; i < end; i++) {
                char ch = out.charAt(i);
                // Preserve line boundaries so proximity-based parsing remains stable.
                if (ch != '\n' && ch != '\r') out.setCharAt(i, ' ');
            }
            from = Math.max(start + labelLength, end);
        }
        return out.toString();
    }

    private static boolean overlapsAddonVoiceLabel(String text, int idx) {
        int start = Math.max(0, idx - 14);
        String prefix = text.substring(start, idx).replaceAll("\\s+", "");
        return prefix.endsWith("부가") || prefix.endsWith("영상") || prefix.endsWith("영상/부가")
                || prefix.endsWith("영상통화/부가") || prefix.endsWith("영상통화및부가");
    }

    private static int countMatches(String text, String... words) {
        int n = 0;
        for (String w : words) if (text.contains(w.toLowerCase(Locale.ROOT))) n++;
        return n;
    }

    private static String normalize(String s) {
        return s.replace('\u00A0', ' ')
                .replaceAll("[\\t\\r]+", " ")
                .replaceAll(" *\\n *", "\\n")
                .replaceAll("\\n{3,}", "\\n\\n")
                .replaceAll(" {2,}", " ")
                .trim();
    }

    private static String compact(String s) {
        return s == null ? "--" : s.replaceAll("\\s+", "");
    }

    private static int indexOfIgnoreCase(String text, String target, int from) {
        return text.toLowerCase(Locale.ROOT).indexOf(target.toLowerCase(Locale.ROOT), from);
    }

    private enum Kind { DATA, VOICE, SMS }

    private static final class Part {
        final String used;
        final String total;
        final int percent;
        final int confidence;

        Part(String used, String total, int percent, int confidence) {
            this.used = used;
            this.total = total;
            this.percent = percent;
            this.confidence = confidence;
        }

        static Part empty() { return new Part("--", "--", 0, 0); }
    }
}

package com.example.eyesmobilewidget;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses the logged-in usage cards. v2.5 prefers a DOM-focused snapshot and rejects
 * recommendation/plan-card numbers that previously could be mistaken for live usage.
 */
public final class UsageParser {
    private UsageParser() {}

    private static final String DATA_CORE = "[0-9][0-9.,]*\\s*(?:TB|GB|MB|KB|G|M)";
    // Prefer the longest Korean duration so values such as "0분 35초" are kept as one token.
    private static final String VOICE_NUMBER = "[0-9][0-9.,]*";
    private static final String VOICE_CORE =
            "(?:" + VOICE_NUMBER + "\\s*시간\\s*(?:" + VOICE_NUMBER + "\\s*분\\s*)?(?:" + VOICE_NUMBER + "\\s*초)?"
            + "|" + VOICE_NUMBER + "\\s*분\\s*(?:" + VOICE_NUMBER + "\\s*초)?"
            + "|" + VOICE_NUMBER + "\\s*초"
            + "|" + VOICE_NUMBER + "\\s*(?:minute|min))";
    private static final String SMS_CORE = "[0-9][0-9.,]*\\s*(?:건|회|개)";

    private static final Pattern PERCENT = Pattern.compile("(\\d{1,3})\\s*%");
    private static final Pattern DATA_TOKEN = Pattern.compile("(" + DATA_CORE + ")", Pattern.CASE_INSENSITIVE);
    private static final Pattern VOICE_TOKEN = Pattern.compile("(" + VOICE_CORE + ")", Pattern.CASE_INSENSITIVE);
    private static final Pattern SMS_TOKEN = Pattern.compile("(" + SMS_CORE + ")", Pattern.CASE_INSENSITIVE);

    public static UsageData parse(String source) {
        if (source == null) return null;
        String normalized = normalize(source);
        if (normalized.length() < 20) return null;

        List<String> focused = extractFocusedBlocks(normalized);
        Part data = bestPart(focused, Kind.DATA);
        Part voice = bestPart(focused, Kind.VOICE);
        Part sms = bestPart(focused, Kind.SMS);
        Part addonVoice = bestPart(focused, Kind.ADDON_VOICE);

        int found = countFound(data, voice, sms);
        if (found == 0) {
            // Legacy/plain-text fallback, but only when the page contains explicit usage context.
            String body = extractBody(normalized);
            if (!looksLikeUsageArea(body)) return null;
            List<String> single = new ArrayList<>();
            single.add(body);
            data = bestPart(single, Kind.DATA);
            voice = bestPart(single, Kind.VOICE);
            sms = bestPart(single, Kind.SMS);
            addonVoice = bestPart(single, Kind.ADDON_VOICE);
            found = countFound(data, voice, sms);
        }

        // A recommendation card can also mention data/voice/SMS allowances. A successful usage
        // read must contain at least two independently parsed usage categories.
        if (found < 2) return null;

        if (data == null) data = Part.empty();
        if (voice == null) voice = Part.empty();
        if (sms == null) sms = Part.empty();
        if (addonVoice == null) addonVoice = Part.empty();
        addonVoice = repairAddonVoiceTotal(normalized, addonVoice);

        return new UsageData(
                data.used, data.total, data.percent,
                voice.used, voice.total, voice.percent,
                sms.used, sms.total, sms.percent,
                addonVoice.used, addonVoice.total, addonVoice.percent,
                System.currentTimeMillis());
    }

    private static Part bestPart(List<String> blocks, Kind kind) {
        Part best = null;
        for (String block : blocks) {
            Part p = findPart(block, kind);
            if (p != null && (best == null || p.confidence > best.confidence)) best = p;
        }
        return best;
    }

    private static Part findPart(String text, Kind kind) {
        String[] labels = labels(kind);
        Pattern tokenPattern = tokenPattern(kind);
        Part best = null;

        for (String label : labels) {
            int from = 0;
            while (from < text.length()) {
                int idx = indexOfIgnoreCase(text, label, from);
                if (idx < 0) break;
                if (kind == Kind.VOICE && overlapsAddonVoiceLabel(text, idx)) {
                    from = idx + label.length();
                    continue;
                }

                int start = idx;
                int end = Math.min(text.length(), idx + 520);
                int next = nextOtherCategory(text, kind, idx + label.length());
                if (next > idx && next < end) end = next;
                String window = text.substring(start, end);

                Part p = parseWindow(window, kind, tokenPattern);
                if (p != null && (best == null || p.confidence > best.confidence)) best = p;
                from = idx + label.length();
            }
        }
        return best;
    }

    private static Part parseWindow(String window, Kind kind, Pattern tokenPattern) {
        String lower = window.toLowerCase(Locale.ROOT);
        int bad = countMatches(lower, "요금제추천", "가입신청", "특별할인", "추천상품", "통신상품");
        int strongUsageSignals = countMatches(lower, "사용량", "잔여", "남은", "잔량", "소진", "제공량", "이용량");
        boolean basicProvided = lower.contains("기본제공") || lower.contains("기본 제공") || lower.contains("무제한");
        int usageSignals = strongUsageSignals + (basicProvided ? 1 : 0);
        if (bad > 0 && strongUsageSignals == 0) return null;

        String core = core(kind);
        String used = findAssociated(window, core,
                "(?:실사용량|사용량(?!조회)|소진량|소진|이용량)");
        String remain = findAssociated(window, core,
                "(?:잔여량|잔여|남은량|남은|잔량)");
        String total = findAssociated(window, core,
                "(?:기본\\s*제공(?:량)?|총\\s*제공(?:량)?|제공(?:량)?|전체량|전체|총량|총|기준|한도)");

        List<String> values = collectValues(window, tokenPattern);
        int confidence = usageSignals * 5 - bad * 15;
        if (kind == Kind.ADDON_VOICE && (lower.contains("부가통화") || lower.contains("부가 통화"))) {
            confidence += 12;
        }
        if (used != null) confidence += 18;
        if (remain != null) confidence += 18;
        if (total != null) confidence += 14;

        // v7.2: EyesMobile may render supplementary-call cards as "15 / 300분" or
        // expose the gauge values only through progress/ARIA attributes. Recover both values
        // before falling back to "총량 확인 필요".
        if (kind == Kind.ADDON_VOICE) {
            String[] pair = findAddonVoicePair(window);
            if (pair != null) {
                if (used == null && pair[0] != null) { used = pair[0]; confidence += 12; }
                if (total == null && pair[1] != null) { total = pair[1]; confidence += 16; }
            }
            String[] metric = findAddonMetric(window);
            if (metric != null) {
                if (used == null && metric[0] != null) { used = metric[0]; confidence += 10; }
                if (total == null && metric[1] != null) { total = metric[1]; confidence += 14; }
            }
        }

        // If the site gives remaining + total, derive actual used amount so the existing widget
        // can continue to display "잔여 = total - used" correctly.
        if (used == null && remain != null && total != null) {
            used = subtract(total, remain, kind);
            if (used != null) confidence += 10;
        }
        if (total == null && used != null && remain != null) {
            total = add(used, remain, kind);
            if (total != null) confidence += 8;
        }

        // Fallback only inside a block that has explicit usage wording. This is intentionally
        // stricter than v2.3's "first number / second number" rule.
        if (used == null && (strongUsageSignals > 0 || kind == Kind.ADDON_VOICE) && !values.isEmpty()) {
            used = values.get(0);
            confidence += kind == Kind.ADDON_VOICE ? 8 : 4;
        }
        if (total == null && (strongUsageSignals > 0 || kind == Kind.ADDON_VOICE) && values.size() >= 2) {
            for (String v : values) {
                if (used == null || !compact(v).equals(compact(used))) {
                    total = v;
                    confidence += 3;
                    break;
                }
            }
        }

        if (kind != Kind.DATA && total == null && (lower.contains("기본제공") || lower.contains("기본 제공") || lower.contains("무제한"))) {
            total = "기본제공";
            confidence += 8;
        }

        if (used == null && total == null && remain == null) return null;
        if (used == null) used = "--";
        if (total == null) total = inferTotal(window);

        int percent = findPercent(window);
        if (kind == Kind.ADDON_VOICE && (total == null || "--".equals(total))
                && percent > 0 && percent <= 100 && used != null && !"--".equals(used)) {
            double u = numericToBase(used, kind);
            if (u > 0d) {
                double inferred = u * 100d / percent;
                // Round tiny floating point noise while preserving non-integer minute plans.
                if (inferred >= u && inferred < 100000d) {
                    total = formatBase(inferred, kind);
                    confidence += 8;
                }
            }
        }
        if (percent < 0) percent = calculatePercent(used, total, kind);
        if (percent < 0 && kind == Kind.DATA && remain != null && !"--".equals(total)) {
            double r = numericToBase(remain, kind);
            double t = numericToBase(total, kind);
            if (r >= 0 && t > 0) percent = clampPercent((t - r) * 100d / t);
        }
        if (percent < 0) percent = 0;

        if (confidence < 4) return null;
        return new Part(compact(used), compact(total), percent, confidence);
    }

    /**
     * v7.3 second-pass recovery. EyesMobile can put the supplementary-call allowance in a
     * separate tariff/benefit area instead of the live usage card. Search the full captured
     * document for a numeric allowance near an addon-call label, while rejecting live-used and
     * remaining values. This is intentionally only used when the normal card did not expose a
     * total, so it cannot override a stronger direct parse.
     */
    private static Part repairAddonVoiceTotal(String fullText, Part addon) {
        if (addon == null) return Part.empty();
        if (addon.total != null && !"--".equals(addon.total)) return addon;
        if (fullText == null || fullText.isEmpty()) return addon;

        String total = findGlobalAddonAllowance(fullText, addon.used);
        if (total == null) return addon;

        int percent = addon.percent;
        int calculated = calculatePercent(addon.used, total, Kind.ADDON_VOICE);
        if (calculated >= 0) percent = calculated;
        return new Part(addon.used, compact(total), percent, addon.confidence + 18);
    }

    private static String findGlobalAddonAllowance(String text, String usedValue) {
        double used = numericToBase(usedValue, Kind.ADDON_VOICE);
        String[] addonLabels = labels(Kind.ADDON_VOICE);
        String best = null;
        int bestScore = Integer.MIN_VALUE;
        double bestMinutes = -1d;

        for (String label : addonLabels) {
            int from = 0;
            while (from < text.length()) {
                int idx = indexOfIgnoreCase(text, label, from);
                if (idx < 0) break;

                // Keep the search inside this addon-call row/card. Do not let a neighbouring
                // voice/SMS card's "기본제공" text turn the live addon usage into a fake total.
                int end = Math.min(text.length(), idx + 420);
                int nextCategory = nextOtherCategory(text, Kind.ADDON_VOICE, idx + label.length());
                if (nextCategory > idx && nextCategory < end) end = nextCategory;
                int marker = text.indexOf("[[EYES_", idx + label.length());
                if (marker > idx && marker < end) end = marker;
                String segment = text.substring(idx, end);
                String segLower = segment.toLowerCase(Locale.ROOT);
                boolean planContext = containsAnyText(segLower,
                        "기본제공", "기본 제공", "총 제공", "총제공", "제공량", "월 제공", "월제공",
                        "전체", "총량", "한도", "요금제", "혜택", "플랜");

                Matcher vm = VOICE_TOKEN.matcher(segment);
                while (vm.find()) {
                    String candidate = compact(vm.group(1));
                    double minutes = numericToBase(candidate, Kind.ADDON_VOICE);
                    if (minutes <= 0d || minutes > 100000d) continue;
                    if (used >= 0d && minutes + 0.0001d < used) continue;

                    int ca = Math.max(0, vm.start() - 48);
                    int cb = Math.min(segment.length(), vm.end() + 48);
                    String ctx = segment.substring(ca, cb).toLowerCase(Locale.ROOT);
                    boolean explicitTotal = containsAnyText(ctx,
                            "기본제공", "기본 제공", "총 제공", "총제공", "제공량", "월 제공", "월제공",
                            "전체", "총량", "한도");
                    boolean liveCounter = containsAnyText(ctx,
                            "사용량", "실사용", "소진", "잔여", "남은", "잔량", "이용량");

                    // The exact known used value is never accepted as a total unless the source
                    // explicitly labels it as an allowance.
                    if (used >= 0d && Math.abs(minutes - used) < 0.0001d && !explicitTotal) continue;
                    if (liveCounter && !explicitTotal) continue;

                    int score = 0;
                    if (explicitTotal) score += 90;
                    if (planContext) score += 35;
                    int distance = vm.start();
                    score += Math.max(0, 24 - Math.min(24, distance / 8));
                    if (used >= 0d && minutes > used) score += 8;

                    if (score > bestScore || (score == bestScore && minutes > bestMinutes)) {
                        bestScore = score;
                        bestMinutes = minutes;
                        best = candidate;
                    }
                }
                from = idx + Math.max(1, label.length());
            }
        }
        return bestScore >= 35 ? best : null;
    }

    private static boolean containsAnyText(String text, String... needles) {
        if (text == null) return false;
        String lower = text.toLowerCase(Locale.ROOT);
        for (String n : needles) if (lower.contains(n.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private static String[] findAddonVoicePair(String window) {
        // Remaining/allowance presentation must be checked before the generic slash form,
        // otherwise "잔여 285분 / 제공 300분" could be mistaken for 285 minutes used.
        Pattern remTotal = Pattern.compile(
                "(?:잔여량?|남은량?|잔량)\\s*[:：]?\\s*(" + VOICE_CORE + ")"
                        + "[\\s/／|·,-]{0,18}(?:총|전체|기본\\s*제공(?:량)?|제공(?:량)?|한도)\\s*[:：]?\\s*(" + VOICE_CORE + ")",
                Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        Matcher m = remTotal.matcher(window);
        if (m.find()) {
            String remain = compact(m.group(1));
            String total = compact(m.group(2));
            String used = subtract(total, remain, Kind.ADDON_VOICE);
            return new String[]{used, total};
        }

        // Common card text: "사용 15 / 300분", "15분/300분", or "15 / 300 분".
        Pattern ratio = Pattern.compile(
                "(?<!잔여)(?<!남은)(?<!잔량)(?:사용량?|이용량|소진량)?\\s*([0-9][0-9.,]*(?:\\s*(?:시간|분|초|min(?:ute)?))?(?:\\s*[0-9][0-9.,]*\\s*(?:분|초))?)"
                        + "\\s*(?:/|／|중|of)\\s*(?:총|전체|기본\\s*제공(?:량)?|제공(?:량)?)?\\s*"
                        + "(" + VOICE_CORE + ")",
                Pattern.CASE_INSENSITIVE);
        Matcher r = ratio.matcher(window);
        if (r.find()) {
            String total = compact(r.group(2));
            String used = compact(r.group(1));
            if (!hasVoiceUnit(used)) used = used + "분";
            return new String[]{used, total};
        }
        return null;
    }

    private static String[] findAddonMetric(String window) {
        // UsageDomSnapshot appends semantic progress values when the visual gauge keeps the
        // allowance outside innerText. Supplementary-call metrics are minute based.
        Pattern p = Pattern.compile(
                "\\[\\[EYES_METRIC]]\\s*context=[^\\n]{0,320}(?:부가\\s*통화|영상\\s*통화|영상/부가)[^\\n]{0,320}\\s+value\\s*=\\s*([0-9][0-9.,]*)\\s+max\\s*=\\s*([0-9][0-9.,]*)",
                Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(window);
        if (!m.find()) return null;
        double now;
        double max;
        try {
            now = Double.parseDouble(m.group(1).replace(",", ""));
            max = Double.parseDouble(m.group(2).replace(",", ""));
        } catch (Exception e) {
            return null;
        }
        if (now < 0d || max <= 0d || now > max * 2d || max > 100000d) return null;
        return new String[]{formatBase(now, Kind.ADDON_VOICE), formatBase(max, Kind.ADDON_VOICE)};
    }

    private static boolean hasVoiceUnit(String value) {
        if (value == null) return false;
        String v = value.toLowerCase(Locale.ROOT);
        return v.contains("시간") || v.contains("분") || v.contains("초") || v.contains("min");
    }

    private static String findAssociated(String window, String tokenCore, String keywordCore) {
        Pattern after = Pattern.compile(keywordCore + "[^0-9]{0,34}(" + tokenCore + ")",
                Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        Matcher a = after.matcher(window);
        if (a.find()) return compact(a.group(1));

        Pattern before = Pattern.compile("(" + tokenCore + ")[^\\n0-9]{0,28}" + keywordCore,
                Pattern.CASE_INSENSITIVE);
        Matcher b = before.matcher(window);
        if (b.find()) return compact(b.group(1));
        return null;
    }

    private static List<String> collectValues(String window, Pattern tokenPattern) {
        List<String> out = new ArrayList<>();
        Matcher m = tokenPattern.matcher(window);
        while (m.find() && out.size() < 8) {
            String value = compact(m.group(1));
            if (!out.contains(value)) out.add(value);
        }
        return out;
    }

    private static int findPercent(String window) {
        Matcher pm = PERCENT.matcher(window);
        if (pm.find()) {
            try { return Math.min(100, Integer.parseInt(pm.group(1))); } catch (Exception ignored) {}
        }
        return -1;
    }

    private static String inferTotal(String window) {
        String lower = window.toLowerCase(Locale.ROOT);
        if (lower.contains("기본제공") || lower.contains("기본 제공") || lower.contains("무제한")) return "기본제공";
        return "--";
    }

    private static int calculatePercent(String used, String total, Kind kind) {
        double u = numericToBase(used, kind);
        double t = numericToBase(total, kind);
        if (u < 0 || t <= 0) return -1;
        return clampPercent(u * 100d / t);
    }

    private static int clampPercent(double p) {
        return (int) Math.round(Math.max(0d, Math.min(100d, p)));
    }

    private static String subtract(String total, String remaining, Kind kind) {
        double t = numericToBase(total, kind);
        double r = numericToBase(remaining, kind);
        if (t < 0 || r < 0 || r > t) return null;
        return formatBase(t - r, kind);
    }

    private static String add(String used, String remaining, Kind kind) {
        double u = numericToBase(used, kind);
        double r = numericToBase(remaining, kind);
        if (u < 0 || r < 0) return null;
        return formatBase(u + r, kind);
    }

    private static double numericToBase(String value, Kind kind) {
        if (value == null || value.contains("기본제공") || value.equals("--")) return -1;
        String v = value.replace(",", "").replace(" ", "").toUpperCase(Locale.ROOT);
        Matcher m = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)(TB|GB|MB|KB|G|M|시간|분|초|MINUTE|MIN|건|회|개)?").matcher(v);
        if (!m.find()) return -1;
        double n;
        try { n = Double.parseDouble(m.group(1)); } catch (Exception e) { return -1; }
        String unit = m.group(2) == null ? "" : m.group(2);
        if (kind == Kind.DATA) {
            if (unit.equals("TB")) n *= 1024d * 1024d;
            else if (unit.equals("GB") || unit.equals("G")) n *= 1024d;
            else if (unit.equals("KB")) n /= 1024d;
        } else if (kind == Kind.VOICE || kind == Kind.ADDON_VOICE) {
            return voiceMinutes(value);
        }
        return n;
    }

    /** Returns the complete voice duration in minutes, including seconds. */
    private static double voiceMinutes(String value) {
        if (value == null) return -1;
        String v = value.replace(",", "").toUpperCase(Locale.ROOT);
        Matcher parts = Pattern.compile(
                "([0-9]+(?:\\.[0-9]+)?)\\s*(시간|분|초|MINUTE|MIN)",
                Pattern.CASE_INSENSITIVE).matcher(v);
        double minutes = 0d;
        boolean found = false;
        while (parts.find()) {
            double n;
            try { n = Double.parseDouble(parts.group(1)); } catch (Exception e) { continue; }
            String u = parts.group(2).toUpperCase(Locale.ROOT);
            if ("시간".equals(u)) minutes += n * 60d;
            else if ("초".equals(u)) minutes += n / 60d;
            else minutes += n;
            found = true;
        }
        if (found) return minutes;

        Matcher plain = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)").matcher(v);
        if (!plain.find()) return -1;
        try { return Double.parseDouble(plain.group(1)); } catch (Exception e) { return -1; }
    }

    private static String formatBase(double value, Kind kind) {
        if (kind == Kind.DATA) {
            if (value >= 1024d) return trim(value / 1024d, 2) + "GB";
            return trim(value, 1) + "MB";
        }
        if (kind == Kind.VOICE || kind == Kind.ADDON_VOICE) return trim(value, 1) + "분";
        return trim(value, 0) + "건";
    }

    private static String trim(double n, int decimals) {
        String f;
        if (decimals <= 0) f = String.format(Locale.KOREA, "%.0f", n);
        else if (decimals == 1) f = String.format(Locale.KOREA, "%.1f", n);
        else f = String.format(Locale.KOREA, "%.2f", n);
        if (f.contains(".")) f = f.replaceAll("0+$", "").replaceAll("\\.$", "");
        return f;
    }

    private static List<String> extractFocusedBlocks(String text) {
        List<String> blocks = new ArrayList<>();
        Pattern marker = Pattern.compile("\\[\\[EYES_USAGE_BLOCK_\\d+]]");
        Matcher m = marker.matcher(text);
        List<Integer> starts = new ArrayList<>();
        while (m.find()) starts.add(m.end());
        for (int i = 0; i < starts.size(); i++) {
            int start = starts.get(i);
            int end = text.length();
            if (i + 1 < starts.size()) {
                int nextMarker = text.lastIndexOf("[[EYES_USAGE_BLOCK_", starts.get(i + 1));
                if (nextMarker > start) end = nextMarker;
            } else {
                int body = text.indexOf("[[EYES_BODY]]", start);
                int addonHint = text.indexOf("[[EYES_ADDON_HINT]]", start);
                if (body > start) end = body;
                if (addonHint > start && addonHint < end) end = addonHint;
            }
            String block = text.substring(start, end).trim();
            if (!block.isEmpty()) blocks.add(block);
        }
        return blocks;
    }

    private static String extractBody(String text) {
        int idx = text.indexOf("[[EYES_BODY]]");
        return idx >= 0 ? text.substring(idx + "[[EYES_BODY]]".length()).trim() : text;
    }

    private static boolean looksLikeUsageArea(String text) {
        if (text == null) return false;
        String l = text.toLowerCase(Locale.ROOT);
        boolean explicit = l.contains("사용량조회") || l.contains("사용량 조회")
                || l.contains("데이터 사용량") || l.contains("통화 사용량")
                || l.contains("음성 사용량") || l.contains("문자 사용량");
        boolean category = (l.contains("데이터") && (l.contains("통화") || l.contains("음성")) && (l.contains("문자") || l.contains("sms")));
        return explicit && category;
    }

    private static boolean hasStrongUsageSignal(String text) {
        String l = text.toLowerCase(Locale.ROOT);
        return l.contains("데이터 사용량") || l.contains("사용량조회") || l.contains("사용량 조회")
                || (l.contains("잔여") && l.contains("데이터"));
    }

    private static int countFound(Part... parts) {
        int n = 0;
        for (Part p : parts) if (p != null) n++;
        return n;
    }

    private static int nextOtherCategory(String text, Kind current, int from) {
        int best = -1;
        for (Kind k : Kind.values()) {
            if (k == current) continue;
            for (String label : labels(k)) {
                int searchFrom = from;
                while (searchFrom < text.length()) {
                    int i = indexOfIgnoreCase(text, label, searchFrom);
                    if (i < 0) break;
                    // "통화" inside "부가통화" is not a transition to the normal voice card.
                    if (k == Kind.VOICE && overlapsAddonVoiceLabel(text, i)) {
                        searchFrom = i + label.length();
                        continue;
                    }
                    if (best < 0 || i < best) best = i;
                    break;
                }
            }
        }
        return best;
    }

    private static String[] labels(Kind kind) {
        if (kind == Kind.DATA) return new String[]{"데이터 사용량", "데이터 잔여량", "데이터"};
        if (kind == Kind.VOICE) return new String[]{"음성 사용량", "통화 사용량", "일반통화", "국내통화", "음성", "통화"};
        if (kind == Kind.ADDON_VOICE) return new String[]{
                "영상통화/부가통화", "영상/부가통화", "영상통화 및 부가통화",
                "부가통화 사용량", "부가 통화 사용량", "부가통화", "부가 통화"
        };
        return new String[]{"문자 사용량", "SMS 사용량", "문자", "SMS"};
    }

    private static Pattern tokenPattern(Kind kind) {
        if (kind == Kind.DATA) return DATA_TOKEN;
        if (kind == Kind.VOICE || kind == Kind.ADDON_VOICE) return VOICE_TOKEN;
        return SMS_TOKEN;
    }

    private static String core(Kind kind) {
        if (kind == Kind.DATA) return DATA_CORE;
        if (kind == Kind.VOICE || kind == Kind.ADDON_VOICE) return VOICE_CORE;
        return SMS_CORE;
    }

    private static boolean overlapsAddonVoiceLabel(String text, int idx) {
        int start = Math.max(0, idx - 10);
        String prefix = text.substring(start, idx).replaceAll("\\s+", "");
        return prefix.endsWith("부가") || prefix.endsWith("영상") || prefix.endsWith("영상/부가")
                || prefix.endsWith("영상통화/부가") || prefix.endsWith("영상통화및부가");
    }

    private static int countMatches(String text, String... words) {
        int n = 0;
        for (String w : words) if (text.contains(w.toLowerCase(Locale.ROOT))) n++;
        return n;
    }

    private static String normalize(String s) {
        return s.replace('\u00A0', ' ')
                .replaceAll("[\\t\\r]+", " ")
                .replaceAll(" *\\n *", "\\n")
                .replaceAll("\\n{3,}", "\\n\\n")
                .replaceAll(" {2,}", " ")
                .trim();
    }

    private static String compact(String s) {
        return s == null ? "--" : s.replaceAll("\\s+", "");
    }

    private static int indexOfIgnoreCase(String text, String target, int from) {
        return text.toLowerCase(Locale.ROOT).indexOf(target.toLowerCase(Locale.ROOT), from);
    }

    private enum Kind { DATA, VOICE, SMS, ADDON_VOICE }

    private static final class Part {
        final String used;
        final String total;
        final int percent;
        final int confidence;

        Part(String used, String total, int percent, int confidence) {
            this.used = used;
            this.total = total;
            this.percent = percent;
            this.confidence = confidence;
        }

        static Part empty() { return new Part("--", "--", 0, 0); }
    }
}

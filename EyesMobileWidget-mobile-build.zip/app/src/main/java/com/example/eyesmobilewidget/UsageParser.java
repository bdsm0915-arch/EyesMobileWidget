package com.example.eyesmobilewidget;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class UsageParser {
    private UsageParser() {}

    private static final Pattern PERCENT = Pattern.compile("(\\d{1,3})\\s*%");
    private static final Pattern DATA_TOKEN = Pattern.compile("([0-9][0-9.,]*\\s*(?:GB|MB|KB|G|M))", Pattern.CASE_INSENSITIVE);
    private static final Pattern VOICE_TOKEN = Pattern.compile("([0-9][0-9.,]*\\s*(?:분|초|minute|min))", Pattern.CASE_INSENSITIVE);
    private static final Pattern SMS_TOKEN = Pattern.compile("([0-9][0-9.,]*\\s*(?:건|회|개))", Pattern.CASE_INSENSITIVE);

    public static UsageData parse(String source) {
        if (source == null) return null;
        String text = normalize(source);
        if (text.length() < 20) return null;
        if (text.contains("로그인을 해주세요") || text.contains("회원가입 로그인")) {
            // Public shell can contain these strings even when logged in, so parsing still gets a chance below.
        }

        Part data = findPart(text, new String[]{"데이터 사용량", "데이터", "DATA"}, DATA_TOKEN);
        Part voice = findPart(text, new String[]{"음성 사용량", "통화 사용량", "음성", "통화"}, VOICE_TOKEN);
        Part sms = findPart(text, new String[]{"문자 사용량", "SMS 사용량", "문자", "SMS"}, SMS_TOKEN);

        if (data == null && voice == null && sms == null) return null;
        if (data == null) data = Part.empty();
        if (voice == null) voice = Part.empty();
        if (sms == null) sms = Part.empty();

        return new UsageData(
                data.used, data.total, data.percent,
                voice.used, voice.total, voice.percent,
                sms.used, sms.total, sms.percent,
                System.currentTimeMillis());
    }

    private static Part findPart(String text, String[] labels, Pattern tokenPattern) {
        for (String label : labels) {
            int from = 0;
            while (from < text.length()) {
                int idx = indexOfIgnoreCase(text, label, from);
                if (idx < 0) break;
                int start = Math.max(0, idx - 100);
                int end = Math.min(text.length(), idx + 650);
                String window = text.substring(start, end);
                Part p = parseWindow(window, tokenPattern);
                if (p != null) return p;
                from = idx + label.length();
            }
        }
        return null;
    }

    private static Part parseWindow(String window, Pattern tokenPattern) {
        List<String> values = new ArrayList<>();
        Matcher token = tokenPattern.matcher(window);
        while (token.find() && values.size() < 4) {
            String v = compact(token.group(1));
            if (!values.contains(v)) values.add(v);
        }

        int percent = -1;
        Matcher pm = PERCENT.matcher(window);
        if (pm.find()) {
            try { percent = Math.min(100, Integer.parseInt(pm.group(1))); } catch (Exception ignored) {}
        }

        if (values.isEmpty() && percent < 0) return null;
        String used = values.size() >= 1 ? values.get(0) : "--";
        String total = values.size() >= 2 ? values.get(1) : inferTotal(window);

        if (percent < 0) percent = calculatePercent(used, total);
        if (percent < 0) percent = 0;
        return new Part(used, total, percent);
    }

    private static String inferTotal(String window) {
        String lower = window.toLowerCase(Locale.ROOT);
        if (lower.contains("기본제공") || lower.contains("무제한")) return "기본제공";
        return "--";
    }

    private static int calculatePercent(String used, String total) {
        double u = numericToBase(used);
        double t = numericToBase(total);
        if (u < 0 || t <= 0) return -1;
        return (int) Math.round(Math.min(100d, u * 100d / t));
    }

    private static double numericToBase(String value) {
        if (value == null) return -1;
        String v = value.replace(",", "").replace(" ", "").toUpperCase(Locale.ROOT);
        Matcher m = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)(GB|MB|KB|G|M|분|초|MINUTE|MIN|건|회|개)?").matcher(v);
        if (!m.find()) return -1;
        double n;
        try { n = Double.parseDouble(m.group(1)); } catch (Exception e) { return -1; }
        String unit = m.group(2) == null ? "" : m.group(2);
        if (unit.equals("GB") || unit.equals("G")) n *= 1024d;
        if (unit.equals("KB")) n /= 1024d;
        return n;
    }

    private static String normalize(String s) {
        return s.replace('\u00A0', ' ')
                .replaceAll("[\\t\\r]+", " ")
                .replaceAll("\\n+", "\\n")
                .replaceAll(" {2,}", " ")
                .trim();
    }

    private static String compact(String s) {
        return s == null ? "--" : s.replaceAll("\\s+", "");
    }

    private static int indexOfIgnoreCase(String text, String target, int from) {
        return text.toLowerCase(Locale.ROOT).indexOf(target.toLowerCase(Locale.ROOT), from);
    }

    private static final class Part {
        final String used;
        final String total;
        final int percent;
        Part(String used, String total, int percent) {
            this.used = used; this.total = total; this.percent = percent;
        }
        static Part empty() { return new Part("--", "--", 0); }
    }
}

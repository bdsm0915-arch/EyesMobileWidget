package com.example.eyesmobilewidget;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses the logged-in usage cards. v2.4 prefers a DOM-focused snapshot and rejects
 * recommendation/plan-card numbers that previously could be mistaken for live usage.
 */
public final class UsageParser {
    private UsageParser() {}

    private static final String DATA_CORE = "[0-9][0-9.,]*\\s*(?:TB|GB|MB|KB|G|M)";
    private static final String VOICE_CORE = "[0-9][0-9.,]*\\s*(?:시간|분|초|minute|min)";
    private static final String SMS_CORE = "[0-9][0-9.,]*\\s*(?:건|회|개)";

    private static final Pattern PERCENT = Pattern.compile("(\\d{1,3})\\s*%");
    private static final Pattern DATA_TOKEN = Pattern.compile("(" + DATA_CORE + ")", Pattern.CASE_INSENSITIVE);
    private static final Pattern VOICE_TOKEN = Pattern.compile("(" + VOICE_CORE + ")", Pattern.CASE_INSENSITIVE);
    private static final Pattern SMS_TOKEN = Pattern.compile("(" + SMS_CORE + ")", Pattern.CASE_INSENSITIVE);

    public static UsageData parse(String source) {
        if (source == null) return null;
        String normalized = normalize(source);
        if (normalized.length() < 20) return null;

        List<String> focused = extractFocusedBlocks(normalized);
        Part data = bestPart(focused, Kind.DATA);
        Part voice = bestPart(focused, Kind.VOICE);
        Part sms = bestPart(focused, Kind.SMS);

        int found = countFound(data, voice, sms);
        if (found == 0) {
            // Legacy/plain-text fallback, but only when the page contains explicit usage context.
            String body = extractBody(normalized);
            if (!looksLikeUsageArea(body)) return null;
            List<String> single = new ArrayList<>();
            single.add(body);
            data = bestPart(single, Kind.DATA);
            voice = bestPart(single, Kind.VOICE);
            sms = bestPart(single, Kind.SMS);
            found = countFound(data, voice, sms);
        }

        // A recommendation card can also mention data/voice/SMS allowances. A successful usage
        // read must contain at least two independently parsed usage categories.
        if (found < 2) return null;

        if (data == null) data = Part.empty();
        if (voice == null) voice = Part.empty();
        if (sms == null) sms = Part.empty();

        return new UsageData(
                data.used, data.total, data.percent,
                voice.used, voice.total, voice.percent,
                sms.used, sms.total, sms.percent,
                System.currentTimeMillis());
    }

    private static Part bestPart(List<String> blocks, Kind kind) {
        Part best = null;
        for (String block : blocks) {
            Part p = findPart(block, kind);
            if (p != null && (best == null || p.confidence > best.confidence)) best = p;
        }
        return best;
    }

    private static Part findPart(String text, Kind kind) {
        String[] labels = labels(kind);
        Pattern tokenPattern = tokenPattern(kind);
        Part best = null;

        for (String label : labels) {
            int from = 0;
            while (from < text.length()) {
                int idx = indexOfIgnoreCase(text, label, from);
                if (idx < 0) break;

                int start = idx;
                int end = Math.min(text.length(), idx + 520);
                int next = nextOtherCategory(text, kind, idx + label.length());
                if (next > idx && next < end) end = next;
                String window = text.substring(start, end);

                Part p = parseWindow(window, kind, tokenPattern);
                if (p != null && (best == null || p.confidence > best.confidence)) best = p;
                from = idx + label.length();
            }
        }
        return best;
    }

    private static Part parseWindow(String window, Kind kind, Pattern tokenPattern) {
        String lower = window.toLowerCase(Locale.ROOT);
        int bad = countMatches(lower, "요금제추천", "가입신청", "특별할인", "추천상품", "통신상품");
        int strongUsageSignals = countMatches(lower, "사용량", "잔여", "남은", "잔량", "소진", "제공량", "이용량");
        boolean basicProvided = lower.contains("기본제공") || lower.contains("무제한");
        int usageSignals = strongUsageSignals + (basicProvided ? 1 : 0);
        if (bad > 0 && strongUsageSignals == 0) return null;

        String core = core(kind);
        String used = findAssociated(window, core,
                "(?:실사용량|사용량|사용|소진량|소진|이용량|이용)");
        String remain = findAssociated(window, core,
                "(?:잔여량|잔여|남은량|남은|잔량)");
        String total = findAssociated(window, core,
                "(?:기본제공량|총제공량|제공량|전체량|전체|총량|총|기준|한도)");

        List<String> values = collectValues(window, tokenPattern);
        int confidence = usageSignals * 5 - bad * 15;
        if (used != null) confidence += 18;
        if (remain != null) confidence += 18;
        if (total != null) confidence += 14;

        // If the site gives remaining + total, derive actual used amount so the existing widget
        // can continue to display "잔여 = total - used" correctly.
        if (used == null && remain != null && total != null) {
            used = subtract(total, remain, kind);
            if (used != null) confidence += 10;
        }
        if (total == null && used != null && remain != null) {
            total = add(used, remain, kind);
            if (total != null) confidence += 8;
        }

        // Fallback only inside a block that has explicit usage wording. This is intentionally
        // stricter than v2.3's "first number / second number" rule.
        if (used == null && strongUsageSignals > 0 && !values.isEmpty()) {
            used = values.get(0);
            confidence += 4;
        }
        if (total == null && strongUsageSignals > 0 && values.size() >= 2) {
            for (String v : values) {
                if (used == null || !compact(v).equals(compact(used))) {
                    total = v;
                    confidence += 3;
                    break;
                }
            }
        }

        if (kind != Kind.DATA && total == null && (lower.contains("기본제공") || lower.contains("무제한"))) {
            total = "기본제공";
            confidence += 8;
        }

        if (used == null && total == null && remain == null) return null;
        if (used == null) used = "--";
        if (total == null) total = inferTotal(window);

        int percent = findPercent(window);
        if (percent < 0) percent = calculatePercent(used, total, kind);
        if (percent < 0 && kind == Kind.DATA && remain != null && !"--".equals(total)) {
            double r = numericToBase(remain, kind);
            double t = numericToBase(total, kind);
            if (r >= 0 && t > 0) percent = clampPercent((t - r) * 100d / t);
        }
        if (percent < 0) percent = 0;

        if (confidence < 4) return null;
        return new Part(compact(used), compact(total), percent, confidence);
    }

    private static String findAssociated(String window, String tokenCore, String keywordCore) {
        Pattern after = Pattern.compile(keywordCore + "[^0-9]{0,34}(" + tokenCore + ")",
                Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        Matcher a = after.matcher(window);
        if (a.find()) return compact(a.group(1));

        Pattern before = Pattern.compile("(" + tokenCore + ")[^\\n0-9]{0,28}" + keywordCore,
                Pattern.CASE_INSENSITIVE);
        Matcher b = before.matcher(window);
        if (b.find()) return compact(b.group(1));
        return null;
    }

    private static List<String> collectValues(String window, Pattern tokenPattern) {
        List<String> out = new ArrayList<>();
        Matcher m = tokenPattern.matcher(window);
        while (m.find() && out.size() < 8) {
            String value = compact(m.group(1));
            if (!out.contains(value)) out.add(value);
        }
        return out;
    }

    private static int findPercent(String window) {
        Matcher pm = PERCENT.matcher(window);
        if (pm.find()) {
            try { return Math.min(100, Integer.parseInt(pm.group(1))); } catch (Exception ignored) {}
        }
        return -1;
    }

    private static String inferTotal(String window) {
        String lower = window.toLowerCase(Locale.ROOT);
        if (lower.contains("기본제공") || lower.contains("무제한")) return "기본제공";
        return "--";
    }

    private static int calculatePercent(String used, String total, Kind kind) {
        double u = numericToBase(used, kind);
        double t = numericToBase(total, kind);
        if (u < 0 || t <= 0) return -1;
        return clampPercent(u * 100d / t);
    }

    private static int clampPercent(double p) {
        return (int) Math.round(Math.max(0d, Math.min(100d, p)));
    }

    private static String subtract(String total, String remaining, Kind kind) {
        double t = numericToBase(total, kind);
        double r = numericToBase(remaining, kind);
        if (t < 0 || r < 0 || r > t) return null;
        return formatBase(t - r, kind);
    }

    private static String add(String used, String remaining, Kind kind) {
        double u = numericToBase(used, kind);
        double r = numericToBase(remaining, kind);
        if (u < 0 || r < 0) return null;
        return formatBase(u + r, kind);
    }

    private static double numericToBase(String value, Kind kind) {
        if (value == null || value.contains("기본제공") || value.equals("--")) return -1;
        String v = value.replace(",", "").replace(" ", "").toUpperCase(Locale.ROOT);
        Matcher m = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)(TB|GB|MB|KB|G|M|시간|분|초|MINUTE|MIN|건|회|개)?").matcher(v);
        if (!m.find()) return -1;
        double n;
        try { n = Double.parseDouble(m.group(1)); } catch (Exception e) { return -1; }
        String unit = m.group(2) == null ? "" : m.group(2);
        if (kind == Kind.DATA) {
            if (unit.equals("TB")) n *= 1024d * 1024d;
            else if (unit.equals("GB") || unit.equals("G")) n *= 1024d;
            else if (unit.equals("KB")) n /= 1024d;
        } else if (kind == Kind.VOICE) {
            if (unit.equals("시간")) n *= 60d;
            else if (unit.equals("초")) n /= 60d;
        }
        return n;
    }

    private static String formatBase(double value, Kind kind) {
        if (kind == Kind.DATA) {
            if (value >= 1024d) return trim(value / 1024d, 2) + "GB";
            return trim(value, 1) + "MB";
        }
        if (kind == Kind.VOICE) return trim(value, 1) + "분";
        return trim(value, 0) + "건";
    }

    private static String trim(double n, int decimals) {
        String f;
        if (decimals <= 0) f = String.format(Locale.KOREA, "%.0f", n);
        else if (decimals == 1) f = String.format(Locale.KOREA, "%.1f", n);
        else f = String.format(Locale.KOREA, "%.2f", n);
        if (f.contains(".")) f = f.replaceAll("0+$", "").replaceAll("\\.$", "");
        return f;
    }

    private static List<String> extractFocusedBlocks(String text) {
        List<String> blocks = new ArrayList<>();
        Pattern marker = Pattern.compile("\\[\\[EYES_USAGE_BLOCK_\\d+]]");
        Matcher m = marker.matcher(text);
        List<Integer> starts = new ArrayList<>();
        while (m.find()) starts.add(m.end());
        for (int i = 0; i < starts.size(); i++) {
            int start = starts.get(i);
            int end = text.length();
            if (i + 1 < starts.size()) {
                int nextMarker = text.lastIndexOf("[[EYES_USAGE_BLOCK_", starts.get(i + 1));
                if (nextMarker > start) end = nextMarker;
            } else {
                int body = text.indexOf("[[EYES_BODY]]", start);
                if (body > start) end = body;
            }
            String block = text.substring(start, end).trim();
            if (!block.isEmpty()) blocks.add(block);
        }
        return blocks;
    }

    private static String extractBody(String text) {
        int idx = text.indexOf("[[EYES_BODY]]");
        return idx >= 0 ? text.substring(idx + "[[EYES_BODY]]".length()).trim() : text;
    }

    private static boolean looksLikeUsageArea(String text) {
        if (text == null) return false;
        String l = text.toLowerCase(Locale.ROOT);
        boolean explicit = l.contains("사용량조회") || l.contains("사용량 조회")
                || l.contains("데이터 사용량") || l.contains("통화 사용량")
                || l.contains("음성 사용량") || l.contains("문자 사용량");
        boolean category = (l.contains("데이터") && (l.contains("통화") || l.contains("음성")) && (l.contains("문자") || l.contains("sms")));
        return explicit && category;
    }

    private static boolean hasStrongUsageSignal(String text) {
        String l = text.toLowerCase(Locale.ROOT);
        return l.contains("데이터 사용량") || l.contains("사용량조회") || l.contains("사용량 조회")
                || (l.contains("잔여") && l.contains("데이터"));
    }

    private static int countFound(Part... parts) {
        int n = 0;
        for (Part p : parts) if (p != null) n++;
        return n;
    }

    private static int nextOtherCategory(String text, Kind current, int from) {
        int best = -1;
        for (Kind k : Kind.values()) {
            if (k == current) continue;
            for (String label : labels(k)) {
                int i = indexOfIgnoreCase(text, label, from);
                if (i >= 0 && (best < 0 || i < best)) best = i;
            }
        }
        return best;
    }

    private static String[] labels(Kind kind) {
        if (kind == Kind.DATA) return new String[]{"데이터 사용량", "데이터 잔여량", "데이터"};
        if (kind == Kind.VOICE) return new String[]{"음성 사용량", "통화 사용량", "음성", "통화"};
        return new String[]{"문자 사용량", "SMS 사용량", "문자", "SMS"};
    }

    private static Pattern tokenPattern(Kind kind) {
        if (kind == Kind.DATA) return DATA_TOKEN;
        if (kind == Kind.VOICE) return VOICE_TOKEN;
        return SMS_TOKEN;
    }

    private static String core(Kind kind) {
        if (kind == Kind.DATA) return DATA_CORE;
        if (kind == Kind.VOICE) return VOICE_CORE;
        return SMS_CORE;
    }

    private static int countMatches(String text, String... words) {
        int n = 0;
        for (String w : words) if (text.contains(w.toLowerCase(Locale.ROOT))) n++;
        return n;
    }

    private static String normalize(String s) {
        return s.replace('\u00A0', ' ')
                .replaceAll("[\\t\\r]+", " ")
                .replaceAll(" *\\n *", "\\n")
                .replaceAll("\\n{3,}", "\\n\\n")
                .replaceAll(" {2,}", " ")
                .trim();
    }

    private static String compact(String s) {
        return s == null ? "--" : s.replaceAll("\\s+", "");
    }

    private static int indexOfIgnoreCase(String text, String target, int from) {
        return text.toLowerCase(Locale.ROOT).indexOf(target.toLowerCase(Locale.ROOT), from);
    }

    private enum Kind { DATA, VOICE, SMS }

    private static final class Part {
        final String used;
        final String total;
        final int percent;
        final int confidence;

        Part(String used, String total, int percent, int confidence) {
            this.used = used;
            this.total = total;
            this.percent = percent;
            this.confidence = confidence;
        }

        static Part empty() { return new Part("--", "--", 0, 0); }
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.CookieManager;

public final class SessionCookieStore {
    private static final String PREF = "eyes_session_cookie_backup";
    private static final String KEY_WWW = "cookie_www";
    private static final String KEY_ROOT = "cookie_root";

    private static final String URL_WWW = "https://www.eyes.co.kr/";
    private static final String URL_ROOT = "https://eyes.co.kr/";

    private SessionCookieStore() {}

    public static void backup(Context context) {
        try {
            CookieManager cm = CookieManager.getInstance();
            String www = cm.getCookie(URL_WWW);
            String root = cm.getCookie(URL_ROOT);

            SharedPreferences.Editor e = prefs(context).edit();
            if (www != null && !www.trim().isEmpty()) e.putString(KEY_WWW, www);
            if (root != null && !root.trim().isEmpty()) e.putString(KEY_ROOT, root);
            e.apply();
            cm.flush();
        } catch (Exception ignored) {
        }
    }

    public static void restore(Context context) {
        try {
            CookieManager cm = CookieManager.getInstance();
            restoreCookieHeader(cm, URL_WWW, prefs(context).getString(KEY_WWW, null));
            restoreCookieHeader(cm, URL_ROOT, prefs(context).getString(KEY_ROOT, null));
            cm.flush();
        } catch (Exception ignored) {
        }
    }

    public static String currentCookieHeader(Context context, String url) {
        restore(context);
        try {
            CookieManager cm = CookieManager.getInstance();
            String cookie = cm.getCookie(url);
            if (cookie == null || cookie.trim().isEmpty()) {
                cookie = cm.getCookie(URL_WWW);
            }
            return cookie;
        } catch (Exception e) {
            return null;
        }
    }

    private static void restoreCookieHeader(CookieManager cm, String url, String header) {
        if (header == null || header.trim().isEmpty()) return;
        String[] pairs = header.split(";");
        for (String pair : pairs) {
            String p = pair.trim();
            if (p.isEmpty() || !p.contains("=")) continue;
            cm.setCookie(url, p + "; Path=/; Secure; SameSite=Lax");
        }
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
}

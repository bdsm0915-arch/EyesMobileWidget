package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.CookieManager;

public final class SessionCookieStore {
    private static final String PREF = "eyes_session_cookie_backup";
    private static final String KEY_WWW = "cookie_www";
    private static final String KEY_ROOT = "cookie_root";
    private static final String KEY_USER_AGENT = "webview_user_agent";

    private static final String URL_WWW = "https://www.eyes.co.kr/";
    private static final String URL_ROOT = "https://eyes.co.kr/";

    private SessionCookieStore() {}

    public static void backup(Context context) {
        try {
            CookieManager cm = CookieManager.getInstance();
            String www = cm.getCookie(URL_WWW);
            String root = cm.getCookie(URL_ROOT);

            SharedPreferences.Editor e = prefs(context).edit();
            if (notEmpty(www)) e.putString(KEY_WWW, www);
            if (notEmpty(root)) e.putString(KEY_ROOT, root);
            e.apply();
            cm.flush();
        } catch (Exception ignored) {
        }
    }

    /**
     * Restore only when WebView has no live cookies.
     * Never overwrite a newer live session with an older backup.
     */
    public static void restoreIfMissing(Context context) {
        try {
            CookieManager cm = CookieManager.getInstance();
            String liveWww = cm.getCookie(URL_WWW);
            String liveRoot = cm.getCookie(URL_ROOT);

            if (!notEmpty(liveWww)) {
                restoreCookieHeader(cm, URL_WWW, prefs(context).getString(KEY_WWW, null));
            }
            if (!notEmpty(liveRoot)) {
                restoreCookieHeader(cm, URL_ROOT, prefs(context).getString(KEY_ROOT, null));
            }
            cm.flush();
        } catch (Exception ignored) {
        }
    }

    public static String currentCookieHeader(Context context, String url) {
        restoreIfMissing(context);
        try {
            CookieManager cm = CookieManager.getInstance();
            String cookie = cm.getCookie(url);
            if (!notEmpty(cookie)) cookie = cm.getCookie(URL_WWW);
            if (!notEmpty(cookie)) cookie = prefs(context).getString(KEY_WWW, null);
            return cookie;
        } catch (Exception e) {
            return null;
        }
    }

    public static void saveUserAgent(Context context, String userAgent) {
        if (!notEmpty(userAgent)) return;
        prefs(context).edit().putString(KEY_USER_AGENT, userAgent).apply();
    }

    public static String getUserAgent(Context context) {
        return prefs(context).getString(KEY_USER_AGENT,
                "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0 Mobile Safari/537.36");
    }

    private static void restoreCookieHeader(CookieManager cm, String url, String header) {
        if (!notEmpty(header)) return;
        String[] pairs = header.split(";");
        for (String pair : pairs) {
            String p = pair.trim();
            if (p.isEmpty() || !p.contains("=")) continue;
            cm.setCookie(url, p + "; Path=/; Secure");
        }
    }

    private static boolean notEmpty(String s) {
        return s != null && !s.trim().isEmpty();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
}

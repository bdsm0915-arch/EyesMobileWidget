package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.CookieManager;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Stores only a last-known-good WebView cookie snapshot.
 * The snapshot is captured after the usage page was parsed successfully.
 */
public final class SessionCookieStore {
    private static final String PREF = "eyes_session_cookie_backup";
    private static final String KEY_WWW = "cookie_www_v22";
    private static final String KEY_ROOT = "cookie_root_v22";
    private static final String KEY_MYPAGE = "cookie_mypage_v22";
    private static final String KEY_MYPAGE_DIR = "cookie_mypage_dir_v22";
    private static final String KEY_USER_AGENT = "webview_user_agent";
    private static final String OLD_KEY_WWW = "cookie_www";
    private static final String OLD_KEY_ROOT = "cookie_root";
    private static final String KEY_SAVED_AT = "cookie_saved_at_v22";

    public static final String URL_WWW = "https://www.eyes.co.kr/";
    public static final String URL_ROOT = "https://eyes.co.kr/";
    public static final String URL_MYPAGE = "https://www.eyes.co.kr/mypage/main";
    public static final String URL_MYPAGE_DIR = "https://www.eyes.co.kr/mypage/";

    private SessionCookieStore() {}

    public static void backup(Context context) {
        try {
            CookieManager cm = CookieManager.getInstance();
            String www = cm.getCookie(URL_WWW);
            String root = cm.getCookie(URL_ROOT);
            String myPage = cm.getCookie(URL_MYPAGE);
            String myPageDir = cm.getCookie(URL_MYPAGE_DIR);

            SharedPreferences.Editor e = prefs(context).edit();
            if (notEmpty(www)) e.putString(KEY_WWW, www);
            if (notEmpty(root)) e.putString(KEY_ROOT, root);
            if (notEmpty(myPage)) e.putString(KEY_MYPAGE, myPage);
            if (notEmpty(myPageDir)) e.putString(KEY_MYPAGE_DIR, myPageDir);
            if (notEmpty(www) || notEmpty(root) || notEmpty(myPage) || notEmpty(myPageDir)) {
                e.putLong(KEY_SAVED_AT, System.currentTimeMillis());
            }
            e.apply();
            cm.flush();
        } catch (Throwable ignored) {
        }
    }

    /**
     * Restores missing cookie names even when analytics/consent cookies are already present.
     * v2.1 only restored when an entire cookie header was empty, which could leave the auth
     * cookie missing while unrelated cookies made the jar look non-empty.
     */
    public static void restoreIfMissing(Context context) {
        try {
            CookieManager cm = CookieManager.getInstance();
            SharedPreferences p = prefs(context);

            Map<String, String> live = new LinkedHashMap<>();
            mergeHeader(live, cm.getCookie(URL_WWW));
            mergeHeader(live, cm.getCookie(URL_ROOT));
            mergeHeader(live, cm.getCookie(URL_MYPAGE));
            mergeHeader(live, cm.getCookie(URL_MYPAGE_DIR));

            Map<String, String> good = getBackupCookieMap(p);
            for (Map.Entry<String, String> entry : good.entrySet()) {
                if (!live.containsKey(entry.getKey()) || !notEmpty(live.get(entry.getKey()))) {
                    setCookieEverywhere(cm, entry.getKey(), entry.getValue());
                }
            }
            cm.flush();
        } catch (Throwable ignored) {
        }
    }

    public static boolean hasBackup(Context context) {
        return !getBackupCookieMap(prefs(context)).isEmpty();
    }

    public static long getSavedAt(Context context) {
        return prefs(context).getLong(KEY_SAVED_AT, 0L);
    }

    /**
     * Re-applies every cookie from the last known-good snapshot. This is used once after a
     * confirmed logout page, then WebView storage is restored before retrying MyPage.
     */
    public static void forceRestoreBackup(Context context) {
        try {
            CookieManager cm = CookieManager.getInstance();
            Map<String, String> good = getBackupCookieMap(prefs(context));
            for (Map.Entry<String, String> entry : good.entrySet()) {
                setCookieEverywhere(cm, entry.getKey(), entry.getValue());
            }
            cm.flush();
        } catch (Throwable ignored) {
        }
    }

    public static String currentCookieHeader(Context context, String url) {
        restoreIfMissing(context);
        try {
            CookieManager cm = CookieManager.getInstance();
            String cookie = cm.getCookie(url);
            if (!notEmpty(cookie)) cookie = cm.getCookie(URL_MYPAGE);
            if (!notEmpty(cookie)) cookie = cm.getCookie(URL_WWW);
            if (!notEmpty(cookie)) cookie = prefs(context).getString(KEY_MYPAGE, null);
            if (!notEmpty(cookie)) cookie = prefs(context).getString(KEY_WWW, null);
            return cookie;
        } catch (Throwable e) {
            return null;
        }
    }

    public static void flush() {
        try {
            CookieManager.getInstance().flush();
        } catch (Throwable ignored) {
        }
    }

    public static void saveUserAgent(Context context, String userAgent) {
        if (!notEmpty(userAgent)) return;
        prefs(context).edit().putString(KEY_USER_AGENT, userAgent).apply();
    }

    public static String getUserAgent(Context context) {
        return prefs(context).getString(KEY_USER_AGENT,
                "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0 Mobile Safari/537.36");
    }

    private static Map<String, String> getBackupCookieMap(SharedPreferences p) {
        Map<String, String> out = new LinkedHashMap<>();
        // Migrate/accept v2.1 snapshots so upgrading to v2.2 does not force an immediate logout.
        mergeHeader(out, p.getString(OLD_KEY_WWW, null));
        mergeHeader(out, p.getString(OLD_KEY_ROOT, null));
        mergeHeader(out, p.getString(KEY_WWW, null));
        mergeHeader(out, p.getString(KEY_ROOT, null));
        mergeHeader(out, p.getString(KEY_MYPAGE_DIR, null));
        mergeHeader(out, p.getString(KEY_MYPAGE, null));
        return out;
    }

    private static void mergeHeader(Map<String, String> out, String header) {
        if (!notEmpty(header)) return;
        for (String pair : header.split(";")) {
            String item = pair.trim();
            int eq = item.indexOf('=');
            if (eq <= 0) continue;
            String name = item.substring(0, eq).trim();
            String value = item.substring(eq + 1).trim();
            if (!name.isEmpty()) out.put(name, value);
        }
    }

    private static void setCookieEverywhere(CookieManager cm, String name, String value) {
        if (!notEmpty(name)) return;
        String pair = name + "=" + (value == null ? "" : value) + "; Path=/; Secure";
        cm.setCookie(URL_WWW, pair);
        cm.setCookie(URL_MYPAGE_DIR, pair);
        cm.setCookie(URL_MYPAGE, pair);
        cm.setCookie(URL_ROOT, pair);
    }

    private static boolean notEmpty(String s) {
        return s != null && !s.trim().isEmpty();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
}

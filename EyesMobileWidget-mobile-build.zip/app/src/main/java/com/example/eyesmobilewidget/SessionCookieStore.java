package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.CookieManager;

/**
 * v2.6 session policy:
 * - CookieManager is the single source of truth.
 * - Old copied auth-cookie snapshots are never restored because the server may have already
 *   invalidated them. Re-inserting an expired token can trap WebView in a logged-out loop.
 * - If the live session expires, AutoLoginHelper creates a brand-new server session.
 */
public final class SessionCookieStore {
    private static final String PREF = "eyes_session_cookie_backup";
    private static final String KEY_USER_AGENT = "webview_user_agent";

    private static final String KEY_WWW = "cookie_www_v22";
    private static final String KEY_ROOT = "cookie_root_v22";
    private static final String KEY_MYPAGE = "cookie_mypage_v22";
    private static final String KEY_MYPAGE_DIR = "cookie_mypage_dir_v22";
    private static final String OLD_KEY_WWW = "cookie_www";
    private static final String OLD_KEY_ROOT = "cookie_root";
    private static final String KEY_SAVED_AT = "cookie_saved_at_v22";
    private static final String KEY_POLICY_MIGRATED = "v26_live_cookie_policy";

    public static final String URL_WWW = "https://www.eyes.co.kr/";
    public static final String URL_ROOT = "https://eyes.co.kr/";
    public static final String URL_MYPAGE = "https://www.eyes.co.kr/mypage/main";
    public static final String URL_MYPAGE_DIR = "https://www.eyes.co.kr/mypage/";

    private SessionCookieStore() {}

    /** Removes only the app's legacy copied-cookie snapshot, never live WebView cookies. */
    public static void migrateToLiveCookiePolicy(Context context) {
        try {
            SharedPreferences p = prefs(context);
            if (p.getBoolean(KEY_POLICY_MIGRATED, false)) return;
            p.edit()
                    .remove(KEY_WWW)
                    .remove(KEY_ROOT)
                    .remove(KEY_MYPAGE)
                    .remove(KEY_MYPAGE_DIR)
                    .remove(OLD_KEY_WWW)
                    .remove(OLD_KEY_ROOT)
                    .remove(KEY_SAVED_AT)
                    .putBoolean(KEY_POLICY_MIGRATED, true)
                    .apply();
        } catch (Throwable ignored) {
        }
    }

    /** Kept for source compatibility. v2.6 no longer duplicates auth cookies into preferences. */
    public static void backup(Context context) {
        flush();
    }

    /** Kept for source compatibility. Expired cookie snapshots are intentionally never restored. */
    public static void restoreIfMissing(Context context) {
        migrateToLiveCookiePolicy(context);
        flush();
    }

    public static boolean hasBackup(Context context) {
        return false;
    }

    public static long getSavedAt(Context context) {
        return 0L;
    }

    /** Intentionally disabled in v2.6. A stale server session must not be resurrected. */
    public static void forceRestoreBackup(Context context) {
        migrateToLiveCookiePolicy(context);
        flush();
    }

    public static String currentCookieHeader(Context context, String url) {
        migrateToLiveCookiePolicy(context);
        try {
            CookieManager cm = CookieManager.getInstance();
            String cookie = cm.getCookie(url);
            if (!notEmpty(cookie)) cookie = cm.getCookie(URL_MYPAGE);
            if (!notEmpty(cookie)) cookie = cm.getCookie(URL_WWW);
            return cookie;
        } catch (Throwable e) {
            return null;
        }
    }

    public static void flush() {
        try {
            CookieManager.getInstance().flush();
        } catch (Throwable ignored) {
        }
    }

    public static void saveUserAgent(Context context, String userAgent) {
        if (!notEmpty(userAgent)) return;
        prefs(context).edit().putString(KEY_USER_AGENT, userAgent).apply();
    }

    public static String getUserAgent(Context context) {
        return prefs(context).getString(KEY_USER_AGENT,
                "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0 Mobile Safari/537.36");
    }

    private static boolean notEmpty(String s) {
        return s != null && !s.trim().isEmpty();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.CookieManager;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * v2.7 verified-session persistence.
 *
 * A cookie snapshot is saved ONLY after UsageParser successfully reads the authenticated
 * usage page. On the next process start, only cookie names that are missing from the live
 * CookieManager are restored. If the server later rejects that session, the snapshot is
 * invalidated before AutoLoginHelper creates a fresh server session.
 */
public final class VerifiedSessionStore {
    private static final String PREF = "eyes_verified_session_v27";
    private static final String KEY_WWW = "verified_www";
    private static final String KEY_MYPAGE = "verified_mypage";
    private static final String KEY_SAVED_AT = "verified_at";
    private static final long MAX_AGE_MS = 7L * 24L * 60L * 60L * 1000L;

    private VerifiedSessionStore() {}

    public static boolean hasVerifiedSession(Context context) {
        SharedPreferences p = prefs(context);
        long at = p.getLong(KEY_SAVED_AT, 0L);
        if (at <= 0L || System.currentTimeMillis() - at > MAX_AGE_MS) return false;
        return notEmpty(p.getString(KEY_WWW, null)) || notEmpty(p.getString(KEY_MYPAGE, null));
    }

    public static void captureVerified(Context context) {
        try {
            CookieManager cm = CookieManager.getInstance();
            String www = cm.getCookie(SessionCookieStore.URL_WWW);
            String mypage = cm.getCookie(SessionCookieStore.URL_MYPAGE);
            if (!notEmpty(www) && !notEmpty(mypage)) return;

            SharedPreferences.Editor e = prefs(context).edit();
            if (notEmpty(www)) e.putString(KEY_WWW, www); else e.remove(KEY_WWW);
            if (notEmpty(mypage)) e.putString(KEY_MYPAGE, mypage); else e.remove(KEY_MYPAGE);
            e.putLong(KEY_SAVED_AT, System.currentTimeMillis()).apply();
            cm.flush();
        } catch (Throwable ignored) {
        }
    }

    /** Restores only missing cookie NAMES, never overwriting a newer live cookie value. */
    public static boolean restoreMissing(Context context) {
        try {
            if (!hasVerifiedSession(context)) return false;
            CookieManager cm = CookieManager.getInstance();
            SharedPreferences p = prefs(context);
            boolean changed = false;
            changed |= restoreHeaderMissing(cm, SessionCookieStore.URL_WWW,
                    p.getString(KEY_WWW, null));
            changed |= restoreHeaderMissing(cm, SessionCookieStore.URL_MYPAGE_DIR,
                    p.getString(KEY_MYPAGE, null));
            if (changed) cm.flush();
            return changed;
        } catch (Throwable ignored) {
            return false;
        }
    }

    /** Called as soon as the server shows a logged-out page for a previously verified session. */
    public static void invalidate(Context context) {
        try {
            prefs(context).edit().clear().apply();
        } catch (Throwable ignored) {
        }
    }

    public static long ageMillis(Context context) {
        long at = prefs(context).getLong(KEY_SAVED_AT, 0L);
        return at <= 0L ? -1L : Math.max(0L, System.currentTimeMillis() - at);
    }

    private static boolean restoreHeaderMissing(CookieManager cm, String url, String savedHeader) {
        if (!notEmpty(savedHeader)) return false;
        Map<String, String> live = parse(cm.getCookie(url));
        Map<String, String> saved = parse(savedHeader);
        boolean changed = false;
        for (Map.Entry<String, String> entry : saved.entrySet()) {
            String name = entry.getKey();
            String value = entry.getValue();
            if (!live.containsKey(name) && notEmpty(name) && value != null) {
                cm.setCookie(url, name + "=" + value + "; Path=/; Secure; SameSite=Lax");
                changed = true;
            }
        }
        return changed;
    }

    private static Map<String, String> parse(String header) {
        Map<String, String> out = new LinkedHashMap<>();
        if (!notEmpty(header)) return out;
        for (String part : header.split(";")) {
            String p = part.trim();
            int eq = p.indexOf('=');
            if (eq <= 0) continue;
            String name = p.substring(0, eq).trim();
            String value = p.substring(eq + 1).trim();
            if (!name.isEmpty()) out.put(name, value);
        }
        return out;
    }

    private static boolean notEmpty(String s) {
        return s != null && !s.trim().isEmpty();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Stores the optional auto-login credentials encrypted with a key held by Android Keystore.
 * Nothing is hard-coded into the APK and plaintext credentials are never written to disk.
 */
public final class SecureCredentialStore {
    private static final String PREF = "eyes_secure_autologin_v23";
    private static final String KEY_ALIAS = "eyes_mobile_autologin_aes_v23";
    private static final String KEY_ID = "enc_id";
    private static final String KEY_PASSWORD = "enc_password";
    private static final String KEY_ENABLED = "enabled";

    private SecureCredentialStore() {}

    public static final class Credentials {
        public final String userId;
        public final String password;

        Credentials(String userId, String password) {
            this.userId = userId;
            this.password = password;
        }
    }

    public static void save(Context context, String userId, String password) throws Exception {
        if (userId == null || userId.trim().isEmpty()) throw new IllegalArgumentException("아이디가 비어 있습니다.");
        if (password == null || password.isEmpty()) throw new IllegalArgumentException("비밀번호가 비어 있습니다.");

        SharedPreferences.Editor e = prefs(context).edit();
        e.putString(KEY_ID, encrypt(userId.trim()));
        e.putString(KEY_PASSWORD, encrypt(password));
        e.putBoolean(KEY_ENABLED, true);
        e.apply();
    }

    private static volatile String lastLoadError = "";

    public static Credentials load(Context context) {
        SharedPreferences p = prefs(context);
        String packedId = p.getString(KEY_ID, null);
        String packedPw = p.getString(KEY_PASSWORD, null);
        if (packedId == null || packedId.isEmpty() || packedPw == null || packedPw.isEmpty()) {
            lastLoadError = "NO_STORED_DATA";
            return null;
        }

        // v6.5: encrypted credential presence is the source of truth. Older builds could make the
        // UI look as if auto-login had switched itself off when a one-off Keystore read failed.
        // If encrypted values still exist, repair the enabled marker instead of treating them as
        // deleted. Only the explicit '저장정보 삭제' action actually removes these values.
        if (!p.getBoolean(KEY_ENABLED, false)) {
            p.edit().putBoolean(KEY_ENABLED, true).apply();
        }

        Throwable last = null;
        for (int attempt = 0; attempt < 3; attempt++) {
            try {
                String id = decrypt(packedId);
                String pw = decrypt(packedPw);
                if (id == null || id.isEmpty() || pw == null || pw.isEmpty()) {
                    lastLoadError = "EMPTY_AFTER_DECRYPT";
                    return null;
                }
                lastLoadError = "";
                return new Credentials(id, pw);
            } catch (Throwable t) {
                last = t;
                try { Thread.sleep(20L * (attempt + 1)); } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        lastLoadError = last == null ? "DECRYPT_FAILED" : last.getClass().getSimpleName();
        return null;
    }

    /** True when encrypted auto-login information is still stored, even if a Keystore read failed. */
    public static boolean isEnabled(Context context) {
        SharedPreferences p = prefs(context);
        String id = p.getString(KEY_ID, null);
        String pw = p.getString(KEY_PASSWORD, null);
        boolean stored = id != null && !id.isEmpty() && pw != null && !pw.isEmpty();
        if (stored && !p.getBoolean(KEY_ENABLED, false)) {
            p.edit().putBoolean(KEY_ENABLED, true).apply();
        }
        return stored;
    }

    public static String getLastLoadError() {
        return lastLoadError == null ? "" : lastLoadError;
    }

    public static void clear(Context context) {
        prefs(context).edit().clear().apply();
    }

    private static String encrypt(String plain) throws Exception {
        SecretKey key = getOrCreateKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = cipher.getIV();
        byte[] encrypted = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(iv, Base64.NO_WRAP) + "." + Base64.encodeToString(encrypted, Base64.NO_WRAP);
    }

    private static String decrypt(String packed) throws Exception {
        if (packed == null || packed.isEmpty()) return null;
        int dot = packed.indexOf('.');
        if (dot <= 0 || dot >= packed.length() - 1) return null;
        byte[] iv = Base64.decode(packed.substring(0, dot), Base64.NO_WRAP);
        byte[] encrypted = Base64.decode(packed.substring(dot + 1), Base64.NO_WRAP);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
    }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            return (SecretKey) ks.getKey(KEY_ALIAS, null);
        }

        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build();
        generator.init(spec);
        return generator.generateKey();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.PowerManager;

import java.util.concurrent.atomic.AtomicBoolean;

/** Shared background-only automatic refresh work used by both AlarmManager and JobScheduler. */
public final class AutoRefreshWorker {
    private AutoRefreshWorker() {}

    public interface Completion {
        void onComplete();
    }

    public static void run(Context context, Completion completion) {
        Context app = context.getApplicationContext();
        final AtomicBoolean finished = new AtomicBoolean(false);
        final PowerManager.WakeLock wakeLock = acquireWakeLock(app);

        final Runnable finish = () -> {
            if (!finished.compareAndSet(false, true)) return;
            try {
                if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            } catch (Throwable ignored) {
            }
            try {
                if (completion != null) completion.onComplete();
            } catch (Throwable ignored) {
            }
        };

        if (HiddenWebViewRefresher.isRunning()
                || FastUsageRefresher.isRunning()
                || FastAutoLogin.isRunning()) {
            AutoRefreshScheduler.noteAttempt(app, false, "BUSY");
            finish.run();
            return;
        }

        // A successful manual refresh learns the small authenticated usage endpoint. Automatic
        // refresh deliberately stays background-only and never opens the transparent Activity.
        if (!FastUsageRefresher.shouldTry(app)) {
            AutoRefreshScheduler.noteAttempt(app, false, "NO_ENDPOINT");
            finish.run();
            return;
        }

        FastUsageRefresher.refreshBackgroundAsync(app, (success, detail) -> {
            if (success) {
                AutoRefreshScheduler.noteAttempt(app, true, "FAST");
                finish.run();
                return;
            }

            if (FastAutoLogin.shouldAttempt(app, detail)) {
                FastAutoLogin.refreshBackgroundAsync(app, detail, (loginSuccess, loginDetail) -> {
                    AutoRefreshScheduler.noteAttempt(app, loginSuccess,
                            loginSuccess ? "AUTO_LOGIN" : loginDetail);
                    finish.run();
                });
            } else {
                AutoRefreshScheduler.noteAttempt(app, false, detail);
                finish.run();
            }
        });
    }

    private static PowerManager.WakeLock acquireWakeLock(Context context) {
        try {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm == null) return null;
            PowerManager.WakeLock lock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "EyesMobileWidget:AutoRefresh");
            lock.setReferenceCounted(false);
            lock.acquire(35_000L);
            return lock;
        } catch (Throwable ignored) {
            return null;
        }
    }
}

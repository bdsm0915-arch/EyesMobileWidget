package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;

import java.util.concurrent.atomic.AtomicBoolean;

/** Shared background-only automatic refresh work used by both AlarmManager and JobScheduler. */
public final class AutoRefreshWorker {
    private AutoRefreshWorker() {}

    public interface Completion {
        void onComplete();
    }

    public static void run(Context context, Completion completion) {
        Context app = context.getApplicationContext();
        final AtomicBoolean finished = new AtomicBoolean(false);
        final PowerManager.WakeLock wakeLock = acquireWakeLock(app);

        final Runnable finish = () -> {
            if (!finished.compareAndSet(false, true)) return;
            try {
                if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            } catch (Throwable ignored) {
            }
            try {
                if (completion != null) completion.onComplete();
            } catch (Throwable ignored) {
            }
        };

        if (HiddenWebViewRefresher.isRunning()
                || FastUsageRefresher.isRunning()
                || FastAutoLogin.isRunning()) {
            AutoRefreshScheduler.noteAttempt(app, false, "BUSY");
            finish.run();
            return;
        }

        // v5.8: the scheduler may be healthy even when the small direct usage endpoint has never
        // been learned. v5.7 reported NO_ENDPOINT and stopped, so the alarm fired correctly but
        // the widget could never change. Fall back to the existing off-screen WebView instead.
        // It can update the widget directly and may also learn/verify the endpoint for future fast
        // cycles. No Activity or visible UI is opened.
        if (!FastUsageRefresher.shouldTry(app)) {
            runWebFallback(app, finish, "NO_ENDPOINT", 0);
            return;
        }

        FastUsageRefresher.refreshBackgroundAsync(app, (success, detail) -> {
            if (success) {
                AutoRefreshScheduler.noteAttempt(app, true, "FAST");
                finish.run();
                return;
            }

            if (FastAutoLogin.shouldAttempt(app, detail)) {
                FastAutoLogin.refreshBackgroundAsync(app, detail, (loginSuccess, loginDetail) -> {
                    if (loginSuccess) {
                        AutoRefreshScheduler.noteAttempt(app, true, "AUTO_LOGIN");
                        finish.run();
                    } else {
                        // HTTP login can be rejected or lack enough context on some EyesMobile
                        // sessions. Give the browser path one final silent chance before failing.
                        runWebFallback(app, finish, loginDetail, 0);
                    }
                });
            } else {
                // A learned endpoint can become stale when EyesMobile changes its page/API. The
                // browser fallback both refreshes the widget and gets another chance to observe it.
                runWebFallback(app, finish, detail, 0);
            }
        });
    }

    private static void runWebFallback(Context app, Runnable finish, String priorDetail, int attempt) {
        final long before = WidgetStorage.load(app).updatedAt;
        HiddenWebViewRefresher.refreshBackground(app, () -> {
            long after = WidgetStorage.load(app).updatedAt;
            boolean success = after > before;
            if (success) {
                AutoRefreshScheduler.noteAttempt(app, true, attempt > 0 ? "WEB_RETRY" : "WEB");
                finish.run();
                return;
            }

            // v5.9: a WebView auto-refresh can occasionally reach MyPage before EyesMobile's
            // async usage request has populated the DOM. This was visible as one successful cycle
            // followed by WEB_NO_UPDATE on the next one. When the session was verified recently,
            // wait briefly and give a brand-new off-screen WebView one more chance. Avoid doing
            // this on a stale session so we do not submit a second login unnecessarily.
            long verifiedAge = VerifiedSessionStore.ageMillis(app);
            boolean recentlyVerified = verifiedAge >= 0L && verifiedAge < 30L * 60L * 1000L;
            if (attempt == 0 && recentlyVerified) {
                SessionCookieStore.flush();
                new Handler(Looper.getMainLooper()).postDelayed(
                        () -> runWebFallback(app, finish, priorDetail, 1), 900L);
                return;
            }

            String prefix = attempt > 0 ? "WEB_RETRY_NO_UPDATE" : "WEB_NO_UPDATE";
            String detail = priorDetail == null || priorDetail.trim().isEmpty()
                    ? prefix : prefix + "|" + priorDetail;
            AutoRefreshScheduler.noteAttempt(app, false, detail);
            finish.run();
        });
    }

    private static PowerManager.WakeLock acquireWakeLock(Context context) {
        try {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm == null) return null;
            PowerManager.WakeLock lock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "EyesMobileWidget:AutoRefresh");
            lock.setReferenceCounted(false);
            lock.acquire(55_000L);
            return lock;
        } catch (Throwable ignored) {
            return null;
        }
    }
}

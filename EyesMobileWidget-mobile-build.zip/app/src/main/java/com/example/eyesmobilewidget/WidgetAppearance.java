package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

public final class WidgetAppearance {
    private static final String PREF = "eyes_widget_appearance";
    private static final String KEY_DARK = "dark_v14";
    private static final String KEY_TRANSPARENCY = "transparency_v14";
    private static final String KEY_TEXT = "text_color_v14";

    private WidgetAppearance() {}

    public static boolean isDark(Context context) {
        return prefs(context).getBoolean(KEY_DARK, false);
    }

    public static void setDark(Context context, boolean dark) {
        prefs(context).edit().putBoolean(KEY_DARK, dark).apply();
    }

    public static int getTransparency(Context context) {
        return clamp(prefs(context).getInt(KEY_TRANSPARENCY, 0), 0, 60);
    }

    public static void setTransparency(Context context, int value) {
        prefs(context).edit().putInt(KEY_TRANSPARENCY, clamp(value, 0, 60)).apply();
    }

    public static int getTextColor(Context context) {
        SharedPreferences p = prefs(context);
        if (p.contains(KEY_TEXT)) return p.getInt(KEY_TEXT, Color.rgb(27, 22, 52));
        return isDark(context) ? Color.WHITE : Color.rgb(27, 22, 52);
    }

    public static void setTextColor(Context context, int color) {
        prefs(context).edit().putInt(KEY_TEXT, color).apply();
    }

    public static int getSurfaceColor(Context context) {
        return isDark(context) ? Color.rgb(17, 20, 31) : Color.rgb(246, 241, 255);
    }

    public static int getCardColor(Context context) {
        return isDark(context) ? Color.rgb(28, 31, 45) : Color.rgb(252, 251, 255);
    }

    public static int getTrackColor(Context context) {
        return isDark(context) ? Color.rgb(63, 67, 84) : Color.rgb(226, 222, 244);
    }

    public static int getAccentColor() {
        return Color.rgb(126, 103, 248);
    }

    public static int getBodyColor(Context context) {
        int base = getSurfaceColor(context);
        int transparency = getTransparency(context);
        int alpha = Math.round(255f * (100 - transparency) / 100f);
        return Color.argb(alpha, Color.red(base), Color.green(base), Color.blue(base));
    }

    public static int getDefaultTextColor(Context context) {
        return isDark(context) ? Color.WHITE : Color.rgb(27, 22, 52);
    }

    public static int[] colorChoices() {
        return new int[]{
                Color.rgb(27, 22, 52),
                Color.BLACK,
                Color.WHITE,
                Color.rgb(126, 103, 248),
                Color.rgb(137, 83, 211),
                Color.rgb(92, 91, 112),
                Color.rgb(45, 79, 173),
                Color.rgb(245, 0, 115)
        };
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}

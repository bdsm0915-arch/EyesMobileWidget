package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

public final class WidgetAppearance {
    private static final String PREF = "eyes_widget_appearance";
    private static final String KEY_DARK = "dark";
    private static final String KEY_TRANSPARENCY = "transparency";
    private static final String KEY_TEXT = "text_color";

    private WidgetAppearance() {}

    public static boolean isDark(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(KEY_DARK, false);
    }

    public static void setDark(Context context, boolean dark) {
        prefs(context).edit().putBoolean(KEY_DARK, dark).apply();
    }

    public static int getTransparency(Context context) {
        return clamp(prefs(context).getInt(KEY_TRANSPARENCY, 0), 0, 80);
    }

    public static void setTransparency(Context context, int value) {
        prefs(context).edit().putInt(KEY_TRANSPARENCY, clamp(value, 0, 80)).apply();
    }

    public static int getTextColor(Context context) {
        SharedPreferences p = prefs(context);
        if (p.contains(KEY_TEXT)) return p.getInt(KEY_TEXT, Color.BLACK);
        return isDark(context) ? Color.WHITE : Color.rgb(20,20,20);
    }

    public static void setTextColor(Context context, int color) {
        prefs(context).edit().putInt(KEY_TEXT, color).apply();
    }

    public static int getBodyColor(Context context) {
        boolean dark = isDark(context);
        int base = dark ? Color.rgb(13,22,35) : Color.WHITE;
        int transparency = getTransparency(context);
        int alpha = Math.round(255f * (100 - transparency) / 100f);
        return Color.argb(alpha, Color.red(base), Color.green(base), Color.blue(base));
    }

    public static int getTrackColor(Context context) {
        return isDark(context) ? Color.rgb(54,64,78) : Color.rgb(232,233,237);
    }

    public static int getDefaultTextColor(Context context) {
        return isDark(context) ? Color.WHITE : Color.rgb(20,20,20);
    }

    public static int[] colorChoices() {
        return new int[]{
                Color.WHITE,
                Color.BLACK,
                Color.rgb(255,129,148),
                Color.rgb(255,183,118),
                Color.rgb(162,208,130),
                Color.rgb(45,79,173),
                Color.rgb(137,83,211),
                Color.rgb(245,0,115)
        };
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}

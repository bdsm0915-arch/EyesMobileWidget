package com.example.eyesmobilewidget;

import android.net.Uri;
import android.webkit.WebView;

/** Opens EyesMobile's actual usage/MyPage view without repeatedly reloading the same route. */
public final class UsagePageNavigator {
    private UsagePageNavigator() {}

    public interface Callback {
        void onResult(boolean navigated, String detail);
    }

    public static void tryOpen(WebView webView, Callback callback) {
        if (webView == null) {
            if (callback != null) callback.onResult(false, "NO_WEBVIEW");
            return;
        }

        String current = null;
        try { current = webView.getUrl(); } catch (Throwable ignored) {}
        final boolean alreadyMyPage = isMyPageMain(current);

        // v6.3: after a fresh login EyesMobile can land on /mypage/main without actually
        // firing the usage XHR. The old navigator returned immediately just because the URL
        // already matched MyPage, leaving a fully authenticated page with no usage values.
        // Always inspect/click the real "사용량조회" control once; on SPA-style handlers the
        // click is the event that starts the usage request even when href is the same URL.
        String js = "(function(){try{" +
                "var els=document.querySelectorAll('a,button,[role=button],[onclick]');" +
                "var best=null;" +
                "for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').replace(/\\s/g,'');" +
                "if(t==='사용량조회'||t.indexOf('사용량조회')>=0){best=e;break;}}" +
                "if(!best)return 'NOT_FOUND';" +
                "var href=best.href||best.getAttribute('href')||'';" +
                "if(href&&href!=='#'&&!/^javascript:/i.test(href))return 'HREF:'+href;" +
                "best.click();return 'CLICKED';" +
                "}catch(e){return 'ERROR:'+e;}})()";

        try {
            webView.evaluateJavascript(js, raw -> {
                String r = decode(raw);
                if (r != null && r.startsWith("HREF:")) {
                    String href = r.substring(5);
                    if (isMyPageMain(href) && isMyPageMain(safeUrl(webView))) {
                        // Same-route usage shortcuts can still have click handlers that launch
                        // the actual usage fetch. Invoke the control instead of short-circuiting.
                        String clickSame = "(function(){try{var es=document.querySelectorAll('a,button,[role=button],[onclick]');for(var i=0;i<es.length;i++){var e=es[i],t=(e.innerText||e.textContent||'').replace(/\\s/g,'');if(t==='사용량조회'||t.indexOf('사용량조회')>=0){e.click();return 'CLICKED_SAME';}}return 'NOT_FOUND_SAME';}catch(x){return 'ERROR_SAME';}})()";
                        try {
                            webView.evaluateJavascript(clickSame, ignored -> {
                                if (callback != null) callback.onResult(true, "CLICKED_SAME_ROUTE");
                            });
                        } catch (Throwable t) {
                            if (callback != null) callback.onResult(false, "ALREADY_MY_PAGE");
                        }
                        return;
                    }
                    try {
                        webView.loadUrl(href);
                        if (callback != null) callback.onResult(true, "NAVIGATE:" + href);
                    } catch (Throwable t) {
                        if (callback != null) callback.onResult(false, "LOAD_ERROR");
                    }
                    return;
                }
                boolean ok = "CLICKED".equals(r);
                if (!ok && alreadyMyPage && "NOT_FOUND".equals(r)) {
                    // MyPage itself may auto-load usage even when no shortcut is rendered. Keep
                    // polling rather than treating the authenticated route as a navigation error.
                    if (callback != null) callback.onResult(false, "ALREADY_MY_PAGE_NO_CONTROL");
                    return;
                }
                if (callback != null) callback.onResult(ok, r == null ? "" : r);
            });
        } catch (Throwable t) {
            if (callback != null) callback.onResult(false, "ERROR");
        }
    }

    private static String safeUrl(WebView webView) {
        try { return webView == null ? null : webView.getUrl(); } catch (Throwable t) { return null; }
    }

    private static boolean isMyPageMain(String url) {
        if (url == null || url.trim().isEmpty()) return false;
        try {
            Uri u = Uri.parse(url);
            String host = u.getHost();
            String path = u.getPath();
            return host != null && (host.equalsIgnoreCase("eyes.co.kr") || host.equalsIgnoreCase("www.eyes.co.kr"))
                    && path != null && (path.equals("/mypage/main") || path.equals("/mypage/main/"));
        } catch (Throwable t) {
            return url.contains("/mypage/main");
        }
    }

    private static String decode(String value) {
        if (value == null || "null".equals(value)) return null;
        if (value.startsWith("\"") && value.endsWith("\"")) value = value.substring(1, value.length() - 1);
        return value.replace("\\\"", "\"").replace("\\\\", "\\");
    }
}

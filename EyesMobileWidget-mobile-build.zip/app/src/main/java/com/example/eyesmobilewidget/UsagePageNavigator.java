package com.example.eyesmobilewidget;

import android.net.Uri;
import android.webkit.WebView;

/** Opens EyesMobile's actual usage/MyPage view without repeatedly reloading the same route. */
public final class UsagePageNavigator {
    private UsagePageNavigator() {}

    public interface Callback {
        void onResult(boolean navigated, String detail);
    }

    public static void tryOpen(WebView webView, Callback callback) {
        if (webView == null) {
            if (callback != null) callback.onResult(false, "NO_WEBVIEW");
            return;
        }

        String current = null;
        try { current = webView.getUrl(); } catch (Throwable ignored) {}
        if (isMyPageMain(current)) {
            // The site's "사용량조회" shortcut itself points here. Usage values arrive later
            // through page JavaScript, so reloading the same URL only restarts that request.
            if (callback != null) callback.onResult(true, "ALREADY_MY_PAGE");
            return;
        }

        String js = "(function(){try{" +
                "var els=document.querySelectorAll('a,button,[role=button],[onclick]');" +
                "var best=null;" +
                "for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').replace(/\\s/g,'');" +
                "if(t==='사용량조회'||t.indexOf('사용량조회')>=0){best=e;break;}}" +
                "if(!best)return 'NOT_FOUND';" +
                "var href=best.href||best.getAttribute('href')||'';" +
                "if(href&&href!=='#'&&!/^javascript:/i.test(href))return 'HREF:'+href;" +
                "best.click();return 'CLICKED';" +
                "}catch(e){return 'ERROR:'+e;}})()";

        try {
            webView.evaluateJavascript(js, raw -> {
                String r = decode(raw);
                if (r != null && r.startsWith("HREF:")) {
                    String href = r.substring(5);
                    if (isMyPageMain(href) && isMyPageMain(safeUrl(webView))) {
                        if (callback != null) callback.onResult(true, "ALREADY_MY_PAGE");
                        return;
                    }
                    try {
                        webView.loadUrl(href);
                        if (callback != null) callback.onResult(true, "NAVIGATE:" + href);
                    } catch (Throwable t) {
                        if (callback != null) callback.onResult(false, "LOAD_ERROR");
                    }
                    return;
                }
                boolean ok = "CLICKED".equals(r);
                if (callback != null) callback.onResult(ok, r == null ? "" : r);
            });
        } catch (Throwable t) {
            if (callback != null) callback.onResult(false, "ERROR");
        }
    }

    private static String safeUrl(WebView webView) {
        try { return webView == null ? null : webView.getUrl(); } catch (Throwable t) { return null; }
    }

    private static boolean isMyPageMain(String url) {
        if (url == null || url.trim().isEmpty()) return false;
        try {
            Uri u = Uri.parse(url);
            String host = u.getHost();
            String path = u.getPath();
            return host != null && (host.equalsIgnoreCase("eyes.co.kr") || host.equalsIgnoreCase("www.eyes.co.kr"))
                    && path != null && (path.equals("/mypage/main") || path.equals("/mypage/main/"));
        } catch (Throwable t) {
            return url.contains("/mypage/main");
        }
    }

    private static String decode(String value) {
        if (value == null || "null".equals(value)) return null;
        if (value.startsWith("\"") && value.endsWith("\"")) value = value.substring(1, value.length() - 1);
        return value.replace("\\\"", "\"").replace("\\\\", "\\");
    }
}

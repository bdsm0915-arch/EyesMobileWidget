package com.example.eyesmobilewidget;

import android.webkit.WebView;

/** Opens EyesMobile's actual "사용량조회" page from the logged-in MyPage shell. */
public final class UsagePageNavigator {
    private UsagePageNavigator() {}

    public interface Callback {
        void onResult(boolean navigated, String detail);
    }

    public static void tryOpen(WebView webView, Callback callback) {
        if (webView == null) {
            if (callback != null) callback.onResult(false, "NO_WEBVIEW");
            return;
        }

        String js = "(function(){try{" +
                "var els=document.querySelectorAll('a,button,[role=button],[onclick]');" +
                "var best=null;" +
                "for(var i=0;i<els.length;i++){var e=els[i];var t=(e.innerText||e.textContent||'').replace(/\\s/g,'');" +
                "if(t==='사용량조회'||t.indexOf('사용량조회')>=0){best=e;break;}}" +
                "if(!best)return 'NOT_FOUND';" +
                "var href=best.href||best.getAttribute('href')||'';" +
                "if(href&&href!=='#'&&!/^javascript:/i.test(href)){location.href=href;return 'NAVIGATE:'+href;}" +
                "best.click();return 'CLICKED';" +
                "}catch(e){return 'ERROR:'+e;}})()";

        try {
            webView.evaluateJavascript(js, raw -> {
                String r = decode(raw);
                boolean ok = r != null && (r.startsWith("NAVIGATE:") || r.startsWith("CLICKED"));
                if (callback != null) callback.onResult(ok, r == null ? "" : r);
            });
        } catch (Throwable t) {
            if (callback != null) callback.onResult(false, "ERROR");
        }
    }

    private static String decode(String value) {
        if (value == null || "null".equals(value)) return null;
        if (value.startsWith("\"") && value.endsWith("\"")) value = value.substring(1, value.length() - 1);
        return value.replace("\\\"", "\"").replace("\\\\", "\\");
    }
}

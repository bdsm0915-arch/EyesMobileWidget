package com.example.eyesmobilewidget;

import android.content.Context;
import android.text.Html;
import android.webkit.CookieManager;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class EyesMobileFetcher {
    public static final String MY_PAGE_URL = "https://www.eyes.co.kr/mypage/main";
    private static final int MAX_REDIRECTS = 5;

    private EyesMobileFetcher() {}

    public static boolean refresh(Context context) {
        SessionCookieStore.restoreIfMissing(context);
        String initialCookies = SessionCookieStore.currentCookieHeader(context, MY_PAGE_URL);
        if (initialCookies == null || initialCookies.trim().isEmpty()) {
            WidgetStorage.setStatus(context, "앱을 열어 로그인하세요");
            return false;
        }

        Map<String, String> cookieJar = parseCookieHeader(initialCookies);
        List<PendingCookie> pendingCookies = new ArrayList<>();
        String userAgent = SessionCookieStore.getUserAgent(context);
        String currentUrl = MY_PAGE_URL;

        try {
            for (int redirect = 0; redirect <= MAX_REDIRECTS; redirect++) {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(currentUrl);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setInstanceFollowRedirects(false);
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(15000);
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Cookie", buildCookieHeader(cookieJar));
                    conn.setRequestProperty("User-Agent", userAgent);
                    conn.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en;q=0.7");
                    conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
                    conn.setRequestProperty("Cache-Control", "no-cache");
                    conn.setRequestProperty("Pragma", "no-cache");

                    int code = conn.getResponseCode();
                    collectSetCookies(conn, currentUrl, cookieJar, pendingCookies);

                    if (code >= 300 && code < 400) {
                        String location = conn.getHeaderField("Location");
                        if (location == null || location.trim().isEmpty()) {
                            WidgetStorage.setStatus(context, "조회 실패 (리다이렉트 오류)");
                            return false;
                        }
                        currentUrl = new URL(url, location).toString();
                        continue;
                    }

                    if (code < 200 || code >= 400) {
                        WidgetStorage.setStatus(context, "조회 실패 (HTTP " + code + ")");
                        return false;
                    }

                    String html = readAll(conn.getInputStream());
                    String text;
                    if (android.os.Build.VERSION.SDK_INT >= 24) {
                        text = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString();
                    } else {
                        text = Html.fromHtml(html).toString();
                    }

                    UsageData data = UsageParser.parse(text);
                    if (data == null) {
                        // Do not import cookies from a login/error page into WebView.
                        // This prevents a failed background refresh from overwriting a still-valid login session.
                        WidgetStorage.setStatus(context, "로그인 세션 확인 필요");
                        return false;
                    }

                    commitCookies(context, pendingCookies);
                    WidgetStorage.save(context, data);
                    SessionCookieStore.backup(context);
                    return true;
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }

            WidgetStorage.setStatus(context, "조회 실패 (리다이렉트 초과)");
            return false;
        } catch (Exception e) {
            WidgetStorage.setStatus(context, "새로고침 실패");
            return false;
        }
    }

    private static void collectSetCookies(HttpURLConnection conn,
                                          String requestUrl,
                                          Map<String, String> cookieJar,
                                          List<PendingCookie> pendingCookies) {
        Map<String, List<String>> headers = conn.getHeaderFields();
        if (headers == null) return;

        for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
            String key = entry.getKey();
            if (key == null || !"set-cookie".equals(key.toLowerCase(Locale.ROOT))) continue;
            List<String> values = entry.getValue();
            if (values == null) continue;

            for (String setCookie : values) {
                if (setCookie == null || setCookie.trim().isEmpty()) continue;
                pendingCookies.add(new PendingCookie(requestUrl, setCookie));
                mergeSetCookie(cookieJar, setCookie);
            }
        }
    }

    private static void mergeSetCookie(Map<String, String> jar, String setCookie) {
        String first = setCookie.split(";", 2)[0].trim();
        int eq = first.indexOf('=');
        if (eq <= 0) return;
        String name = first.substring(0, eq).trim();
        String value = first.substring(eq + 1).trim();
        String lower = setCookie.toLowerCase(Locale.ROOT);
        boolean delete = value.isEmpty() || lower.contains("max-age=0");
        if (delete) jar.remove(name);
        else jar.put(name, value);
    }

    private static Map<String, String> parseCookieHeader(String header) {
        Map<String, String> jar = new LinkedHashMap<>();
        if (header == null) return jar;
        for (String pair : header.split(";")) {
            String p = pair.trim();
            int eq = p.indexOf('=');
            if (eq <= 0) continue;
            String name = p.substring(0, eq).trim();
            String value = p.substring(eq + 1).trim();
            if (!name.isEmpty()) jar.put(name, value);
        }
        return jar;
    }

    private static String buildCookieHeader(Map<String, String> jar) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : jar.entrySet()) {
            if (sb.length() > 0) sb.append("; ");
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        return sb.toString();
    }

    private static void commitCookies(Context context, List<PendingCookie> pendingCookies) {
        if (pendingCookies.isEmpty()) return;
        try {
            CookieManager cm = CookieManager.getInstance();
            for (PendingCookie cookie : pendingCookies) {
                cm.setCookie(cookie.url, cookie.setCookie);
            }
            cm.flush();
            SessionCookieStore.backup(context);
        } catch (Exception ignored) {
        }
    }

    private static String readAll(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private static final class PendingCookie {
        final String url;
        final String setCookie;

        PendingCookie(String url, String setCookie) {
            this.url = url;
            this.setCookie = setCookie;
        }
    }
}

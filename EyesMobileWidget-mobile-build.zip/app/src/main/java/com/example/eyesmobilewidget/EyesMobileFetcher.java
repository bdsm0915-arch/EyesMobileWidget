package com.example.eyesmobilewidget;

import android.content.Context;
import android.text.Html;
import android.webkit.CookieManager;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public final class EyesMobileFetcher {
    public static final String MY_PAGE_URL = "https://www.eyes.co.kr/mypage/main";

    private EyesMobileFetcher() {}

    public static boolean refresh(Context context) {
        HttpURLConnection conn = null;
        try {
            CookieManager cm = CookieManager.getInstance();
            SessionCookieStore.restore(context);
            String cookies = SessionCookieStore.currentCookieHeader(context, MY_PAGE_URL);
            if (cookies == null || cookies.trim().isEmpty()) {
                WidgetStorage.setStatus(context, "앱을 열어 로그인하세요");
                return false;
            }

            URL url = new URL(MY_PAGE_URL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(15000);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Cookie", cookies);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36");
            conn.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en;q=0.7");
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");

            int code = conn.getResponseCode();
            if (code < 200 || code >= 400) {
                WidgetStorage.setStatus(context, "조회 실패 (HTTP " + code + ")");
                return false;
            }

            Map<String, List<String>> headers = conn.getHeaderFields();
            List<String> setCookies = headers.get("Set-Cookie");
            if (setCookies != null) {
                for (String c : setCookies) {
                    cm.setCookie(MY_PAGE_URL, c);
                    cm.setCookie("https://www.eyes.co.kr/", c);
                }
                cm.flush();
                SessionCookieStore.backup(context);
            }

            String html = readAll(conn.getInputStream());
            String text;
            if (android.os.Build.VERSION.SDK_INT >= 24) {
                text = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString();
            } else {
                // minSdk is 24; retained only for source clarity.
                text = Html.fromHtml(html).toString();
            }

            UsageData data = UsageParser.parse(text);
            if (data == null) {
                WidgetStorage.setStatus(context, "로그인/사용량 페이지 확인 필요");
                return false;
            }

            WidgetStorage.save(context, data);
            SessionCookieStore.backup(context);
            return true;
        } catch (Exception e) {
            WidgetStorage.setStatus(context, "새로고침 실패");
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String readAll(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Performs a widget refresh with an off-screen WebView so the user's Activity
 * never opens. It uses the same WebView cookie jar as MainActivity.
 */
public final class HiddenWebViewRefresher {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    private static WebView activeWebView;

    private HiddenWebViewRefresher() {}

    public static void refresh(Context context, android.content.BroadcastReceiver.PendingResult pendingResult) {
        final Context app = context.getApplicationContext();

        if (!RUNNING.compareAndSet(false, true)) {
            if (pendingResult != null) pendingResult.finish();
            return;
        }

        WidgetStorage.setStatus(app, "새로고침 중…");
        EyesMobileWidgetProvider.updateAll(app);

        MAIN.post(() -> start(app, pendingResult));
    }

    private static void start(Context app, android.content.BroadcastReceiver.PendingResult pendingResult) {
        final AtomicBoolean finished = new AtomicBoolean(false);
        final boolean[] recoveryAttempted = {false};
        final int[] parseAttempts = {0};

        final Runnable timeout = () -> finish(app, pendingResult, finished,
                "새로고침 시간 초과", false);
        MAIN.postDelayed(timeout, 9500L);

        try {
            SessionCookieStore.restoreIfMissing(app);
            CookieManager.getInstance().setAcceptCookie(true);

            WebView webView = new WebView(app);
            activeWebView = webView;

            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setLoadWithOverviewMode(false);
            settings.setUseWideViewPort(false);
            settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

            String storedUa = SessionCookieStore.getUserAgent(app);
            if (storedUa != null && !storedUa.trim().isEmpty()) {
                settings.setUserAgentString(storedUa);
            } else {
                SessionCookieStore.saveUserAgent(app, settings.getUserAgentString());
            }

            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    if (finished.get()) return;
                    MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                            recoveryAttempted, parseAttempts, timeout), 1000L);
                }
            });

            webView.loadUrl(EyesMobileFetcher.MY_PAGE_URL);
        } catch (Throwable t) {
            MAIN.removeCallbacks(timeout);
            finish(app, pendingResult, finished, "새로고침 실패", false);
        }
    }

    private static void capture(WebView view,
                                Context app,
                                android.content.BroadcastReceiver.PendingResult pendingResult,
                                AtomicBoolean finished,
                                boolean[] recoveryAttempted,
                                int[] parseAttempts,
                                Runnable timeout) {
        if (finished.get() || view == null) return;

        view.evaluateJavascript(
                "(function(){try{return document.body ? document.body.innerText : '';}catch(e){return '';}})()",
                value -> {
                    if (finished.get()) return;
                    String text = decodeJsString(value);
                    UsageData data = UsageParser.parse(text);

                    if (data != null) {
                        SessionCookieStore.backup(app);
                        WidgetStorage.save(app, data);
                        EyesMobileWidgetProvider.updateAll(app);
                        MAIN.removeCallbacks(timeout);
                        finish(app, pendingResult, finished, null, true);
                        return;
                    }

                    if (!recoveryAttempted[0] && looksLoggedOut(text)
                            && SessionCookieStore.hasBackup(app)) {
                        recoveryAttempted[0] = true;
                        SessionCookieStore.forceRestoreBackup(app);
                        MAIN.postDelayed(() -> {
                            if (!finished.get() && activeWebView != null) {
                                activeWebView.loadUrl(EyesMobileFetcher.MY_PAGE_URL);
                            }
                        }, 400L);
                        return;
                    }

                    // Some usage values are painted by page JavaScript after onPageFinished.
                    // Give the page one extra chance before declaring failure.
                    if (!looksLoggedOut(text) && parseAttempts[0]++ < 1) {
                        MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                                recoveryAttempted, parseAttempts, timeout), 1400L);
                        return;
                    }

                    MAIN.removeCallbacks(timeout);
                    if (looksLoggedOut(text)) {
                        finish(app, pendingResult, finished,
                                "로그인 필요 · 톱니바퀴에서 로그인하세요", false);
                    } else {
                        finish(app, pendingResult, finished,
                                "사용량을 읽지 못했습니다", false);
                    }
                });
    }

    private static void finish(Context app,
                               android.content.BroadcastReceiver.PendingResult pendingResult,
                               AtomicBoolean finished,
                               String status,
                               boolean success) {
        if (!finished.compareAndSet(false, true)) return;

        try {
            if (!success && status != null) WidgetStorage.setStatus(app, status);
            EyesMobileWidgetProvider.updateAll(app);
        } catch (Throwable ignored) {
        }

        try {
            if (activeWebView != null) {
                activeWebView.stopLoading();
                activeWebView.setWebViewClient(null);
                activeWebView.destroy();
            }
        } catch (Throwable ignored) {
        } finally {
            activeWebView = null;
            RUNNING.set(false);
            if (pendingResult != null) pendingResult.finish();
        }
    }

    private static boolean looksLoggedOut(String text) {
        if (text == null) return false;
        String t = text.toLowerCase(Locale.ROOT);
        return t.contains("로그인")
                && (t.contains("비밀번호") || t.contains("아이디") || t.contains("회원가입"));
    }

    private static String decodeJsString(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            if (value.startsWith("\"") && value.endsWith("\"")) {
                value = value.substring(1, value.length() - 1);
            }
            return value.replace("\\n", "\n")
                    .replace("\\r", "\r")
                    .replace("\\t", "\t")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\u003C", "<")
                    .replace("\\u003E", ">");
        } catch (Exception e) {
            return value;
        }
    }
}

package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Silent widget refresh.
 *
 * v3.1 keeps the one-tap login recovery flow while reducing normal refresh latency. After an expired session is recovered,
 * the old implementation waited a fixed delay and reloaded MyPage once. If the login request
 * was still rotating cookies at that exact moment, the refresh stopped at
 * "조회 중…" and the user's second tap became the first request
 * that actually used the new session.
 *
 * v2.9 treats login recovery as a small state machine:
 *  1) submit stored credentials,
 *  2) poll the off-screen WebView until the login page has really gone away,
 *  3) only then reload MyPage with the new session,
 *  4) navigate to the usage page and parse it,
 *  5) finish only after the widget has been updated (or a real error is reached).
 */
public final class HiddenWebViewRefresher {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    private static final int MAX_POST_LOGIN_POLLS = 18;
    private static final int MAX_FAST_USAGE_POLLS = 52;
    private static final int MAX_NORMAL_PARSE_ATTEMPTS = 36;
    private static final long STALE_SESSION_HINT_MS = 20L * 60L * 1000L;
    private static WebView activeWebView;
    private static volatile android.content.BroadcastReceiver.PendingResult activePendingResult;
    private static final AtomicBoolean CANCELLED = new AtomicBoolean(false);

    private HiddenWebViewRefresher() {}

    /** Exposed for WidgetRefreshJobService so the OS job stays alive until WebView work is done. */
    public static boolean isRunning() {
        return RUNNING.get();
    }

    public static void refresh(Context context, android.content.BroadcastReceiver.PendingResult pendingResult) {
        refresh(context, pendingResult, false);
    }

    public static void refresh(Context context,
                               android.content.BroadcastReceiver.PendingResult pendingResult,
                               boolean silent) {
        final Context app = context.getApplicationContext();
        if (!RUNNING.compareAndSet(false, true)) {
            if (pendingResult != null) pendingResult.finish();
            return;
        }
        CANCELLED.set(false);
        activePendingResult = pendingResult;

        if (!silent) {
            WidgetStorage.setStatus(app, "조회 중…");
            EyesMobileWidgetProvider.updateStatusOnly(app);
        }
        MAIN.post(() -> start(app, pendingResult, silent));
    }

    /** Cancels the hidden fallback when v3.5 direct HTTP has already produced fresh usage. */
    public static void cancelCurrentForFastSuccess() {
        CANCELLED.set(true);
        MAIN.removeCallbacksAndMessages(null);
        MAIN.post(() -> {
            try {
                if (activeWebView != null) {
                    activeWebView.stopLoading();
                    activeWebView.setWebViewClient(null);
                    activeWebView.destroy();
                }
            } catch (Throwable ignored) {
            } finally {
                activeWebView = null;
                RUNNING.set(false);
                android.content.BroadcastReceiver.PendingResult pending = activePendingResult;
                activePendingResult = null;
                if (pending != null) {
                    try { pending.finish(); } catch (Throwable ignored) {}
                }
            }
        });
    }

    private static void start(Context app,
                              android.content.BroadcastReceiver.PendingResult pendingResult,
                              boolean silent) {
        final AtomicBoolean finished = new AtomicBoolean(false);
        final boolean[] autoLoginAttempted = {false};
        final boolean[] usageNavigationAttempted = {false};
        final int[] parseAttempts = {0};
        final int[] fastUsagePolls = {0};
        final long verifiedAge = VerifiedSessionStore.ageMillis(app);
        final boolean[] likelyStaleSession = {AutoLoginHelper.hasCredentials(app)
                && (verifiedAge < 0L || verifiedAge >= STALE_SESSION_HINT_MS)};

        // v2.9 post-login state. While this is true, normal capture must not conclude
        // "login failed" just because the login request is still completing.
        final boolean[] postLoginPending = {false};
        final boolean[] postLoginProbeQueued = {false};
        final int[] postLoginPolls = {0};
        final boolean[] postLoginReloadIssued = {false};

        final Runnable timeout = () -> {
            if (CANCELLED.get()) return;
            finish(app, pendingResult, finished,
                    "새로고침 시간 초과 · 자동 로그인/사용량 조회 확인 필요", false, silent);
        };
        MAIN.postDelayed(timeout, likelyStaleSession[0] ? 10500L : 8200L);

        try {
            UsageEndpointStore.beginObservation();
            SessionCookieStore.migrateToLiveCookiePolicy(app);
            WebSessionStateStore.clear(app);
            CookieManager.getInstance().setAcceptCookie(true);
            // Do not revive an old missing session after a long idle period. If live WebView cookies
            // still work, they are kept; otherwise the page reaches login quickly and auto-login
            // creates a fresh server session instead of spending a round-trip on stale backup cookies.
            if (!likelyStaleSession[0]) {
                VerifiedSessionStore.restoreMissing(app);
            }
            SessionCookieStore.flush();

            WebView webView = new WebView(app);
            activeWebView = webView;
            prepareOffscreenViewport(webView);
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setLoadWithOverviewMode(true);
            settings.setUseWideViewPort(true);
            settings.setCacheMode(WebSettings.LOAD_DEFAULT);
            // Hidden refresh only needs DOM/JavaScript. Avoid waiting on image downloads.
            settings.setLoadsImagesAutomatically(false);
            settings.setBlockNetworkImage(true);

            String storedUa = SessionCookieStore.getUserAgent(app);
            if (storedUa != null && !storedUa.trim().isEmpty()) {
                settings.setUserAgentString(storedUa);
            } else {
                SessionCookieStore.saveUserAgent(app, settings.getUserAgentString());
            }
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
            webView.setWebChromeClient(new WebChromeClient());

            webView.setWebViewClient(new WebViewClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    try {
                        if (request != null && request.getUrl() != null) {
                            UsageEndpointStore.observe(request.getMethod(), request.getUrl().toString(),
                                    request.getRequestHeaders());
                        }
                    } catch (Throwable ignored) {}
                    return super.shouldInterceptRequest(view, request);
                }

                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    if (CANCELLED.get() || finished.get()) return;
                    prepareOffscreenViewport(view);
                    SessionCookieStore.flush();

                    if (postLoginPending[0]) {
                        // A page-finished event during login recovery is useful evidence, but
                        // do not let the normal parser race the session-establishment probe.
                        schedulePostLoginProbe(view, app, pendingResult, finished,
                                autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                                likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                                postLoginReloadIssued, timeout, silent, 90L);
                    } else {
                        MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                                autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                                likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                                postLoginReloadIssued, timeout, silent), 25L);
                    }
                }
            });

            UsageDomSnapshot.loadFresh(webView);

            // v3.3 fast path: do not wait for onPageFinished. EyesMobile can finish its
            // usage XHR/DOM update while trailing page resources are still loading. Probe only
            // for a successful usage parse; login/error decisions remain in the normal state
            // machine so partially-loaded pages cannot trigger a false re-login.
            scheduleFastUsageProbe(webView, app, pendingResult, finished, fastUsagePolls,
                    timeout, silent, 60L);
        } catch (Throwable t) {
            MAIN.removeCallbacks(timeout);
            finish(app, pendingResult, finished, "새로고침 실패", false, silent);
        }
    }

    private static void capture(WebView view,
                                Context app,
                                android.content.BroadcastReceiver.PendingResult pendingResult,
                                AtomicBoolean finished,
                                boolean[] autoLoginAttempted,
                                boolean[] usageNavigationAttempted,
                                int[] parseAttempts,
                                boolean[] likelyStaleSession,
                                boolean[] postLoginPending,
                                boolean[] postLoginProbeQueued,
                                int[] postLoginPolls,
                                boolean[] postLoginReloadIssued,
                                Runnable timeout,
                                boolean silent) {
        if (CANCELLED.get() || finished.get() || view == null) return;

        if (postLoginPending[0]) {
            schedulePostLoginProbe(view, app, pendingResult, finished,
                    autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                    likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                    postLoginReloadIssued, timeout, silent, 100L);
            return;
        }

        UsageDomSnapshot.capture(view, text -> {
            if (CANCELLED.get() || finished.get()) return;
            UsageData data = UsageParser.parse(text);
            if (data != null) {
                completeWithUsage(app, pendingResult, finished, data, timeout, silent);
                return;
            }

            // v4.8: a manual refresh now starts the tiny direct usage probe and this WebView
            // together. While the direct probe is still deciding whether the session is valid,
            // keep warming this page but do not submit credentials yet. This prevents a duplicate
            // login race and removes the old JobScheduler hand-off delay after logout detection.
            if (FastUsageRefresher.isRunning() && AutoLoginHelper.hasCredentials(app)) {
                MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                        autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                        likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                        postLoginReloadIssued, timeout, silent), 55L);
                return;
            }

            // v4.6: this WebView may have been pre-warmed while the 1-second HTTP auto-login
            // attempt is running. Keep loading the page, but never submit a second login in
            // parallel. The next capture continues immediately when the HTTP attempt ends.
            if (FastAutoLogin.isRunning()) {
                MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                        autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                        likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                        postLoginReloadIssued, timeout, silent), 80L);
                return;
            }

            // v4.7: direct HTTP login may already have created a fresh authenticated session
            // even when its tiny usage fetch missed the budget. Reuse those fresh cookies in the
            // already-warm WebView and reload MyPage once instead of logging in a second time.
            if (FastAutoLogin.consumeSessionReadyHint()) {
                restartRecoveryTimeout(timeout);
                likelyStaleSession[0] = false;
                usageNavigationAttempted[0] = false;
                parseAttempts[0] = 0;
                SessionCookieStore.flush();
                UsageDomSnapshot.loadFresh(view);
                MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                        autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                        likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                        postLoginReloadIssued, timeout, silent), 80L);
                return;
            }

            boolean loggedOut = looksLoggedOut(text);

            if (loggedOut && !autoLoginAttempted[0] && AutoLoginHelper.hasCredentials(app)) {
                VerifiedSessionStore.invalidate(app);
                autoLoginAttempted[0] = true;
                if (!silent) {
                    WidgetStorage.setStatus(app, "조회 중…");
                }
                attemptAutoLogin(view, app, pendingResult, finished, autoLoginAttempted,
                        usageNavigationAttempted, parseAttempts,
                        likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                        postLoginReloadIssued, timeout, silent);
                return;
            }

            if (!loggedOut && !usageNavigationAttempted[0]) {
                usageNavigationAttempted[0] = true;
                if (!silent) {
                    WidgetStorage.setStatus(app, "조회 중…");
                }
                // EyesMobile's public "사용량조회" link resolves to /mypage/main itself.
                // Do not keep re-navigating the same page: that can reset the site's async
                // usage request. Just make sure we are on MyPage and then poll its live DOM.
                UsagePageNavigator.tryOpen(view, (navigated, detail) -> {
                    if (CANCELLED.get() || finished.get()) return;
                    MAIN.postDelayed(() -> {
                        if (!finished.get() && activeWebView != null) {
                            capture(activeWebView, app, pendingResult, finished,
                                    autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                                    likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                                    postLoginReloadIssued, timeout, silent);
                        }
                    }, navigated ? 160L : 40L);
                });
                return;
            }

            // A real usage page is filled asynchronously. Give it time before deciding that a
            // hidden guest/login layer must be opened. This prevents a valid logged-in session
            // from being interrupted while the carrier usage API is still returning data.
            if (!loggedOut && parseAttempts[0] < MAX_NORMAL_PARSE_ATTEMPTS) {
                int attempt = ++parseAttempts[0];
                if (!silent && (attempt == 6 || attempt == 12)) {
                    WidgetStorage.setStatus(app, "조회 중…");
                }

                // v4.0 recovery probe: EyesMobile can expire the authenticated session without
                // leaving an obvious "로그인 필요" string in the captured DOM. In that case v3.6+
                // kept polling a guest shell and eventually ended with "사용량을 읽지 못했습니다".
                // After a few empty usage polls, ask the existing off-screen login helper to inspect
                // the real DOM once. If a login form/button is present it submits the stored account
                // and continues the same one-tap refresh flow. If no login UI exists, this was simply
                // a slow valid session, so resume usage polling without treating it as a login error.
                int recoveryProbeAt = likelyStaleSession[0] ? 2 : 6;
                if (attempt == recoveryProbeAt && !autoLoginAttempted[0]
                        && AutoLoginHelper.hasCredentials(app)) {
                    autoLoginAttempted[0] = true;
                    if (!silent) {
                        WidgetStorage.setStatus(app, "조회 중…");
                        EyesMobileWidgetProvider.updateStatusOnly(app);
                    }
                    prepareOffscreenViewport(view);
                    AutoLoginHelper.tryLoginOffscreen(app, view, (submitted, detail) -> {
                        if (CANCELLED.get() || finished.get()) return;
                        if (submitted) {
                            restartRecoveryTimeout(timeout);
                            usageNavigationAttempted[0] = false;
                            parseAttempts[0] = 0;
                            postLoginPending[0] = true;
                            postLoginPolls[0] = 0;
                            postLoginReloadIssued[0] = false;
                            likelyStaleSession[0] = false;
                            if (!silent) {
                                WidgetStorage.setStatus(app, "조회 중…");
                                EyesMobileWidgetProvider.updateStatusOnly(app);
                            }
                            schedulePostLoginProbe(view, app, pendingResult, finished,
                                    autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                                    likelyStaleSession, postLoginPending, postLoginProbeQueued,
                                    postLoginPolls, postLoginReloadIssued, timeout, silent, 100L);
                        } else {
                            // No login UI on the current page means the session may still be valid.
                            // Allow later explicit logged-out evidence to try auto-login normally.
                            autoLoginAttempted[0] = false;
                            MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                                    autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                                    likelyStaleSession, postLoginPending, postLoginProbeQueued,
                                    postLoginPolls, postLoginReloadIssued, timeout, silent), 150L);
                        }
                    });
                    return;
                }

                MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                        autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                        likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                        postLoginReloadIssued, timeout, silent), 150L);
                return;
            }

            MAIN.removeCallbacks(timeout);
            if (loggedOut) {
                finish(app, pendingResult, finished,
                        AutoLoginHelper.hasCredentials(app)
                                ? "자동 로그인 실패 · 앱에서 계정 확인"
                                : "로그인 만료 · 앱에서 자동로그인 설정",
                        false, silent);
            } else {
                finish(app, pendingResult, finished, "사용량을 읽지 못했습니다", false, silent);
            }
        });
    }

    private static void attemptAutoLogin(WebView view,
                                         Context app,
                                         android.content.BroadcastReceiver.PendingResult pendingResult,
                                         AtomicBoolean finished,
                                         boolean[] autoLoginAttempted,
                                         boolean[] usageNavigationAttempted,
                                         int[] parseAttempts,
                                         boolean[] likelyStaleSession,
                                         boolean[] postLoginPending,
                                         boolean[] postLoginProbeQueued,
                                         int[] postLoginPolls,
                                         boolean[] postLoginReloadIssued,
                                         Runnable timeout,
                                         boolean silent) {
        prepareOffscreenViewport(view);
        AutoLoginHelper.tryLoginOffscreen(app, view, (submitted, detail) -> {
            if (CANCELLED.get() || finished.get()) return;
            if (submitted) {
                restartRecoveryTimeout(timeout);
                usageNavigationAttempted[0] = false;
                parseAttempts[0] = 0;
                postLoginPending[0] = true;
                postLoginPolls[0] = 0;
                postLoginReloadIssued[0] = false;
                if (!silent) {
                    WidgetStorage.setStatus(app, "조회 중…");
                }

                // Do not guess a fixed number of seconds. Probe until the login UI actually
                // disappears, then continue to MyPage/usage parsing automatically.
                schedulePostLoginProbe(view, app, pendingResult, finished,
                        autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                        likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                        postLoginReloadIssued, timeout, silent, 100L);
                return;
            }

            if (detail != null && detail.startsWith("NO_LOGIN_UI")) {
                if (parseAttempts[0]++ < 2) {
                    MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                            autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                            likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                            postLoginReloadIssued, timeout, silent), 160L);
                    return;
                }
            }

            MAIN.removeCallbacks(timeout);
            String why = (detail == null || detail.trim().isEmpty()) ? "UNKNOWN" : detail;
            finish(app, pendingResult, finished,
                    "자동 로그인 실패 · " + why, false, silent);
        });
    }

    private static void schedulePostLoginProbe(WebView view,
                                               Context app,
                                               android.content.BroadcastReceiver.PendingResult pendingResult,
                                               AtomicBoolean finished,
                                               boolean[] autoLoginAttempted,
                                               boolean[] usageNavigationAttempted,
                                               int[] parseAttempts,
                                               boolean[] likelyStaleSession,
                                               boolean[] postLoginPending,
                                               boolean[] postLoginProbeQueued,
                                               int[] postLoginPolls,
                                               boolean[] postLoginReloadIssued,
                                               Runnable timeout,
                                               boolean silent,
                                               long delayMs) {
        if (CANCELLED.get() || finished.get() || !postLoginPending[0]) return;
        if (postLoginProbeQueued[0]) return;
        postLoginProbeQueued[0] = true;
        MAIN.postDelayed(() -> {
            postLoginProbeQueued[0] = false;
            probePostLogin(view, app, pendingResult, finished,
                    autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                    likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                    postLoginReloadIssued, timeout, silent);
        }, delayMs);
    }

    private static void probePostLogin(WebView view,
                                       Context app,
                                       android.content.BroadcastReceiver.PendingResult pendingResult,
                                       AtomicBoolean finished,
                                       boolean[] autoLoginAttempted,
                                       boolean[] usageNavigationAttempted,
                                       int[] parseAttempts,
                                       boolean[] likelyStaleSession,
                                       boolean[] postLoginPending,
                                       boolean[] postLoginProbeQueued,
                                       int[] postLoginPolls,
                                       boolean[] postLoginReloadIssued,
                                       Runnable timeout,
                                       boolean silent) {
        if (CANCELLED.get() || finished.get() || view == null || !postLoginPending[0]) return;
        prepareOffscreenViewport(view);
        SessionCookieStore.flush();

        UsageDomSnapshot.capture(view, text -> {
            if (CANCELLED.get() || finished.get() || !postLoginPending[0]) return;

            UsageData data = UsageParser.parse(text);
            if (data != null) {
                postLoginPending[0] = false;
                completeWithUsage(app, pendingResult, finished, data, timeout, silent);
                return;
            }

            int poll = ++postLoginPolls[0];
            boolean loggedOut = looksLoggedOut(text);
            String url = null;
            try { url = view.getUrl(); } catch (Throwable ignored) {}

            // The meaningful transition is not "N seconds elapsed"; it is that the login UI
            // is gone and the browser is no longer sitting on a login URL. At that moment the
            // newly-created cookie/session is ready for MyPage.
            boolean ready = !loggedOut && !looksLikeLoginUrl(url) && hasUsablePage(text);
            if (ready) {
                postLoginPending[0] = false;
                likelyStaleSession[0] = false;
                usageNavigationAttempted[0] = false;
                parseAttempts[0] = 0;
                SessionCookieStore.flush();
                if (!silent) {
                    WidgetStorage.setStatus(app, "조회 중…");
                }

                UsageDomSnapshot.loadFresh(view);
                // Backup continuation in case the site updates as an SPA and does not emit a
                // traditional onPageFinished callback for the expected route.
                MAIN.postDelayed(() -> {
                    if (!finished.get() && activeWebView != null) {
                        capture(activeWebView, app, pendingResult, finished,
                                autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                                likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                                postLoginReloadIssued, timeout, silent);
                    }
                }, 140L);
                return;
            }

            // v4.9: EyesMobile often commits the authenticated cookie a little after the login
            // button callback returns. v4.8 only watched for about a second, so a perfectly valid
            // login could be reported as a failed new session. Keep the single submitted login,
            // but give cookie rotation roughly three seconds to settle.
            if (poll < 5) {
                schedulePostLoginProbe(view, app, pendingResult, finished,
                        autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                        likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                        postLoginReloadIssued, timeout, silent, 120L);
                return;
            }

            // First MyPage sync at roughly 0.7s after submission. This handles AJAX logins that
            // create the cookie without navigating away from the login document.
            if (poll == 5 && !postLoginReloadIssued[0]) {
                postLoginReloadIssued[0] = true;
                if (!silent) WidgetStorage.setStatus(app, "조회 중…");
                SessionCookieStore.flush();
                UsageDomSnapshot.loadFresh(view);
                schedulePostLoginProbe(view, app, pendingResult, finished,
                        autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                        likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                        postLoginReloadIssued, timeout, silent, 220L);
                return;
            }

            // A second sync around 1.8s catches slower server-side session propagation. It does
            // not resubmit credentials, so it avoids the duplicate-login/15-second failure path.
            if (poll == 11) {
                if (!silent) WidgetStorage.setStatus(app, "조회 중…");
                SessionCookieStore.flush();
                UsageDomSnapshot.loadFresh(view);
                schedulePostLoginProbe(view, app, pendingResult, finished,
                        autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                        likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                        postLoginReloadIssued, timeout, silent, 260L);
                return;
            }

            if (poll < MAX_POST_LOGIN_POLLS) {
                long nextDelay = poll < 11 ? 150L : 180L;
                schedulePostLoginProbe(view, app, pendingResult, finished,
                        autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                        likelyStaleSession, postLoginPending, postLoginProbeQueued, postLoginPolls,
                        postLoginReloadIssued, timeout, silent, nextDelay);
                return;
            }

            postLoginPending[0] = false;
            MAIN.removeCallbacks(timeout);
            finish(app, pendingResult, finished,
                    "자동 로그인 후 세션 반영 지연 · 앱에서 로그인 상태 확인", false, silent);
        });
    }


    /**
     * Success-only early polling for an already-authenticated session.
     * It deliberately never decides that the user is logged out; that remains the job of
     * capture() after the document has had enough time to settle.
     */
    private static void scheduleFastUsageProbe(WebView view,
                                               Context app,
                                               android.content.BroadcastReceiver.PendingResult pendingResult,
                                               AtomicBoolean finished,
                                               int[] fastUsagePolls,
                                               Runnable timeout,
                                               boolean silent,
                                               long delayMs) {
        if (CANCELLED.get() || finished.get() || view == null || fastUsagePolls[0] >= MAX_FAST_USAGE_POLLS) return;
        MAIN.postDelayed(() -> {
            if (CANCELLED.get() || finished.get() || activeWebView != view) return;
            UsageDomSnapshot.capture(view, text -> {
                if (CANCELLED.get() || finished.get() || activeWebView != view) return;
                UsageData data = UsageParser.parse(text);
                if (data != null) {
                    try { view.stopLoading(); } catch (Throwable ignored) {}
                    completeWithUsage(app, pendingResult, finished, data, timeout, silent);
                    return;
                }

                int poll = ++fastUsagePolls[0];
                if (poll >= MAX_FAST_USAGE_POLLS) return;
                // Probe aggressively while the usage XHR is filling the DOM.
                long next = poll < 18 ? 80L : (poll < 36 ? 105L : 140L);
                scheduleFastUsageProbe(view, app, pendingResult, finished, fastUsagePolls,
                        timeout, silent, next);
            });
        }, delayMs);
    }

    private static void restartRecoveryTimeout(Runnable timeout) {
        if (timeout == null) return;
        MAIN.removeCallbacks(timeout);
        MAIN.postDelayed(timeout, 7000L);
    }

    private static void completeWithUsage(Context app,
                                          android.content.BroadcastReceiver.PendingResult pendingResult,
                                          AtomicBoolean finished,
                                          UsageData data,
                                          Runnable timeout,
                                          boolean silent) {
        SessionCookieStore.flush();
        VerifiedSessionStore.captureVerified(app);
        WidgetStorage.save(app, data);
        RefreshMetrics.decorateSuccess(app, "웹조회");
        UsageEndpointStore.verifyObservedAsync(app);
        MAIN.removeCallbacks(timeout);
        finish(app, pendingResult, finished, null, true, silent);
    }

    private static boolean hasUsablePage(String text) {
        if (text == null) return false;
        String t = text.trim();
        if (t.length() < 120) return false;
        // UsageDomSnapshot always carries these markers on a successfully evaluated document.
        return t.contains("[[EYES_URL]]") && t.contains("[[EYES_BODY]]");
    }

    private static boolean looksLikeLoginUrl(String url) {
        if (url == null) return false;
        String u = url.toLowerCase(Locale.ROOT);
        return u.contains("/login")
                || u.contains("login?")
                || u.contains("member/login")
                || u.contains("signin")
                || u.contains("sign-in");
    }

    /** Give an unattached WebView a stable viewport so DOM visibility/layout works. */
    private static void prepareOffscreenViewport(WebView webView) {
        if (webView == null) return;
        try {
            int width = 1080;
            int height = 1920;
            int w = View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY);
            int h = View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY);
            webView.measure(w, h);
            webView.layout(0, 0, width, height);
        } catch (Throwable ignored) {
        }
    }

    private static void finish(Context app,
                               android.content.BroadcastReceiver.PendingResult pendingResult,
                               AtomicBoolean finished,
                               String status,
                               boolean success,
                               boolean silent) {
        if (CANCELLED.get()) return;
        if (!finished.compareAndSet(false, true)) return;
        try {
            SessionCookieStore.flush();
            if (!success && !silent && status != null) WidgetStorage.setStatus(app, status);
            EyesMobileWidgetProvider.updateAll(app);
        } catch (Throwable ignored) {
        }
        try {
            if (activeWebView != null) {
                activeWebView.stopLoading();
                activeWebView.setWebViewClient(null);
                activeWebView.destroy();
            }
        } catch (Throwable ignored) {
        } finally {
            activeWebView = null;
            RUNNING.set(false);
            android.content.BroadcastReceiver.PendingResult pending = activePendingResult;
            activePendingResult = null;
            if (pending != null) {
                try { pending.finish(); } catch (Throwable ignored) {}
            } else if (pendingResult != null) {
                try { pendingResult.finish(); } catch (Throwable ignored) {}
            }
        }
    }

    private static boolean looksLoggedOut(String text) {
        if (text == null) return false;
        String t = text.toLowerCase(Locale.ROOT);
        return t.contains("로그인을 해주세요")
                || (t.contains("로그인") && (t.contains("비밀번호") || t.contains("아이디(이메일)")));
    }
}

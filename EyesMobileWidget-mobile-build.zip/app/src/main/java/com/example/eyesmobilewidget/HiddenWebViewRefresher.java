package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Silent widget refresh. v2.8 makes the off-screen WebView behave like the visible settings
 * WebView: same browser settings, WebChromeClient, a real measured viewport, verified-session
 * bootstrap, automatic login recovery, usage-page navigation, and final parsing. The measured
 * viewport matters because an unattached WebView can otherwise report zero-sized DOM controls.
 */
public final class HiddenWebViewRefresher {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    private static WebView activeWebView;

    private HiddenWebViewRefresher() {}

    public static void refresh(Context context, android.content.BroadcastReceiver.PendingResult pendingResult) {
        refresh(context, pendingResult, false);
    }

    public static void refresh(Context context,
                               android.content.BroadcastReceiver.PendingResult pendingResult,
                               boolean silent) {
        final Context app = context.getApplicationContext();
        if (!RUNNING.compareAndSet(false, true)) {
            if (pendingResult != null) pendingResult.finish();
            return;
        }

        if (!silent) {
            WidgetStorage.setStatus(app, "새로고침 중…");
            EyesMobileWidgetProvider.updateAll(app);
        }
        MAIN.post(() -> start(app, pendingResult, silent));
    }

    private static void start(Context app,
                              android.content.BroadcastReceiver.PendingResult pendingResult,
                              boolean silent) {
        final AtomicBoolean finished = new AtomicBoolean(false);
        final boolean[] autoLoginAttempted = {false};
        final boolean[] usageNavigationAttempted = {false};
        final int[] parseAttempts = {0};

        final Runnable timeout = () -> finish(app, pendingResult, finished,
                "새로고침 시간 초과 · 자동 로그인/사용량 조회 확인 필요", false, silent);
        MAIN.postDelayed(timeout, 48000L);

        try {
            SessionCookieStore.migrateToLiveCookiePolicy(app);
            WebSessionStateStore.clear(app);
            CookieManager.getInstance().setAcceptCookie(true);
            VerifiedSessionStore.restoreMissing(app);
            SessionCookieStore.flush();

            WebView webView = new WebView(app);
            activeWebView = webView;
            prepareOffscreenViewport(webView);
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setLoadWithOverviewMode(true);
            settings.setUseWideViewPort(true);
            settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
            webView.clearCache(true);

            String storedUa = SessionCookieStore.getUserAgent(app);
            if (storedUa != null && !storedUa.trim().isEmpty()) {
                settings.setUserAgentString(storedUa);
            } else {
                SessionCookieStore.saveUserAgent(app, settings.getUserAgentString());
            }
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
            // MainActivity already had this; the old hidden refresh path did not. Some site
            // login layers depend on WebChromeClient-backed browser behavior.
            webView.setWebChromeClient(new WebChromeClient());

            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    if (finished.get()) return;
                    prepareOffscreenViewport(view);
                    SessionCookieStore.flush();
                    MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                            autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                            timeout, silent), 1100L);
                }
            });

            UsageDomSnapshot.loadFresh(webView);
        } catch (Throwable t) {
            MAIN.removeCallbacks(timeout);
            finish(app, pendingResult, finished, "새로고침 실패", false, silent);
        }
    }

    private static void capture(WebView view,
                                Context app,
                                android.content.BroadcastReceiver.PendingResult pendingResult,
                                AtomicBoolean finished,
                                boolean[] autoLoginAttempted,
                                boolean[] usageNavigationAttempted,
                                int[] parseAttempts,
                                Runnable timeout,
                                boolean silent) {
        if (finished.get() || view == null) return;

        UsageDomSnapshot.capture(view, text -> {
            if (finished.get()) return;
            UsageData data = UsageParser.parse(text);
            if (data != null) {
                SessionCookieStore.flush();
                VerifiedSessionStore.captureVerified(app);
                WidgetStorage.save(app, data);
                EyesMobileWidgetProvider.updateAll(app);
                MAIN.removeCallbacks(timeout);
                finish(app, pendingResult, finished, null, true, silent);
                return;
            }

            boolean loggedOut = looksLoggedOut(text);

            // If a logged-out page/modal is already visible, recover immediately.
            if (loggedOut && !autoLoginAttempted[0] && AutoLoginHelper.hasCredentials(app)) {
                VerifiedSessionStore.invalidate(app);
                autoLoginAttempted[0] = true;
                if (!silent) {
                    WidgetStorage.setStatus(app, "로그인 만료 감지 · 자동 로그인 중…");
                    EyesMobileWidgetProvider.updateAll(app);
                }
                attemptAutoLogin(view, app, pendingResult, finished, autoLoginAttempted,
                        usageNavigationAttempted, parseAttempts, timeout, silent);
                return;
            }

            // While apparently logged in, first try to reach the dedicated usage page.
            if (!loggedOut && !usageNavigationAttempted[0]) {
                usageNavigationAttempted[0] = true;
                UsagePageNavigator.tryOpen(view, (navigated, detail) -> {
                    if (finished.get()) return;
                    MAIN.postDelayed(() -> {
                        if (!finished.get() && activeWebView != null) {
                            capture(activeWebView, app, pendingResult, finished,
                                    autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                                    timeout, silent);
                        }
                    }, navigated ? 1700L : 350L);
                });
                return;
            }

            // Some logged-out states only show a header "로그인" button, not the password fields.
            // Ask AutoLoginHelper to open that layer and submit it rather than relying on body text.
            if (!autoLoginAttempted[0] && AutoLoginHelper.hasCredentials(app)) {
                autoLoginAttempted[0] = true;
                if (!silent) {
                    WidgetStorage.setStatus(app, "로그인 상태 확인 · 자동 로그인 시도 중…");
                    EyesMobileWidgetProvider.updateAll(app);
                }
                attemptAutoLogin(view, app, pendingResult, finished, autoLoginAttempted,
                        usageNavigationAttempted, parseAttempts, timeout, silent);
                return;
            }

            if (!loggedOut && parseAttempts[0]++ < 3) {
                MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                        autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                        timeout, silent), 1200L);
                return;
            }

            MAIN.removeCallbacks(timeout);
            if (loggedOut) {
                finish(app, pendingResult, finished,
                        AutoLoginHelper.hasCredentials(app)
                                ? "자동 로그인 실패 · 앱에서 계정 확인"
                                : "로그인 만료 · 앱에서 자동로그인 설정",
                        false, silent);
            } else {
                finish(app, pendingResult, finished, "사용량을 읽지 못했습니다", false, silent);
            }
        });
    }

    private static void attemptAutoLogin(WebView view,
                                         Context app,
                                         android.content.BroadcastReceiver.PendingResult pendingResult,
                                         AtomicBoolean finished,
                                         boolean[] autoLoginAttempted,
                                         boolean[] usageNavigationAttempted,
                                         int[] parseAttempts,
                                         Runnable timeout,
                                         boolean silent) {
        prepareOffscreenViewport(view);
        AutoLoginHelper.tryLoginOffscreen(app, view, (submitted, detail) -> {
            if (finished.get()) return;
            if (submitted) {
                usageNavigationAttempted[0] = false;
                parseAttempts[0] = 0;
                if (!silent) {
                    WidgetStorage.setStatus(app, "자동 로그인 전송 완료 · 새 세션 확인 중…");
                    EyesMobileWidgetProvider.updateAll(app);
                }
                // The login request can finish asynchronously. Do not reload MyPage too early;
                // give the site time to write/rotate the new auth cookie first.
                MAIN.postDelayed(() -> {
                    if (!finished.get() && activeWebView != null) {
                        SessionCookieStore.flush();
                        prepareOffscreenViewport(activeWebView);
                        UsageDomSnapshot.loadFresh(activeWebView);
                    }
                }, 5200L);
                return;
            }

            // NO_LOGIN_UI means the page may simply still be rendering; do not falsely label
            // the encrypted credentials as wrong. Give the usage page a final normal retry.
            if (detail != null && detail.startsWith("NO_LOGIN_UI")) {
                if (parseAttempts[0]++ < 2) {
                    MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                            autoLoginAttempted, usageNavigationAttempted, parseAttempts,
                            timeout, silent), 1000L);
                    return;
                }
            }

            MAIN.removeCallbacks(timeout);
            String why = (detail == null || detail.trim().isEmpty()) ? "UNKNOWN" : detail;
            finish(app, pendingResult, finished,
                    "자동 로그인 실패 · " + why, false, silent);
        });
    }

    /** Give an unattached WebView a stable viewport so DOM visibility/layout works. */
    private static void prepareOffscreenViewport(WebView webView) {
        if (webView == null) return;
        try {
            int width = 1080;
            int height = 1920;
            int w = View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY);
            int h = View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY);
            webView.measure(w, h);
            webView.layout(0, 0, width, height);
        } catch (Throwable ignored) {
        }
    }

    private static void finish(Context app,
                               android.content.BroadcastReceiver.PendingResult pendingResult,
                               AtomicBoolean finished,
                               String status,
                               boolean success,
                               boolean silent) {
        if (!finished.compareAndSet(false, true)) return;
        try {
            SessionCookieStore.flush();
            if (!success && !silent && status != null) WidgetStorage.setStatus(app, status);
            EyesMobileWidgetProvider.updateAll(app);
        } catch (Throwable ignored) {
        }
        try {
            if (activeWebView != null) {
                activeWebView.stopLoading();
                activeWebView.setWebViewClient(null);
                activeWebView.destroy();
            }
        } catch (Throwable ignored) {
        } finally {
            activeWebView = null;
            RUNNING.set(false);
            if (pendingResult != null) pendingResult.finish();
        }
    }

    private static boolean looksLoggedOut(String text) {
        if (text == null) return false;
        String t = text.toLowerCase(java.util.Locale.ROOT);
        return t.contains("로그인을 해주세요")
                || (t.contains("로그인") && (t.contains("비밀번호") || t.contains("아이디(이메일)")));
    }
}

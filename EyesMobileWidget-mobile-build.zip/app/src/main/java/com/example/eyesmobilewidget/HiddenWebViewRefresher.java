package com.example.eyesmobilewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Performs a widget refresh with an off-screen WebView so the Activity never opens.
 * v2.2 restores both cookies and tab-scoped Web Storage before loading MyPage.
 */
public final class HiddenWebViewRefresher {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    private static WebView activeWebView;

    private HiddenWebViewRefresher() {}

    public static void refresh(Context context, android.content.BroadcastReceiver.PendingResult pendingResult) {
        refresh(context, pendingResult, false);
    }

    public static void refresh(Context context,
                               android.content.BroadcastReceiver.PendingResult pendingResult,
                               boolean silent) {
        final Context app = context.getApplicationContext();

        if (!RUNNING.compareAndSet(false, true)) {
            if (pendingResult != null) pendingResult.finish();
            return;
        }

        if (!silent) {
            WidgetStorage.setStatus(app, "새로고침 중…");
            EyesMobileWidgetProvider.updateAll(app);
        }

        MAIN.post(() -> start(app, pendingResult, silent));
    }

    private static void start(Context app,
                              android.content.BroadcastReceiver.PendingResult pendingResult,
                              boolean silent) {
        final AtomicBoolean finished = new AtomicBoolean(false);
        final boolean[] recoveryAttempted = {false};
        final boolean[] bootstrapping = {false};
        final int[] parseAttempts = {0};

        final Runnable timeout = () -> finish(app, pendingResult, finished,
                "새로고침 시간 초과", false, silent);
        MAIN.postDelayed(timeout, 11500L);

        try {
            SessionCookieStore.restoreIfMissing(app);
            CookieManager.getInstance().setAcceptCookie(true);
            SessionCookieStore.flush();

            WebView webView = new WebView(app);
            activeWebView = webView;

            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setLoadWithOverviewMode(true);
            settings.setUseWideViewPort(true);
            settings.setCacheMode(WebSettings.LOAD_DEFAULT);

            String storedUa = SessionCookieStore.getUserAgent(app);
            if (storedUa != null && !storedUa.trim().isEmpty()) {
                settings.setUserAgentString(storedUa);
            } else {
                SessionCookieStore.saveUserAgent(app, settings.getUserAgentString());
            }

            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    if (finished.get()) return;
                    SessionCookieStore.flush();

                    if (bootstrapping[0] && isEyesOrigin(url)) {
                        bootstrapping[0] = false;
                        WebSessionStateStore.restoreIntoWebView(app, view, () -> {
                            SessionCookieStore.forceRestoreBackup(app);
                            SessionCookieStore.flush();
                            MAIN.postDelayed(() -> {
                                if (!finished.get() && activeWebView != null) {
                                    activeWebView.loadUrl(EyesMobileFetcher.MY_PAGE_URL);
                                }
                            }, 180L);
                        });
                        return;
                    }

                    MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                            recoveryAttempted, bootstrapping, parseAttempts, timeout, silent), 950L);
                }
            });

            if (SessionCookieStore.hasBackup(app) || WebSessionStateStore.hasSnapshot(app)) {
                bootstrapping[0] = true;
                webView.loadUrl(SessionCookieStore.URL_WWW);
            } else {
                webView.loadUrl(EyesMobileFetcher.MY_PAGE_URL);
            }
        } catch (Throwable t) {
            MAIN.removeCallbacks(timeout);
            finish(app, pendingResult, finished, "새로고침 실패", false, silent);
        }
    }

    private static void capture(WebView view,
                                Context app,
                                android.content.BroadcastReceiver.PendingResult pendingResult,
                                AtomicBoolean finished,
                                boolean[] recoveryAttempted,
                                boolean[] bootstrapping,
                                int[] parseAttempts,
                                Runnable timeout,
                                boolean silent) {
        if (finished.get() || view == null) return;

        view.evaluateJavascript(
                "(function(){try{return document.body ? document.body.innerText : '';}catch(e){return '';}})()",
                value -> {
                    if (finished.get()) return;
                    String text = decodeJsString(value);
                    UsageData data = UsageParser.parse(text);

                    if (data != null) {
                        SessionCookieStore.backup(app);
                        WebSessionStateStore.backupFromWebView(app, view, () -> {
                            if (finished.get()) return;
                            SessionCookieStore.flush();
                            SessionKeepAliveScheduler.schedule(app);
                            WidgetStorage.save(app, data);
                            WidgetStorage.setStatus(app, "최신 사용량");
                            EyesMobileWidgetProvider.updateAll(app);
                            MAIN.removeCallbacks(timeout);
                            finish(app, pendingResult, finished, null, true, silent);
                        });
                        return;
                    }

                    if (!recoveryAttempted[0] && looksLoggedOut(text)
                            && (SessionCookieStore.hasBackup(app) || WebSessionStateStore.hasSnapshot(app))) {
                        recoveryAttempted[0] = true;
                        SessionCookieStore.forceRestoreBackup(app);
                        SessionCookieStore.flush();
                        bootstrapping[0] = true;
                        MAIN.postDelayed(() -> {
                            if (!finished.get() && activeWebView != null) {
                                activeWebView.loadUrl(SessionCookieStore.URL_WWW);
                            }
                        }, 180L);
                        return;
                    }

                    // Usage cards may be painted by site JavaScript shortly after onPageFinished.
                    if (!looksLoggedOut(text) && parseAttempts[0]++ < 2) {
                        MAIN.postDelayed(() -> capture(view, app, pendingResult, finished,
                                recoveryAttempted, bootstrapping, parseAttempts, timeout, silent), 1200L);
                        return;
                    }

                    MAIN.removeCallbacks(timeout);
                    if (looksLoggedOut(text)) {
                        finish(app, pendingResult, finished,
                                "로그인 세션 만료 · 다시 로그인 필요", false, silent);
                    } else {
                        finish(app, pendingResult, finished,
                                "사용량을 읽지 못했습니다", false, silent);
                    }
                });
    }

    private static void finish(Context app,
                               android.content.BroadcastReceiver.PendingResult pendingResult,
                               AtomicBoolean finished,
                               String status,
                               boolean success,
                               boolean silent) {
        if (!finished.compareAndSet(false, true)) return;

        try {
            SessionCookieStore.flush();
            if (!success && !silent && status != null) WidgetStorage.setStatus(app, status);
            EyesMobileWidgetProvider.updateAll(app);
        } catch (Throwable ignored) {
        }

        try {
            if (activeWebView != null) {
                activeWebView.stopLoading();
                activeWebView.setWebViewClient(null);
                activeWebView.destroy();
            }
        } catch (Throwable ignored) {
        } finally {
            activeWebView = null;
            RUNNING.set(false);
            if (pendingResult != null) pendingResult.finish();
        }
    }

    private static boolean isEyesOrigin(String url) {
        if (url == null) return false;
        String u = url.toLowerCase(Locale.ROOT);
        return u.startsWith("https://www.eyes.co.kr/") || u.startsWith("https://eyes.co.kr/");
    }

    private static boolean looksLoggedOut(String text) {
        if (text == null) return false;
        String t = text.toLowerCase(Locale.ROOT);
        return t.contains("로그인")
                && (t.contains("비밀번호") || t.contains("아이디") || t.contains("회원가입"));
    }

    private static String decodeJsString(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            if (value.startsWith("\"") && value.endsWith("\"")) {
                value = value.substring(1, value.length() - 1);
            }
            return value.replace("\\n", "\n")
                    .replace("\\r", "\r")
                    .replace("\\t", "\t")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\u003C", "<")
                    .replace("\\u003E", ">");
        } catch (Exception e) {
            return value;
        }
    }
}

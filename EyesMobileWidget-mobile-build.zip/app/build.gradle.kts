plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.eyesmobilewidget"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.eyesmobilewidget"
        minSdk = 24
        targetSdk = 34
        versionCode = 38
        versionName = "3.8"
    }

    signingConfigs {
        create("eyesDebug") {
            storeFile = file("eyes-debug.keystore")
            storePassword = "android"
            keyAlias = "eyesdebug"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("eyesDebug")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("eyesDebug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

#!/bin/sh
set -e
cd "$(dirname "$0")"
./gradlew assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk EyesMobileWidget-debug.apk
echo "DONE: $(pwd)/EyesMobileWidget-debug.apk"

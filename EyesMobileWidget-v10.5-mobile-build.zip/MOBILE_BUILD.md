# EyesMobileWidget v7.6 mobile build

- Normal data/voice/SMS parsing is isolated from supplementary-call parsing.
- A bare `부가통화 300분` is treated as allowance, never as used time.
- Supplementary-call usage defaults to `0초` when no usage is reported.
- Supplementary-call total is fixed at `300분 제공`.
- Supplementary-call gauge percent is recalculated from used duration / 300 minutes.
- Old v7.0-v7.5 supplementary-call cache is discarded once on upgrade.
- Removes the fake 78% gauge fallback; unknown tiny non-zero usage gets only a 1% marker.


## v7.9
- Widget typography changed from monospace to regular upright sans-serif.
- Removed bold styling from widget labels/captions so Korean text appears as a clean regular typeface.
- Gauge text now uses regular sans-serif instead of monospace bold.


## v8.0
- 위젯 텍스트: Pretendard Regular 고정
- 게이지 숫자: Pretendard SemiBold 고정
- 삼성/기기 사용자 글꼴 설정의 영향을 받지 않도록 폰트를 APK 내부 리소스로 포함
- 빌드 시 Pretendard v1.3.9 공식 GitHub에서 폰트를 받아 APK에 포함


v8.1: 카드 제목과 캡션까지 Pretendard 비트맵 렌더링으로 고정해 삼성 런처 사용자 글꼴 치환을 차단.

## v8.6
- Separate supplementary-call (`부가통화`) sections from normal voice parsing before generic `통화/사용량` matching.
- Treat the fixed 300-minute supplementary allowance only as allowance, never as consumed usage.
- Expand supplementary-call label variants while preserving independent voice/add-on values.

## v8.7
- Added fallback split for plans where EyesMobile advances the raw voice counter after supplementary calls while the dedicated 300-minute counter remains 0.
- Keeps a separate raw voice baseline so the same delta is not counted twice.
- Converts the refresh control to a bitmap ImageView and rotates it during manual refresh progress.

## v8.8
- Keeps the existing circular refresh-arrow shape while reducing the line and arrowhead weight.

## v8.9
- Reduces the refresh button from 32dp to 29dp.
- Enlarges the arrowhead relative to the thin circular stroke so the refresh shape remains clear.

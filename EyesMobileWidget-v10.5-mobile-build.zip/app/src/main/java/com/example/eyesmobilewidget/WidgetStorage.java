package com.example.eyesmobilewidget;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class WidgetStorage {
    private static final String PREFS = "eyes_mobile_widget";
    private static final String ADDON_TOTAL = "300분";
    private static final String KEY_RAW_VOICE_USED = "v87_raw_voice_used";

    private WidgetStorage() {}

    public static void save(Context context, UsageData d) {
        if (d == null) return;

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        UsageData old = load(context);

        // Keep the carrier's raw voice counter separately. On this plan the portal can advance
        // that counter after a supplementary call while its separate 300-minute counter still
        // reports 0. If that happens, the delta must not be lost in the normal voice card.
        String rawVoiceUsed = d.voiceUsed;
        String previousRawVoice = prefs.getString(KEY_RAW_VOICE_USED,
                old != null ? old.voiceUsed : "--");

        boolean addonCounterPresent = UsageParser.hasReliableAddonVoice(d);
        if (!addonCounterPresent) {
            String keep = old != null && old.updatedAt > 0L ? old.addonVoiceUsed : "0초";
            int keepPercent = old != null && old.updatedAt > 0L ? old.addonVoicePercent : 0;
            d = new UsageData(
                    d.dataUsed, d.dataTotal, d.dataPercent,
                    d.voiceUsed, d.voiceTotal, d.voicePercent,
                    d.smsUsed, d.smsTotal, d.smsPercent,
                    keep, ADDON_TOTAL, keepPercent,
                    d.updatedAt);
        }

        // v9.8: EyesMobile can completely omit the supplementary-call counter while still
        // adding that call time to the raw voice counter. Run the delta splitter for both an
        // explicit zero counter and an omitted counter; the preserved addon value above gives
        // it a safe accumulation base instead of silently leaving the call under normal voice.
        d = splitCombinedVoiceAddon(old, previousRawVoice, d);

        d = normalizeForWidget(d);

        SharedPreferences.Editor edit = prefs.edit()
                .putString("data_used", d.dataUsed)
                .putString("data_total", d.dataTotal)
                .putInt("data_percent", d.dataPercent)
                .putString("voice_used", d.voiceUsed)
                .putString("voice_total", d.voiceTotal)
                .putInt("voice_percent", d.voicePercent)
                .putString("sms_used", d.smsUsed)
                .putString("sms_total", d.smsTotal)
                .putInt("sms_percent", d.smsPercent)
                .putString("addon_voice_used", d.addonVoiceUsed)
                .putString("addon_voice_total", ADDON_TOTAL)
                .putInt("addon_voice_percent", d.addonVoicePercent)
                .putLong("updated_at", d.updatedAt)
                .putString("status", "업데이트 완료")
                .putBoolean("v76_addon_cache_valid", true);

        // Store the unmodified carrier counter only when it was a real duration. This makes the
        // next refresh compare raw-to-raw and prevents the same delta from being counted twice.
        if (hasDuration(rawVoiceUsed)) edit.putString(KEY_RAW_VOICE_USED, rawVoiceUsed);
        edit.apply();
    }

    /**
     * v8.7 fallback for EyesMobile responses where "음성" is a combined counter and the
     * supplementary 300-minute field remains at 0. For unlimited/basic-provided voice plans:
     * - a real non-zero addon counter wins and is subtracted from the combined voice value;
     * - if addon is explicitly 0 but raw voice increased since the previous refresh, accumulate
     *   only that new raw delta in the addon bucket and subtract the accumulated addon amount from
     *   the displayed normal-voice value.
     *
     * This is intentionally limited to 기본제공/무제한 voice plans so finite-minute plans keep the
     * carrier's original accounting untouched.
     */
    private static UsageData splitCombinedVoiceAddon(UsageData old, String previousRawVoice, UsageData incoming) {
        if (incoming == null || !isBasicVoice(incoming.voiceTotal)) return incoming;

        double rawVoiceSeconds = durationSecondsOrInvalid(incoming.voiceUsed);
        if (rawVoiceSeconds < 0d) return incoming;

        double reportedAddonSeconds = durationSecondsOrInvalid(incoming.addonVoiceUsed);
        if (reportedAddonSeconds < 0d) reportedAddonSeconds = 0d;

        double addonSeconds = reportedAddonSeconds;
        if (reportedAddonSeconds <= 0.5d && old != null && old.updatedAt > 0L) {
            double oldAddonSeconds = Math.max(0d, durationSeconds(old.addonVoiceUsed));
            double previousRawSeconds = durationSecondsOrInvalid(previousRawVoice);
            if (previousRawSeconds >= 0d && rawVoiceSeconds > previousRawSeconds + 0.5d) {
                addonSeconds = Math.min(300d * 60d,
                        oldAddonSeconds + (rawVoiceSeconds - previousRawSeconds));
            } else {
                // No new combined-voice movement: keep the already inferred addon amount instead
                // of falling back to the portal's persistent 0-minute field.
                addonSeconds = oldAddonSeconds;
            }
        }

        if (addonSeconds <= 0.5d) return incoming;

        double normalVoiceSeconds = Math.max(0d, rawVoiceSeconds - addonSeconds);
        String addonUsed = formatDuration(addonSeconds);
        String normalVoiceUsed = formatDuration(normalVoiceSeconds);

        return new UsageData(
                incoming.dataUsed, incoming.dataTotal, incoming.dataPercent,
                normalVoiceUsed, incoming.voiceTotal, incoming.voicePercent,
                incoming.smsUsed, incoming.smsTotal, incoming.smsPercent,
                addonUsed, ADDON_TOTAL, addonPercent(addonUsed),
                incoming.updatedAt);
    }

    public static UsageData load(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long updated = p.getLong("updated_at", 0L);
        String addonUsed = p.getString("addon_voice_used", "--");
        int addonPercent = p.getInt("addon_voice_percent", 0);

        // v7.0-v7.5 could cache the 300-minute allowance as if it were used time.
        // On first v7.6 launch, discard only that unreliable supplementary-call cache.
        if (!p.getBoolean("v76_addon_cache_valid", false)) {
            addonUsed = "0초";
            addonPercent = 0;
        }

        UsageData raw = new UsageData(
                p.getString("data_used", "--"), p.getString("data_total", "--"), p.getInt("data_percent", 0),
                p.getString("voice_used", "--"), p.getString("voice_total", "--"), p.getInt("voice_percent", 0),
                p.getString("sms_used", "--"), p.getString("sms_total", "--"), p.getInt("sms_percent", 0),
                addonUsed, ADDON_TOTAL, addonPercent,
                updated
        );
        return normalizeForWidget(raw);
    }

    private static UsageData normalizeForWidget(UsageData d) {
        if (d == null) return null;
        String addonUsed = normalizeAddonUsed(d.addonVoiceUsed);
        int addonPercent = addonPercent(addonUsed);
        return new UsageData(
                d.dataUsed, d.dataTotal, d.dataPercent,
                d.voiceUsed, d.voiceTotal, d.voicePercent,
                d.smsUsed, d.smsTotal, d.smsPercent,
                addonUsed, ADDON_TOTAL, addonPercent,
                d.updatedAt
        );
    }

    private static boolean isBasicVoice(String total) {
        if (total == null) return false;
        String t = total.replaceAll("\\s+", "");
        return t.contains("기본제공") || t.contains("무제한");
    }

    private static boolean hasDuration(String value) {
        return durationSecondsOrInvalid(value) >= 0d;
    }

    private static String normalizeAddonUsed(String value) {
        if (value == null) return "0초";
        String v = value.trim();
        if (v.isEmpty() || v.equals("--") || v.equals("-") || v.equals("0") || v.equals("0분")) return "0초";
        return v;
    }

    private static int addonPercent(String value) {
        double seconds = durationSeconds(value);
        if (seconds <= 0d) return 0;
        double raw = seconds * 100d / (300d * 60d);
        int p = (int) Math.round(raw);
        if (p == 0) p = 1;
        return Math.max(0, Math.min(100, p));
    }

    private static double durationSeconds(String value) {
        double parsed = durationSecondsOrInvalid(value);
        return parsed < 0d ? 0d : parsed;
    }

    private static double durationSecondsOrInvalid(String value) {
        if (value == null) return -1d;
        String v = value.replace(",", "").trim().toUpperCase(Locale.ROOT);
        if (v.isEmpty() || "--".equals(v) || "-".equals(v)) return -1d;

        Matcher clock = Pattern.compile("(?<![0-9])([0-9]{1,3}):([0-9]{2})(?::([0-9]{2}))?(?![0-9])").matcher(v);
        if (clock.find()) {
            try {
                double a = Double.parseDouble(clock.group(1));
                double b = Double.parseDouble(clock.group(2));
                String third = clock.group(3);
                return third == null ? a * 60d + b : a * 3600d + b * 60d + Double.parseDouble(third);
            } catch (Exception ignored) {}
        }
        Matcher m = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)\\s*(시간|분|초|MINUTE|MIN)", Pattern.CASE_INSENSITIVE).matcher(v);
        double seconds = 0d;
        boolean found = false;
        while (m.find()) {
            double n;
            try { n = Double.parseDouble(m.group(1)); } catch (Exception e) { continue; }
            String unit = m.group(2).toUpperCase(Locale.ROOT);
            if ("시간".equals(unit)) seconds += n * 3600d;
            else if ("초".equals(unit)) seconds += n;
            else seconds += n * 60d;
            found = true;
        }
        return found ? Math.max(0d, seconds) : -1d;
    }

    private static String formatDuration(double rawSeconds) {
        long seconds = Math.max(0L, Math.round(rawSeconds));
        if (seconds == 0L) return "0초";
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long remainSeconds = seconds % 60L;
        StringBuilder out = new StringBuilder();
        if (hours > 0L) out.append(hours).append("시간");
        if (minutes > 0L) out.append(minutes).append("분");
        if (remainSeconds > 0L) out.append(remainSeconds).append("초");
        return out.length() == 0 ? "0초" : out.toString();
    }

    public static void setStatus(Context context, String status) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("status", status).apply();
    }

    public static String getStatus(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("status", "앱을 열어 아이즈모바일에 로그인하세요");
    }

    private static boolean same(String a, String b) {
        if (a == null) return b == null;
        return a.equals(b);
    }
}

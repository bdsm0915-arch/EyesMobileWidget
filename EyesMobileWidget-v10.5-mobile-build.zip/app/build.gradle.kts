import java.io.File
import java.net.URL

plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.eyesmobilewidget"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.eyesmobilewidget"
        minSdk = 24
        targetSdk = 34
        versionCode = 105
        versionName = "10.5"
    }

    signingConfigs {
        create("eyesDebug") {
            storeFile = file("eyes-debug.keystore")
            storePassword = "android"
            keyAlias = "eyesdebug"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("eyesDebug")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("eyesDebug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}


dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.core:core:1.13.1")
}


// v8.0: bundle Pretendard into the APK at build time so widget typography does not
// follow Samsung / device custom fonts. Pretendard is an open-source system-UI
// alternative and gives a clean iOS-like Korean UI feel.
val widgetFontDir = layout.projectDirectory.dir("src/main/res/font").asFile
val widgetFontSources = mapOf(
    "pretendard_regular.otf" to "https://raw.githubusercontent.com/orioncactus/pretendard/v1.3.9/packages/pretendard/dist/public/static/Pretendard-Regular.otf",
    "pretendard_semibold.otf" to "https://raw.githubusercontent.com/orioncactus/pretendard/v1.3.9/packages/pretendard/dist/public/static/Pretendard-SemiBold.otf"
)

val downloadWidgetFonts by tasks.registering {
    val outputFiles = widgetFontSources.keys.map { File(widgetFontDir, it) }
    val licenseFile = layout.projectDirectory.file("src/main/assets/licenses/pretendard_license.txt").asFile
    outputs.files(outputFiles + licenseFile)
    doLast {
        widgetFontDir.mkdirs()
        widgetFontSources.forEach { (fileName, sourceUrl) ->
            val output = File(widgetFontDir, fileName)
            if (!output.exists() || output.length() < 100_000L) {
                val connection = URL(sourceUrl).openConnection()
                connection.connectTimeout = 20_000
                connection.readTimeout = 60_000
                connection.getInputStream().use { input ->
                    output.outputStream().use { stream -> input.copyTo(stream) }
                }
            }
            check(output.exists() && output.length() >= 100_000L) {
                "Widget font download failed: $fileName"
            }
        }

        licenseFile.parentFile.mkdirs()
        if (!licenseFile.exists() || licenseFile.length() < 1_000L) {
            val licenseUrl = "https://raw.githubusercontent.com/orioncactus/pretendard/v1.3.9/LICENSE"
            val connection = URL(licenseUrl).openConnection()
            connection.connectTimeout = 20_000
            connection.readTimeout = 30_000
            connection.getInputStream().use { input ->
                licenseFile.outputStream().use { stream -> input.copyTo(stream) }
            }
        }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(downloadWidgetFonts)
}
